# coding=utf-8
__author__ = 'Administrator'

import threading

from semaphore import Semaphore


class Thread(threading.Thread):
    def __init__(self, t, *args):
        threading.Thread.__init__(self, target=t, args=args)

        self.start()


if __name__ == '__main__':
    import time
    import logging
    import random

    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.info(__name__)

    class Sema(object):
        mutex = Semaphore(1)

    def add(a, b):
        res = a + b
        Sema.mutex.wait()
        # 关键代码段，使用信号量进行互斥
        sleep_ts = random.randint(0, 3)
        logger.info(str(a) + '+' + str(b) + ": 等待时间" + str(sleep_ts))
        time.sleep(sleep_ts)
        Sema.mutex.signal()
        logger.info(res)
        return res

    # add(1, 1)

    th_list = list()

    for i in xrange(10):
        th_list.append(Thread(add, i, i))

    # 等待所有线程结束
    for t in th_list:
        t.join()



