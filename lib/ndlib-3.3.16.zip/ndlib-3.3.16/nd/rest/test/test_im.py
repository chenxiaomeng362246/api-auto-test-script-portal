# coding=utf-8

__author__ = 'linzh'

import sys
sys.path.insert(0, '..')

from cof.nd_im.new import SendNew99U

# 推送给群
content = "手机测试结果报告\n"
group_list = [2146772]
send_o = SendNew99U()
send_o.send_to_groups(content, group_list)
