# coding=utf-8
import os

from cof.co_file.file import get_app_loc

__author__ = 'linzh'


app_loc = get_app_loc()

fp = open(app_loc + os.sep + 'data' + os.sep + 'attention.txt', "w")

# 36
data = "abcdefghijklmnopqrstuvwxyz1234567890\n"

# 18000
for i in range(0, 5000):
    fp.write(data)

fp.close()
