# coding=utf-8

__author__ = 'linzh'

"""
测试url
"""

import urlparse

url = "http://www.baidu.com"

url_compon = urlparse.urlparse(url)

netloc = url_compon.netloc

netloc_compon = netloc.split(':')

if len(netloc_compon) > 1:
    # 带有端口号
    pass


