# coding=utf-8
from cof.co_mongo.conn import MgConn
from cof.co_test.nd_case import NdCase
from cof.mysql import MysqlConn
from prepare.ExamConst import ExamConst

__author__ = 'linzh'

import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(filename)s[%(lineno)d] %(levelname)s %(message)s')
logger = logging.getLogger(__name__)
logger.info(__name__)


class MysqlTest(NdCase):
    def test_mysql_conn(self):
        """
        测试清空数据库表

        :return:
        """
        host = ExamConst.Mysql.Host

        logger.info(host)

        conn_o = MysqlConn(host=host, user='space', password='888888')

        conn = conn_o.get_connection('elearning_qatest')

        conn.exec_sql('truncate auxo_session')
        conn.exec_sql('truncate auxo_fkmapping_pqa_psqa')
        conn.exec_sql('truncate auxo_paperquestionanswer')
        conn.exec_sql('truncate auxo_paperanswer')
        conn.exec_sql('truncate auxo_papersubquestionanswer')
        conn.exec_sql('truncate auxo_uservideo')

    def test_monogo_conn(self):
        """
        清空 mongo数据库

        :return:
        """

        conn_str = 'mongodb://qa_mdb_learning_unit:1279F60M827J@172.24.133.60:34001,172.24.133.61:34001,172.24.133.62:34001/qa_mdb_learning_unit'

        conn_o = MgConn(conn_str)
        conn = conn_o.get_conn()

        db = conn['qa_mdb_learning_unit']

        db.drop_collection('LU_UserLearningSession')
        db.drop_collection('LU_LearningUnit')
        db.drop_collection('LU_UserLearningUnit')
