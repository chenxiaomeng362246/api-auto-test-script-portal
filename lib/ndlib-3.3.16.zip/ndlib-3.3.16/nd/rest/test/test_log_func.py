# coding=utf-8
from ..co_test.nd_case import NdCase
from ..logger.log_func import Logger

__author__ = 'linzh'


class LogFuncTest(NdCase):
    def setUp(self):
        pass

    def test_info(self):
        """
        case:

        :return:
        """
        logger = Logger("test02")
        logger.info("测试info")

    def test_no_tag(self):
        """

        :return:
        """
        logger = Logger()
        logger.info("没有tag")