# coding=utf-8
from cof.co_test.co_case import CoCase
from cof.co_test.nd_case import NdCase

__author__ = 'linzh'


class CaseTest(NdCase):
    def test_update(self):
        """

        :return:
        """
        case_id = "571de197763d0516383ed919"
        CoCase.CASE_ID = case_id
        case_o = CoCase()
        case_o.update(log_path="test")
        # case_o.save()
