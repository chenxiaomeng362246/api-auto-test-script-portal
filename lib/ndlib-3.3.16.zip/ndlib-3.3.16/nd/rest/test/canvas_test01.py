# coding=utf-8
from Tkinter import Canvas
from cof.co_gui.co_app import CoApp

__author__ = 'linzh'

import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(filename)s[%(lineno)d] %(levelname)s %(message)s')
logger = logging.getLogger(__name__)
logger.info(__name__)


class CanvasTest01(object):
    def __init__(self):
        pass

    def run(self):
        app = CoApp()
        root = app.get_root()

        canvas = Canvas(root)

        # 添加一个tag，并设置
        canvas.create_oval(1, 1, 26, 26, tag="oval")

        oval = canvas.find_withtag("oval")
        logger.info(oval)

        oval_type = canvas.type("oval")

        logger.info(oval_type)

        canvas.pack()

        root.mainloop()

def main():
    o = CanvasTest01()
    o.run()

if __name__ == '__main__':
    main()
