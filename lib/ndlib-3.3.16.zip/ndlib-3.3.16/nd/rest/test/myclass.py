# coding=utf-8
from cof.Singleton import Singleton

__author__ = 'linzh'


class MyClass(Singleton):
    def __init__(self):
        self.a = 3

