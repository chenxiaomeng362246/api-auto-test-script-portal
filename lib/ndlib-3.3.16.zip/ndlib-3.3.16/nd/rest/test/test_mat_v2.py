# coding=utf-8
from ..co_matrix.arr import CoMatrix
from ..co_test.nd_case import NdCase

__author__ = 'linzh'

"""
使用np.array实现的矩阵操作
"""


class MatTestV2(NdCase):
    def setUp(self):
        pass

    def test_det(self):
        """

        :return:
        """
        mt = CoMatrix([[1, 2], [3, 4]])
        print mt.det()

    def tearDown(self):
        pass
