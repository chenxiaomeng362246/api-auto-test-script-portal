# coding=utf-8
from ..co_test.nd_case import NdCase
from ..log import LogInfo

__author__ = 'linzh'


class LogInfoTest(NdCase):
    def setUp(self):
        pass

    def test_info(self):
        """
        case: 测试 log_info

        :return:
        """
        log_info = LogInfo()
