# coding=utf-8
from mongoalchemy.document import Document
from mongoalchemy.fields import StringField
from ..co_mongo.db_info import DbInfo
from ..co_mongo.mongo_db import MongoDb
from ..co_test.nd_case import NdCase
from ..logger.log_func import Logger

__author__ = 'linzh'

logger = Logger("Mongodb服务测试")


class TestDoc(Document):
    first_name = StringField()


class MongoTest(NdCase):
    def test_conn(self):
        """

        :return:
        """
        mongo_str = DbInfo.MongoStr

        logger.info(mongo_str)

        conn = MongoDb(mongo_str).get_conn()

        doc = TestDoc(first_name=u"测试标题")

        conn.save(doc)

    def test_auth_conn(self):
        """

        :return:
        """
        mongo_str = DbInfo.MongoAuthStr

        conn = MongoDb(mongo_str).get_conn()

        doc = TestDoc(first_name=u"测试标题")

        conn.save(doc)
