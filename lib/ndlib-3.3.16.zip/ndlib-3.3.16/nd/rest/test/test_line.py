# coding=utf-8
from ..co_plot.line import Line
from ..co_test.nd_case import NdCase

__author__ = 'linzh'


class LineTest(NdCase):
    def setUp(self):
        x = [1, 2, 3]
        y = [1, 2, 3]
        self.line_o = Line(x, y)

    def test_line(self):
        """

        :return:
        """
        self.line_o.draw()
