# coding=utf-8
from cof.co_test.nd_case import NdCase
from cof.co_vec.arr import CoVec

__author__ = 'linzh'


class VecTestV1(NdCase):
    def setUp(self):
        pass

    def test_new(self):
        """

        :return:
        """
        vec = CoVec([1, 2, 3])

    def test_sum(self):
        """

        :return:
        """
        vec = CoVec([1, 2, 3])
        print vec.sum()
