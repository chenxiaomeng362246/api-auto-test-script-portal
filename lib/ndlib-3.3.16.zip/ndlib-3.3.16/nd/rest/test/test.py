__author__ = 'Administrator'

import cof.co_file.file

# error
print cof.co_file.file.expand_links('./test.py')

print cof.co_file.file.expand_links('test.py')
print cof.co_file.file.expand_links('E:/temp/test.py')
print cof.co_file.file.expand_links('E:\\temp\\test.py')


print cof.co_file.file.get_app_loc()

print "hello"
