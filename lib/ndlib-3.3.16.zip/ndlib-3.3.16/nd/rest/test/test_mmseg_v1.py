# coding=utf-8
from ..co_mmseg.mmseg import Mmseg
from ..co_test.nd_case import NdCase

__author__ = 'linzh'


class MmsegV1Test(NdCase):
    def setUp(self):
        pass

    def test_seg(self):
        """

        :return:
        """
        # data = "中国人网龙测试test"
        data = """
        中国人网龙测试test
        中国人网龙测试test
        """

        mmseg_o = Mmseg()

        res = mmseg_o.seg(data)

        print res
