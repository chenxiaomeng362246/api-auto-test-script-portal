# coding=utf-8
from cof.co_test.nd_case import NdCase
from cof.log import LogInfo
from cof.logger.config import LogConfig


import logging
from cof.logger.scribe_logger import ScribeLogger

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(filename)s[%(lineno)d] %(levelname)s %(message)s')
logger = logging.getLogger(__name__)
logger.info(__name__)

__author__ = 'linzh'


class LogTest(NdCase):
    def setUp(self):
        pass

    def test_info(self):
        """
        case: 测试信息

        :return:
        """
        log_o = LogInfo()
        log_o.write("测试日志")

    def test_format(self):
        """
        case: 设置格式

        :return:
        """
        log_o = LogInfo()
        formatter = log_o.get_format()
        log_o.hdlr.setFormatter(formatter)

    def test_config(self):
        """
        case: 测试日志

        :return:
        """
        config_o = LogConfig()
        config_o.set_host("log.qa.huayu.nd")
        config_o.set_port(11215)

        LogConfig.set_def_host("log.qa.huayu.nd")

        logger.info(LogConfig.HOST)
        logger.info(config_o.get_host())

    def test_scribe(self):
        """
        case:

        :return:
        """
        logger1 = ScribeLogger()
        logger1.write(id(logger1))
        logger1.write("logger1")

        logger2 = ScribeLogger()
        logger2.write(id(logger2))
        logger2.write("logger2")

