# coding=utf-8

from Tkconstants import END, LEFT
from Tkinter import Button, Text
from ..co_gui.co_app import CoApp
from ..co_gui.co_frame import CoFrame
from ..thread import Thread
import tornado.ioloop
import tornado.web

__author__ = 'linzh'

"""
伪接口工具

"""

app = CoApp()

root = app.get_root()

text = Text(root)
text.pack()


sf = CoFrame(root)

f = sf.get_frame()


class Handler(tornado.web.RequestHandler):
    msg = ""

    def get(self):
        self.set_header("Content-Type", "application/json")
        print self.request.headers
        self.write(Handler.msg)

    def post(self):
        print self.request.headers
        print self.request.body
        self.write(Handler.msg)

    def put(self):
        self.write(Handler.msg)

    def delete(self):
        self.write(Handler.msg)

application = tornado.web.Application([(r"/v1/", Handler) ])

application.listen(8882)

class HttpIns(object):
    ins = None

def startTornado():
    # server = HTTPServer(application)
    # server.listen(8882)
    Handler.msg = text.get("1.0", END)
    if not HttpIns.ins:
        HttpIns.ins = tornado.ioloop.IOLoop.instance()

    HttpIns.ins.start()

def stopTornado():
    HttpIns.ins.stop()
    # HttpIns.ins.close(all_fds=True)
    HttpIns.ins = None

def start_srv_th():
    th = Thread(startTornado)

btn = Button(f, text="启动", command=start_srv_th)
btn.pack(side=LEFT)

def stop_all():
    # th = Thread(stopTornado)
    # stopTornado()
    stopTornado()

btn2 = Button(f, text="关闭", command=stop_all)
btn2.pack(side=LEFT)

def win_exit():
    # root.destroy()
    tornado.ioloop.IOLoop.instance().stop()
    tornado.ioloop.IOLoop.instance().close(all_fds=True)
    root.quit()

btn2 = Button(f, text="退出", command=win_exit)
btn2.pack()

root.mainloop()
