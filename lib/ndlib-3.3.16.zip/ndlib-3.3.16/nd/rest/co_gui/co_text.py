# coding=utf-8
from Tkconstants import END
import Pmw

__author__ = 'linzh'


class CoText(object):
    def __init__(self, master):
        self.text = Pmw.ScrolledText(master)
        self.text.pack()

        self.left = None
        self.right = None

    def place(self):
        self.text.place(relx=.5)

    def grid(self):
     self.text.grid(row=0)

    def set_left(self, pert):
        self.left = pert

    def set_right(self, pert):
        self.right = pert

    def position(self):
        self.text.place(relx=self.left, rely=self.right)

    def append(self, txt):
        self.text.insert(END, txt)

    def println(self, txt):
        self.append(txt + "\n")
