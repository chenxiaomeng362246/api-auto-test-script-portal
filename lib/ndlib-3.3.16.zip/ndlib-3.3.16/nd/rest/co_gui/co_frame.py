# coding=utf-8
from Tkconstants import BOTH, TRUE
import Pmw
from ..co_gui.co_app import CoApp

__author__ = 'linzh'


class CoFrame(object):
    def __init__(self, master, w=700, h=300):
        frame = self.frame = Pmw.ScrolledFrame(master, labelpos='n', label_text='测试可视化面板',
                                               usehullsize=1, hull_width=w, hull_height=h)

        frame.pack(fill=BOTH, expand=TRUE)

    def get_frame(self):
        return self.frame.interior()

    def add_ele(self, ele):
        ele.pack()


if __name__ == '__main__':
    from Tkinter import Button

    app = CoApp()

    root = app.get_root()

    frame = CoFrame(root)
    btn = Button(frame.get_frame())

    frame.add_ele(btn)

    root.mainloop()
