# coding=utf-8

__author__ = 'linzh'


class TextShape(object):
    def __init__(self):
        pass
