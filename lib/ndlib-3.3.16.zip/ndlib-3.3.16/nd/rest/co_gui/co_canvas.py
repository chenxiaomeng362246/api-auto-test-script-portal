# coding=utf-8
import Pmw

__author__ = 'linzh'


class CoCanvas(object):
    """
    画布

    支持滚动

    """
    def __init__(self, parent):

        self.sc = Pmw.ScrolledCanvas(parent,
                                     borderframe = 1,
                                     labelpos = 'n',
                                     label_text = 'ScrolledCanvas',
                                     usehullsize = 1,
                                     hull_width = 400,
                                     hull_height = 300,
                                     )

    def get_canvas(self):
        pass
