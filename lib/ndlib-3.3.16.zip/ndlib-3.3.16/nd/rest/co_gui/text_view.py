# coding=utf-8

__author__ = 'linzh'


class TextView(object):
    def __init__(self):
        pass
