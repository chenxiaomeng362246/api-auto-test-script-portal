# coding=utf-8

__author__ = 'linzh'

import Pmw

class CoEntry(object):
    def __init__(self, master):
        self.ent = Pmw.EntryField(master)
        self.ent.pack()
