# coding=utf-8

from Tkinter import Tk
import Pmw

__author__ = 'linzh'

class CoApp(object):
    def __init__(self, title="网龙QA", w=800, h=600):
        """
        创建一个客户端

        :param title:

        :return:

        .. code-block:: python

            >>> root = CoApp()
            >>> root.mainloop()

        """
        import os
        if os.name == 'nt':
            size = 16
        else:
            size = 12

        self.root = Tk()
        Pmw.initialise(self.root, size=size, fontScheme='pmw2')

        self.root.title(title)
        self.root.geometry(str(w) + "x" + str(h) + "+200+200")

    def set_ele(self):
        pass

    def get_root(self):
        """
        获取应用根元素

        .. code-block:: python

            >>> app = CoApp()
            >>> root = app.get_root()
            # 启动应用主循环
            >>> root.mainloop()

        运行效果:

        .. image:: co_app.png

        :return:
        """
        return self.root


if __name__ == '__main__':
    app = CoApp()
    root = app.get_root()
    root.mainloop()
