# coding=utf-8
from Tkinter import Label

__author__ = 'linzh'

class CoControl(object):
    def __init__(self, o):
        self.o = o

    def make_label(self):
        label = self.o.createcomponent('label', (), None,
                                          Label,
                                          (self.o.interior(),),
                                          text='Data Area')
        label.pack()

        return label
