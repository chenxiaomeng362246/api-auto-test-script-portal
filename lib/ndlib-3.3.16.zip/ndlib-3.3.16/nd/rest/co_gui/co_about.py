# coding=utf-8
import Pmw

__author__ = 'linzh'


class CoAbout(object):
    def __init__(self, master, appversion="v0.1", copyright="\n测试工具开发组＠ND.QA",
                 name="林志宏", phone="无",
                 email="cleardo@gmail.com", appname="测试工具"):

        self.about = Pmw.aboutversion(appversion)

        Pmw.aboutcopyright(copyright)

        Pmw.aboutcontact('更多信息，请联系: %s\n\n电话: %s\n\n邮箱: %s' % (name, phone, email))

        self.about = Pmw.AboutDialog(master, applicationname=appname)
        self.about.geometry("250x350+200+200")

    def dismiss(self):
        self.about.withdraw()

    def show(self):
        self.about.show()
        self.about.focus_set()


if __name__ == '__main__':
    from Tkinter import *
    root = Tk()
    root.withdraw()
    about = CoAbout(root)
    about.dismiss()
    about.show()
    root.mainloop()

