# coding=utf-8
import Pmw
from ..co_gui.co_app import CoApp

__author__ = 'linzh'


class CoWindow(object):
    def __init__(self, parent, title=u"网龙QA-TOPLEVEL"):
        self.win = Pmw.MegaToplevel(parent, title=title)
        self.top = self.win.interior()
        self.top.geometry("800x600+200+200")


if __name__ == '__main__':

    app = CoApp()

    root = app.get_root()

    CoWindow(root)

    root.withdraw()

    root.mainloop()


