# coding=utf-8

__author__ = 'linzh'


class CoCircle(object):
    def __init__(self, canvas, color="green"):
        self.cv = canvas
        self.color = color

    def make(self, x, y, r):
        self.cv.create_oval(x - r, y - r, x + r, y + r, fill=self.color)

if __name__ == '__main__':
    from Tkconstants import BOTH, YES
    from Tkinter import Canvas
    from ...co_gui.co_app import CoApp

    app = CoApp()
    root = app.get_root()
    canvas = Canvas(root, width=300, height=300, bd=2)
    canvas.pack(fill=BOTH, expand=YES)

    tri = CoCircle(canvas)
    tri.make(50, 50, 10)

    root.mainloop()
