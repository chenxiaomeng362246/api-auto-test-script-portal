# coding=utf-8

import os
from co_os import OsInfo      # laibaoyu
from co_file import file as cofFile       # laibaoyu

__author__ = 'linzh'


class NdPath(object):
    """
    路径解析
    """
    def __init__(self):
        self.path = os.path.dirname(__file__) + os.sep + '..' + os.sep
        pass

    #@staticmethod
    def get_jlib_path(self):
        """
        获取jlib路径

        md5.jar:
        token.jar

        :return:
        """
        # return nd.__path__[0] + os.sep + 'jlibs' + os.sep
        return self.path + 'jlibs' + os.sep


def search_project_root_path(path, file_name='cfgtype.ini'):
    """
    通过解析调用文件的路径,获取工程根目录
    只会判断2级结构
    如http.py文件
    1级：
    api_call
    --http.py
    2级：
    api_call
    --xxxx
      --http.py
    :param
    path：http.py文件路径
    file_name：需要判断的文件名，默认每个工程的根路径下都会有cfgtype.ini文件
    :return: 工程根路径
    """
    path = os.path.dirname(path)
    # path_list = [path + os.sep + '..' + os.sep, path + os.sep + '..' + os.sep + '..' + os.sep]
    path_list = [path + os.sep + '..' + os.sep,
                 path + os.sep + '..' + os.sep + '..' + os.sep,
                 path + os.sep + '..' + os.sep + '..' + os.sep + '..' + os.sep]
    isExist = False
    ex_path = ""

    if os.path.exists(cofFile.expand_links(path + os.sep + file_name)):
        return path

    for temp in path_list:
        if os.path.exists(cofFile.expand_links(temp + file_name)):
            isExist =True
            ex_path = temp
            break
    if not isExist:
        print "The root path of the project is not found：" + ex_path
        raise Exception("查找不到工程根路径: " + path)
    else:
        if OsInfo.is_windows():
            return unicode(ex_path, "gbk")
        else:
            return ex_path


