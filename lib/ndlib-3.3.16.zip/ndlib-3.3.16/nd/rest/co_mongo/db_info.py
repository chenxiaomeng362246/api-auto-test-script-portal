# coding=utf-8
#from ..conf import get_cfg_type

__author__ = 'linzh'

cfg_type = 'test'


class DbInfo(object):
    if cfg_type == "development":
        # MongoStr = "mongodb://dev_mdb_aaaaaaa:x57OV5974M4U@172.24.133.23:34001,172.24.133.24:34001,172.24.133.25:34001/dev_mdb_aaaaaaa"
        # MongoStr = "mongodb://dev_mdb_aaaaaaa:x57OV5974M4U@172.24.133.23:34001"
        MongoStr = "mongodb://test_db@192.168.19.97:27017"

        MongoDev = {
            "host": "192.168.19.162",
            "port": 27017
        }
    else:
        MongoStr = "mongodb://dev_mdb_qa_demo:eCwSzkb3cawt@172.24.133.23:34001,172.24.133.24:34001,172.24.133.25:34001/dev_mdb_qa_demo?autoConnectRetry=true"
        MongoDev = {
            "host": "192.168.19.97",
            "port": 27017
        }


