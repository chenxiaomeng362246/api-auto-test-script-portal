# coding=utf-8

from mongoalchemy.session import Session

__author__ = 'linzh'

class MongoDb(object):
    def __init__(self, conn_str):
        self.session = Session.connect(conn_str)

    def get_conn(self):
        return self.session
