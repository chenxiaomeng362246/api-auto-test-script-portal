# coding:utf-8

import xlsxwriter

class XlsxWriter_():
	def __init__(self):
		self.workbook = None
		self.worksheet = None
		self.cell_format = None
		self.chart = None

	def creatFile(self,newfile):
		self.workbook = xlsxwriter.Workbook(newfile,
											{'strings_to_numbers':True,'strings_to_formulas':True,
											'strings_to_urls':True,'strings_to_datetimes':True})
	def	addWorkSheet(self,sheetname):
		self.worksheet = self.workbook.add_worksheet(sheetname)
		return self.worksheet

	def mergeCell(self,row_col,celldata,merge_format):
		self.worksheet.merge_range(row_col,celldata,merge_format)
	def setColFormat(self,col_col,colwidth,cell_format=None,boolean=False):
		self.worksheet.set_column(col_col,colwidth,cell_format,{"hidden":boolean})	
	def setRowFormat(self,row,height,cell_format,boolean):
		"""1、hidden处理该行数据是否隐藏"""
		self.worksheet.set_row(row,height,cell_format,{"hidden":boolean})
	def addCellFormat(self,font,fontsize,color,bold,center,bg_color,wrap=1):
		"""1、return解决格式复用问题"""
		self.cell_format = self.workbook.add_format({
			"font_name":font,
			"font_size":fontsize,
			"font_color":color,
			"bold":bold,
			"border":1,
			"align":center,
			"valign":"vcenter",
			"bg_color":bg_color,
			"text_wrap":wrap})
		return self.cell_format

	def addChartFormat(self,sheetname,charttype,x_row1,x_col1,x_row2,x_col2,y_row1,y_col1,y_row2,y_col2,title_name,title_namefont,x_title,y_title,y_max,x_width,y_height,showpercent=True,showcategory=False,showvalues=False,y_axis_percent="0%"):
		"""

		1、add_series的data_labels显示图表内容标签;2、set_y_axis的num_format以百分比显示y轴数据,max限制y轴最大值;
		3、show_hidden_data显示隐藏数据,不加隐藏数据显示不了"""
		self.chart = self.workbook.add_chart({
			"type":charttype
			})
		self.chart.add_series({
			"categories":["%s"%sheetname,x_row1,x_col1,x_row2,x_col2],
			"values":["%s"%sheetname,y_row1,y_col1,y_row2,y_col2],
			#"fill":{"color":chartcolor}
			"data_labels":{"percentage":showpercent,"position":"center","category":showcategory,"value":showvalues}
			})
		self.chart.set_title({
			"name":title_name,
			"name_font":{"name":title_namefont},
			})
		self.chart.set_x_axis({
			"name":x_title,
			"name_font":{"name":title_namefont},
			})
		self.chart.set_y_axis({
			"name":y_title,
			"name_font":{"name":title_namefont},
			"num_format":y_axis_percent,
			"max":y_max
			})
		self.chart.show_hidden_data()
		self.chart.set_size({
							"width":x_width,
							"height":y_height,
							})
		return self.chart
	def setSheetChart(self,cell,chart):
		self.worksheet.insert_chart(cell,chart)

	def writeCell(self,cell,celldata,cell_format=None):
		if cell_format is None:
			cell_format = self.workbook.add_format({'bold': 1})

		self.worksheet.write(cell,celldata,cell_format)

	def writeRowCell(self,row,rowdata,row_format):
		self.worksheet.write_row(row,rowdata,row_format)

	def writeColCell(self,col,coldata,col_format):
		self.worksheet.write_column(col,coldata,col_format)

	def writeCellUrl(self,cell,url,url_format,celldata,tip):
		self.worksheet.write_url(cell,url,url_format,celldata,tip)

	def addSheetImage(self,cell,imagedir,x_off,y_off,x_percent,y_percent):
		"""
		插入图片

		:param cell:
		:param imagedir:
		:param x_off:
		:param y_off:
		:param x_percent:
		:param y_percent:
		:return:
		"""
		self.worksheet.insert_image(cell,imagedir,{
			"x_offset":x_off,
			"y_offset":y_off,
			"x_scale":x_percent,
			"y_scale":y_percent
			})
	def close(self):
		self.workbook.close()


if __name__ == '__main__':
	writer = XlsxWriter_()
	writer.creatFile("demo.xlsx")
	writer.addWorkSheet("sheet 1")
	writer.writeCell("A1", "abc")
	writer.close()

