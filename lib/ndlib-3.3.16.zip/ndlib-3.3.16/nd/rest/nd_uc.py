# coding=utf-8
import json
import subprocess
import hashlib
from .http import Http

import logging
logging.basicConfig(level=logging.INFO)
logger_o = logging.getLogger(__name__)
logger = logging.getLogger(__name__)
logger.info("接口测试框架")

import os
import time
from .nd_path import NdPath
import http as cofHttp
from proc import CoProc
import restful as CoRestful
import re

nd_path_o = NdPath()


class UcEnv:
    ol = 1
    pre = 2
    aws = 3
    awsca = 4
    wjt = 5
    snwjt = 6
    hk = 7

def get_beijing_time(utc_time):
    """
    根据iso时间获取北京时间
    utc_time 评价的创建时间，utc格式，'2015-12-28T03:05:56.000+0000'
    """
    real_time = utc_time[:-9]
    time_array = time.strptime(real_time, "%Y-%m-%dT%H:%M:%S")
    time_stamp = int(time.mktime(time_array))

    beijing_time_stamp = time_stamp + 60 * 60 * 8
    # beijing_time_stamp = time_stamp
    beijing_time = time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(beijing_time_stamp))

    return beijing_time


def get_md5_pw(password):
    """
    根据uc的算法，对密码加密
    """
    # p = os.path.abspath(__file__)
    # p = os.path.dirname(p)
    md5_jar = nd_path_o.get_jlib_path() +  'md5.jar'

    cmd = 'java -jar ' + md5_jar + ' %s' % password

    res = CoProc().run(cmd)
    return res['result'][:-2]

class NdUc(object):
    # UC登录版本默认为0.93
    def __init__(self, env=UcEnv.ol, uc_version='0.93', uc_header=None):
        self.uc_version = str(uc_version)
        sdp_header = dict()
        self.sdp_header = dict()
        self.auth_header_switch = ''
        self.header = {
            "Content-Type": "application/json"
        }
        self.env = env
        self.port = None
        if self.uc_version == '0.93':
            if self.env == UcEnv.hk:
                self.host = "uchk.101.com"
            elif self.env == UcEnv.snwjt:
                self.host = "uc.sneduyun.com.cn"
            elif self.env == UcEnv.wjt:
                self.host = "ucwjt.101.com"
            elif self.env == UcEnv.ol:
                self.host = "aqapi.101.com"
            elif self.env == UcEnv.pre:
                self.host = "ucbetapi.101.com"
            elif self.env == UcEnv.aws:
                self.host = "awsuc.101.com"
            elif self.env == UcEnv.awsca:
                self.host = "uc-awsca.101.com"
        elif self.uc_version == '1.0':
            if self.env == UcEnv.hk:
                self.host = "ahk.101.com"
            elif self.env == UcEnv.snwjt:
                self.host = "a.sneduyun.com.cn"
            elif self.env == UcEnv.wjt:
                self.host = "awjt.101.com"
            elif self.env == UcEnv.ol:
                self.host = "a.101.com"
            elif self.env == UcEnv.pre:
                self.host = "authbeta.101.com"
            elif self.env == UcEnv.aws:
                self.host = "awsauth.101.com"
            elif self.env == UcEnv.awsca:
                self.host = "awscaauth.101.com"

            sdp = re.compile(ur'(^sdp-(\S)+)')
            for key, value in self.uc_header.items():
                if sdp.match(key):
                    self.sdp_header[key] = value
                    self.header[key.upper()] = value
                elif key == 'auth-header-switch':
                    self.auth_header_switch = value
                else:
                    self.header[key] = value

        else:
            raise Exception("UC认证服务版本未传或者指定有误！")

        # 目前，uc的生产、预生产环境，都使用https协议
        if self.env in [UcEnv.ol, UcEnv.pre, UcEnv.aws, UcEnv.awsca, UcEnv.wjt, UcEnv.snwjt, UcEnv.hk]:
            self.is_ssl = True
        else:
            self.is_ssl = False

        self.http_obj = cofHttp.Http(host=self.host, port=self.port, ssl=self.is_ssl)
        self.http_obj.set_header(self.header)

    def set_host(self, host):
        """
        自定义设置账号中心主机
        :param host:
        :return:
        """
        self.host = host

    def set_port(self, port):
        """
        自定义设置账号中心端口
        :param port:
        :return:
        """
        self.port = port

    def set_version(self, version):
        """
        自定义设置账户中心的api版本号
        :param version:
        :return:
        """
        self.version = version

    @staticmethod
    def get_password_md5(passwd):
        """

        该函数用于获取加密过的密码

        :param passwd: 要加密的明文密码

        :return:

        调用DEMO

        .. code-block:: python
            :linenos:

            >>> from nd_uc import NdUc
            >>> nd_uc_o = NdUc()
            >>> password_md5 = nd_uc_o.get_password_md5('123456')
            >>> print password_md5

        这里的password_md5就是加密后的密码了

        """
        passwd = passwd.replace('`', '\`')
        passwd = passwd.replace('\'', '\\\'')
        passwd = passwd.replace('"', '\\\"')
        logger.info('明文密码:' + passwd)

        # jlib_path = nd_path_o.get_jlib_path()
        #
        # md5_jar_path = jlib_path + 'md5.jar'
        #
        # logger.info(md5_jar_path)
        #
        # # command = 'java -jar ' + md5_jar_path + ' \'%s\'' % passwd
        # # command = 'java -jar ' + md5_jar_path + ' `echo $\'%s\'`' % passwd
        # command = 'java -jar "' + md5_jar_path + '" \"%s\"' % passwd
        # logger.info(command)
        #
        # proc = subprocess.Popen(command, stderr=subprocess.PIPE, stdout=subprocess.PIPE, shell=True)
        #
        # error = proc.stderr.read()
        #
        # if error:
        #     logger.info("发生错误：" + error)
        #
        # passwd_md5 = proc.stdout.read()
        #
        # logger.info(passwd_md5)
        #
        # return passwd_md5.strip()

        # add laibaoyu  更新md5加密采用python计算，不在用jar计算
        hex_str = "a3aca1a3"  # UC 固定的插值 16进制字符byte：163 172 161 163
        salt = 'fdjf,jkgfkl'  # UC 固定的的salt值
        bt = []
        for i in range(0, len(hex_str), 2):
            b = hex_str[i:i + 2]
            bt.append(chr(int(b, 16)))
        btmd5 = ''.join(bt)
        md5_input = str(passwd) + btmd5 + salt
        # 创建md5对象
        hl = hashlib.md5()
        hl.update(md5_input)
        passwd_md5 = hl.hexdigest()
        logger.info('密文密码:' + passwd_md5)

        return passwd_md5

    def get_server_time(self):
        """
        获取服务器时间

        :return:

        .. code-block:: python
            :linenos:

            >>> serv_time = get_server_time()
        """
        http_o = Http(self.host, self.port, ssl=self.is_ssl)

        res = http_o.get('/v' + str(self.uc_version) + '/server/time')

        res = res['data']

        res = json.loads(res)

        return res['server_time']

        # -------------- 生成mac token ----------------- #

    def get_mac_content(self, url, method, host):
        """
        :name 获取Authorization - os方法
        :param
        #.  id token
        #.  time 2014-12-24T12:23:12Z 时间
        #.  host 访问的域名（非默认端口号时，需要加上端口号）
        #.  method  获取方法
        注：一般没生成authorization，是因为没有事先登录，获取token
        """
        token_id = self.access_token

        server_time = self.get_server_time()
        server_time = server_time.encode('UTF-8')  # 2017-06-06T10:09:02.048+0000
        if self.env in [UcEnv.aws, UcEnv.awsca]:
            server_time = get_beijing_time(server_time)  # 加8小时

        p = os.path.abspath(__file__)
        p = os.path.dirname(p)
        tok_jar = p + os.sep + 'token.jar'

        # 调用jar[命令跟dos下一样]
        url = url.replace('$', '*')
        # print "------------------ begin jar"
        cmd = 'java -jar ' + tok_jar + ' %s %s %s %s "%s" %s' % (
            token_id, server_time, host, method, url, self.mac_key
        )
        # print "------------------ end jar"
        print cmd

        res = CoProc().run(cmd)
        authorization = res['result'][:-2]

        logger.info(cmd)
        logger.info(authorization)
        logger.info("获取token命令")

        return authorization

    def login(self, login_name, password, org_name, has_encoded=False):
        """
        4.1.3 用户登陆
        {
            "login_name":"", --用户名或手机号或工号
            "password":"", --密码(加密算法由uc_sdk提供)
            "org_name":"", --组织登录名称(可选)
        }
        """
        nd_uc_o = NdUc()

        if has_encoded is False:  # 未加密
            md5_pw = nd_uc_o.get_password_md5(password)
        else:  # 已加密
            md5_pw = password

        json_data = {
            "login_name": login_name,
            "password": md5_pw,
            "org_name": org_name
        }

        param = json.dumps(json_data)

        self.http_obj.set_header(self.header)
        url = '/v' + str(self.version) + '/tokens'
        response = self.http_obj.post(url, param)

        return response

    def get_token(self, user, password, org='', url='', method='', host='', has_encoded=False):
        """
        用户登录，获取mac token
        :param user:用户名
        :param password:密码
        :param org:组织，无组织可不传
        :param url:请求的相对url，如 '/user'
        :param method:请求方法，如 'GET'
        :param host:请求的host，不是指uc的host
        :param has_encoded:密码是否已加密
        :return:登录后获取到的token
        """
        # 1.登录
        response = self.login(user, password, org, has_encoded)
        data_dict = self.rest_o.parse_response(response, 201, '用户登陆失败')

        logger.info("登录信息")
        logger.info(data_dict)

        # 2.获取身份信息
        self.user_id = data_dict['user_id']
        self.access_token = data_dict['access_token']
        self.mac_key = data_dict['mac_key']

        if len(url) == 0:
            raise Exception("url不能为空")

        if len(method) == 0:
            raise Exception("http method不能为空")

        mac_token = self.get_mac_content(url, method, host)

        logger.info("MAC TOKEN")
        logger.info(mac_token)

        return mac_token

        # -------------- 生成bearer token ----------------- #

    def server_login(self, username, password=None, has_encoded=False):
        """
        4.1.14 服务端登录
        {
            "username"：用户名或手机号
            "password"：密码     【使用后台配置好的密码，如下代码所写】
        }
        注：服务端登录没有对应的退出
        """
        nd_uc_o = NdUc()

        if has_encoded is False:
            md5_pw = nd_uc_o.get_password_md5(password)
        else:
            md5_pw = password

        json_data = {
            "login_name": username,
            "password": md5_pw
        }
        param = json.dumps(json_data)

        url = "/v0.93/bearer_tokens"
        response = self.http_obj.post(url, param)
        return response

    def get_bearer_token(self, user_name='', password='', has_encoded=False):
        """
        通过服务端登录，获取bearer token
        :param user_name: 用户名
        :param password: 密码
        :param has_encoded: 密码是否已加密
        :return:登录返回的bearer token
        """
        response = self.server_login(user_name, password, has_encoded)
        data_dec = CoRestful.Restful().parse_response(response, 201, "服务端登录失败")

        return data_dec['access_token']