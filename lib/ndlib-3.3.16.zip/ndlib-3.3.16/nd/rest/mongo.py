# coding=utf-8

"""
用于访问mongodb数据库

.. doctest:: 

    >>> mg_conn = MongodbConn('192.168.9.105', 27317)
    >>> mg_conn.set_coll('metis_test', 'sys_log')
"""
from bson.objectid import ObjectId

__author__ = 'linzh'
import pymongo


class MongodbConn(object):
    """
    创建一个到mongodb数据库的连接
    """

    is_cleaned = False

    def __init__(self, host=None, port=None):
        """创建一个到数据库的连接
        :Parameters:
            - `host`:主机名

        .. versionadded:: 1.1.0
           添加清库支持
        """
        self.host = host
        self.port = int(port)
        self.mg_db = None
        self.mg_coll = None
        self.conn = pymongo.Connection(host, self.port, network_timeout=1)
        self.db = None
        self.coll = None

    def set_coll(self, mg_db, mg_coll):
        """
        设置数据库和表名
        """
        self.mg_db = mg_db
        self.mg_coll = mg_coll
        self.db = self.conn[self.mg_db]
        self.coll = self.db[self.mg_coll]

    def add(self, data):
        oid = self.coll.insert(data)
        return str(oid)

    def update(self, oid, data_update):
        return self.coll.update({'_id': ObjectId(oid)}, {'$set': data_update})

    def clear(self):
        self.coll.remove()

    def find_one(self, cond):
        return self.coll.find_one(cond)

    def auth(self, user, password):
        """

        :param user:
        :param password:
        :return:
        """
        client = list()
        database = self.conn
        client.append(database)
        return client[database].authenticate(user, password)


if __name__ == "__main__":
    print "start..."

    import conf.conf as CoConfM
    import rand as CoRandM

    rand_o = CoRandM.CoRand()
    conf_o = CoConfM.MyCfg("cfg.ini")
    conf_o.set_section("mongo")
    host = conf_o.get("host")
    port = conf_o.get("port")

    mg_conn = MongodbConn(host, port)
    mg_conn.set_coll("qa_pms", "bug")

    data = {
        "bug_uuid": rand_o.uuid()
    }

    mg_conn.add(data)
