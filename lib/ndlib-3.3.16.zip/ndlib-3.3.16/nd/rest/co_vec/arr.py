# coding=utf-8
from array import array

__author__ = 'linzh'


class CoVec(object):
    def __init__(self, l=None):
        """
        强类型一维数组

        :param l:
        :return:
        """
        if l is None:
            l = [1, 2, 3]
        self.vec = array('i', l)

    def scale(self):
        pass

    def sum(self):
        return self.vec
