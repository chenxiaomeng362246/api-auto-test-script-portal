# coding=utf-8
import json
import os

import logging
from tornado.escape import json_decode

logging.basicConfig(level=logging.INFO)
logger_o = logging.getLogger(__name__)

#from ..logger.log_func import Logger
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
# logger = Logger("接口测试框架-测评组件-" + __name__)
logger.info("接口测试框架-测评组件-" + __name__)

__author__ = 'linzh'

from ..http import Http


class NdCs(object):
    def __init__(self):
        self.host = "cs.101.com"
        # self.host = "uploadcs.101.com"
        self.header = dict()
        self.header['Content-Type'] = 'application/json'

        self.service_name = "lsx_test_0529"
        self.service_id = "ae1acb78-8345-433b-ac31-8baf130d0b03"

        self.file_path = ""

        self.uid = "10003732"

    def set_host(self, host):
        self.host = host

    def set_uid(self, uid):
        """

        :param uid:
        :return:
        """
        self.uid = uid

    def get_session(self, dev_uid=None, role="admin", expires=3000):
        """
        1.7.1 获取session
        参数：
        {
          "path":"/example/album",                             //授权的路径（包含子目录项） 必选
          "service_id":"cbeb188a-9f56-41ce-9a32-9f4b63583d6c"  //服务Id(UUID)               必选
          "uid":777,                                           //被授权的用户的uid          必选
          "role":"user",                                       //用户角色                   必选
          "expires":100                                        //session过期时间(秒)        可选
        }

        响应：

        SESSION

        """
        from ..nd_uc import NdUc
        nd_uc_o = NdUc()

        if not dev_uid:
            dev_uid = self.uid

        bearer_token = nd_uc_o.get_bearer_token('waf_loginer', '123456')

        self.header["Authorization"] = "Bearer %s" % bearer_token

        self.parameter = dict()
        self.parameter["path"] = "/" + self.service_name

        self.parameter["service_id"] = self.service_id

        self.parameter["uid"] = dev_uid
        self.parameter["role"] = role
        self.parameter["expires"] = expires

        param = json.dumps(self.parameter)

        http_o = Http(self.host)

        http_o.set_header(self.header)

        response = http_o.post("/v0.1/sessions", param)

        data = response['data']

        data_dec = json.loads(data)

        return data_dec

    def upload_files(self, session, dentry_id, file_path, parent_id, dest_path, file_name, other_name, info, md5,
                     meta_json, scope, mime, chunks, chunk, chunk_size, pos, expire_days, open_file_name=""):
        """
        1.8.1 文件上传
        参数：
        {
            "dentryId":"96340084-775d-4740-ae2f-b2dea283218a",       //如果有传此项，将会覆盖旧文件数据
                                                                     //dentryId和filePath二选一 覆盖上传时不用传parentId，path，name
            "filePath":"/example/ablum/777/name.zip"                 //如果有传此项，将会覆盖旧文件数据，
                                                                     //dentryId和filePath二选一 覆盖上传时不用传parentId，path，name

            "parentId":"96340084-775d-4740-ae2f-b2dea289618b",       //父目录项id（UUID），parentId 和 path 二选一
            "path":"/example/album/777",                             //文件存放的路径(支持自动创建目录)，parentId 和 path 二选一

            "name":"name.zip",                                       //文件名，包括后缀名(支持重命名) 必选
            "otherName":"xxx",                                       //备注名，可选

            "infoJson":{                                             //自定义元数据(Json格式)，
                "a":1,                                               //如：{tags:[xx,xx],title: xx, note: xx, content: xx}
                "b":2                                                //可选 传入要用字符串形式
            },

            "md5":"a587097e7b308954a7f8ea9e3b7405c6",                //整个文件的MD5码，文件秒传时必选

            "metaJson":{                                             //图片，音频，视频等元数据： {width: 1024, height: 768} ，
                "width": 1024,                                       //可选  传入要用字符串形式
                "height": 768
            },

            "scope":1,                                               //0-私密，1-公开，默认：0，可选

            "mime":"image/jpeg",                                     //文件mime                可选

            "size":1024,                                             //文件大小，分块上传时    必选
            "chunks":1,                                              //分块上传的块数量，可选，默认：1
            "chunk":1,                                               //当前上传的分块chunkId(注：从0开始)，可选

            "chunkSize":1204,                                        //当前分块大小   可选

            "pos":0,                                                 //分块偏移量   可选

            "expireDays":1                                           //过期天数，0-永不过期，可选，默认：0
        }

        响应：

        分块上传成功
        {
            "1":{ pos:0, size:128 },                   //分块ID:{偏移量,分块大小}
            "2":{ pos:128, size:512 },                 //分块ID:{偏移量,分块大小}
            ...
        }

        文件上传成功：最后一块的响应信息是dentry结构的数据
        DENTRY

        注：上传文件后，会文件存在gridFs 则flag=2，然后定时推送到S3后flag才变成1
        """
        if open_file_name == "":
            open_file_name = file_name

        file_name_path = self.file_path + open_file_name

        # url = "http://" + self.host + "/v0.1/upload"
        url = "/v0.1/upload"

        if session != "":
            url += "?session=" + session

        params = dict()

        if dentry_id != "":
            params["dentryId"] = dentry_id
        if file_path != "":
            params["filePath"] = file_path
        if parent_id != "":
            params["parentId"] = parent_id
        if dest_path != "":
            params["path"] = dest_path

        params["name"] = file_name

        if other_name != "":
            params["otherName"] = other_name

        if info != "":
            info_json = {"tags": info}
            info = json.dumps(info_json)
            params["infoJson"] = info

        if md5 != "":
            params["md5"] = md5

        if meta_json != "":
            params["metaJson"] = meta_json

        params["scope"] = scope

        if mime != "":
            params["mime"] = mime

        size = os.path.getsize(file_name_path)
        logger.info("文件大小")
        logger.info(size)

        params["size"] = size

        if chunks != "":
            params["chunks"] = chunks
        if chunk != "":
            params["chunk"] = chunk
        if chunk_size != "":
            params["chunkSize"] = chunk_size

        if pos != "":
            params["pos"] = pos

        params["expireDays"] = expire_days

        logger.info(file_name_path)

        file_o = open(file_name_path, "rb")

        params["fileUpload"] = file_o

        self.file_size = os.path.getsize(file_name_path)

        http_obj = Http(self.host)
        response = http_obj.upload_files(url, file_name_path, params)

        return response

    def set_file_path(self, file_path):
        self.file_path = file_path

    def upload_html(self, session, path, file_name):
        """
        上传html文件

        :param session:

        :param file_name: 文件名，上传的文件名

        :param path: 路径，指定文件保存的父目录

        .. code-block:: python
            :linenos:

            >>> from cof.nd_cs import NdCs
            >>> nd_cs_o = NdCs()
            >>> nd_cs_o.set_file_path(file_path)
            >>> session = nd_cs_o.get_session('10003732')
            >>> nd_cs_o.upload_html(session['session'], cs_path, file_name)

        """

        response = self.upload_files(
            session=session, dentry_id="", file_path="", parent_id="", dest_path=path,
            file_name=file_name, other_name="", info="", md5="", meta_json="", scope=1,
            mime="", chunks="", chunk="", chunk_size="", pos="", expire_days=0
        )

        return response

    def upload_png(self, session, path, file_name):
        """
        上传html文件

        :param session:

        :param file_name: 文件名，上传的文件名

        :param path: 路径，指定文件保存的父目录

        .. code-block:: python
            :linenos:

            >>> from cof.nd_cs import NdCs
            >>> nd_cs_o = NdCs()
            >>> nd_cs_o.set_file_path(file_path)
            >>> session = nd_cs_o.get_session('10003732')
            >>> nd_cs_o.upload_html(session['session'], cs_path, file_name)

        """

        response = self.upload_files(
            session=session, dentry_id="", file_path="", parent_id="", dest_path=path,
            file_name=file_name, other_name="", info="", md5="", meta_json="", scope=1,
            mime="", chunks="", chunk="", chunk_size="", pos="", expire_days=0
        )

        data = response['data']
        response = json_decode(data)

        return response


if __name__ == '__main__':
    cs_o = NdCs()
    uid = "10003732"
    session_info = cs_o.get_session(uid)
    cs_o.set_file_path('/home/linzh/ndwork/workspace/py/cleardo_framework_v2.0/tests/')
    cs_o.upload_html(session_info['session'], session_info['path'], 'report.html')
    cs_o.upload_html(session_info['session'], session_info['path'], 'pic.png')

    logger.info('http://cdncs.101.com/v0.1/' + session_info['session'] + '/static' + session_info['path'] + '/report.html')

    # http://cdncs.101.com/v0.1/2cbee96b-e1c3-4693-8c21-9e8341facdc6/static/lsx_test_0529/report.html
    # http://cdncs.101.com/v1.0/ea3ef571-8b80-4a57-ab88-eb4f688a0b16/static/lsx_test_0529/report.html
