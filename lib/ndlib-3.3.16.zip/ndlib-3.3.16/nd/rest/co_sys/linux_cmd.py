# coding=utf-8

__author__ = 'linzh'


class LinuxCmd(object):
    def __init__(self):
        pass

    def get_find_cmd(self):
        return "grep"
