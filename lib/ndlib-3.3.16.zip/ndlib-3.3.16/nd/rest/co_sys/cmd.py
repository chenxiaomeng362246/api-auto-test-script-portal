# coding=utf-8
from ..co_os import OsInfo
from ..co_sys.linux_cmd import LinuxCmd
from ..co_sys.win_cmd import WinCmd
from ..logger.log_func import Logger

__author__ = 'linzh'

logger = Logger("基础测试框架-" + __name__)


class CoCmd(object):
    def __init__(self):
        """

        :return:
        """
        if OsInfo.is_linux():
            self.cmd_o = LinuxCmd()
        else:
            self.cmd_o = WinCmd()

    def get_find_cmd(self):
        return self.cmd_o.get_find_cmd()
