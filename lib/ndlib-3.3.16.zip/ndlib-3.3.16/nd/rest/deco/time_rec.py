# coding=utf-8

__author__ = 'linzh'

def time_rec():
    pass
