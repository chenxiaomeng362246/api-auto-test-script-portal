# coding=utf-8

from ..co_time.co_time import CoTime
from ..logger.log_func import Logger
from functools import update_wrapper

__author__ = 'linzh'

logger = Logger("接口函数调用")


def log_seq(f):
    """
    函数复合

    :param f:
    :return:
    """
    def wrapped_function(*args, **kwargs):
        time_o = CoTime()
        logger.info(time_o.iso8601())
        logger.info(f)

        f(*args, **kwargs)

        logger.info(time_o.iso8601())
        logger.info("调用结束")

    return update_wrapper(wrapped_function, f)


if __name__ == '__main__':

    @log_seq
    def test_func(a):
        print "test_func"
        print a

    test_func(2)
