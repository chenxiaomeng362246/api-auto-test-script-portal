# coding=utf-8


__author__ = 'yxy'
#import rms.login as LoginM


class Singleton(object):
    """
    饿汉式单实例实现
    """
    def __new__(cls, *args, **kw):
        if not hasattr(cls, '_instance'):
            orig = super(Singleton, cls)
            cls._instance = orig.__new__(cls, *args)
        return cls._instance
#
#class Jsession(Singleton):
#    def __init__(self):
#        self.login_o = LoginM.Login()
#        res = self.login_o.login()
#        self.jsessionid = res['jsession']
#
#    def get_jsession(self):
#        return self.jsessionid
#
#    def set_new_jsession(self, user, pwd):
#        if user == "":
#            res = res = self.login_o.login()
#        else:
#            res = self.login_o.login(user, pwd)
#        self.jsessionid = res['jsession']
#
#class MyClass(Singleton):
#    def __init__(self):
#        self.a = 3
#
#one = Jsession()
#two = Jsession()
#
##two.a = 3
##print one.a
##3
##one和two完全相同,可以用id(), ==, is检测
#print id(one)
#
#print id(two)