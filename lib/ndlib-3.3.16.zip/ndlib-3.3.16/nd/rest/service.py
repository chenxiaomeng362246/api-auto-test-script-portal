# coding=utf-8
from tornado.escape import json_decode, json_encode

__author__ = 'linzh'

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.info(__name__)


from .http import Http


class Service(object):
    def __init__(self):
        self.host = "plot.qa.sdp.nd"
        self.http_o = Http(self.host)
        self.version = "1.0"

    def get_url(self):
        return '/api/v' + self.version + '/'

    def post(self, url_in, data):
        url = self.get_url() + url_in
        res = self.http_o.post(url, data)
        logger.info(res)
        data_dec = json_decode(res['data'])
        return data_dec

    def get(self, url_in):
        url = self.get_url() + url_in
        res = self.http_o.get(url)
        data_dec = json_decode(res['data'])
        return data_dec

    def send_test(self, data):
        url = 'api-test'
        data = json_encode(data)
        self.post(url, data)
