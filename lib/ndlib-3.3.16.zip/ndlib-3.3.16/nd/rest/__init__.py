# coding=utf-8
version_tuple = (2, 7)


def co_init():
    import sys
    reload(sys)
    sys.setdefaultencoding('utf-8')


def get_version_string():
    return "1.1.0"


version = get_version_string()
"""cof框架的当前版本"""


def has_mongo_ext():
    """是否添加了pymongo扩展

    .. versionadded:: 1.0.0
    """
    return True
