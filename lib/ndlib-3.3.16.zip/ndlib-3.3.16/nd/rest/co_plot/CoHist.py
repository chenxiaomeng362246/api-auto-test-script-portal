# coding=utf-8

__author__ = 'linzh'

import matplotlib.pyplot as plt


class CoHist(object):
    def __init__(self):
        self.data = [2, 3, 5]

    def plot(self):
        plt.hist(self.data, self.data, histtype='bar', rwidth=0.8)
