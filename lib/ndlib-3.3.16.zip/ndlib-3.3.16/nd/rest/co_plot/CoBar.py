# coding=utf-8

import matplotlib.pyplot as plt

font = {
    'family': 'YaHei Consolas Hybrid',
    'size': 9
}

plt.matplotlib.rc('font', **font)


class CoBar(object):
    def __init__(self, xlabel=u"横轴", size=None):
        self.x = [2, 3, 4]
        self.y = [2, 1, 1]

        if size is None:
            fig = plt.figure()
        else:
            fig = plt.figure(figsize=size)

        self.ax = fig.add_subplot(111)

    def set_xlabel(self, label):
        self.ax.set_xlabel(label, fontsize=13)

    def set_x(self, x):
        self.x = x

    def set_y(self, y):
        self.y = y

    def set_xticks(self, x):
        """
        设置刻度文本

        :param x:
        :return:
        """
        # tick_x = self.x
        # self.ax.xticks(self.x, x, rotation=55)
        # plt.xticks(self.x, x, rotation='vertical')
        xaxis = self.ax.xaxis

        xaxis.set_ticklabels(x, rotation=55, fontsize=8)

    def set_xtick_val(self, x):
        xaxis = self.ax.xaxis
        xaxis.set_ticks(x)

    def autolabel(self, rects):
        # attach some text labels
        for rect in rects:
            # 获取高度
            height = rect.get_height()

            # 在指定高度设置文本
            self.ax.text(rect.get_x() + rect.get_width()/2., 1.05*height, '%d' % int(height), ha='center', va='bottom')

    def plot(self):
        """

        :return:
        """
        plt.subplots_adjust(bottom=0.2)

        rects = self.ax.bar(self.x, self.y)

        self.autolabel(rects)

