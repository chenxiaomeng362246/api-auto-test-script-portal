# coding=utf-8

__author__ = 'linzh'


class HttpInfo(object):
    def __init__(self):
        self.host = ""

    def get_host(self):
        return self.host
