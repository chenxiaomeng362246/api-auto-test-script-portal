# coding=utf-8
import urllib

__author__ = 'linzh'

class HttpUtil(object):
    def __init__(self):
        pass

    @staticmethod
    def get_query(data):
        query = urllib.urlencode(data)
        return '?' + query

    @staticmethod
    def get_query2(data):
        query = urllib.urlencode(data)
        return query
