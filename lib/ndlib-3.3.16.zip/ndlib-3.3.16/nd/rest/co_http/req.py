# coding=utf-8

__author__ = 'linzh'

import requests

"""

http://requests-docs-cn.readthedocs.org/zh_CN/latest/user/quickstart.html

http://requests-docs-cn.readthedocs.org/zh_CN/latest/user/advanced.html

"""

class Http(object):
    def __init__(self):
        self.host = ""

    def get(self, url):
        """

        :param url:

        :return:

        .. code-block:: python
            :linenos:

            >>> http_o = Http(host)
            >>> http_o.get()

        """
        http_url = self.url + url
        res = requests.get(http_url)
        retn = dict()
        retn['code'] = res.status_code
        retn['data'] = res.json

        return retn

