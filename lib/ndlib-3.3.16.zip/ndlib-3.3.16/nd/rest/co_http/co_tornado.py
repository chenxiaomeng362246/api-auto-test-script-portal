# coding=utf-8
__author__ = 'linzh'

from ..tornado.httpclient import HTTPClient


class Http(object):
    """
    使用tornado库

    """
    def __init__(self):
         self.conn = HTTPClient()

    def get(self, url):
        """
         :param url:

         :return:

         .. code-block:: python
             :linenos:

             >>> http_o = Http(host)
             >>> http_o.get()

        """
        return self.conn.fetch(url)

    def put(self, url):
         from tornado.httpclient import HTTPRequest

         req = HTTPRequest(url, "PUT")
         self.conn.fetch(req)

    def post(self, url):
         pass

    def patch(self, url):
         pass

    def upload_files(self, url, file_path, params):
         pass
