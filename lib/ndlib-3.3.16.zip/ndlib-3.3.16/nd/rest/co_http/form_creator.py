# coding=utf-8

__author__ = 'linzh'


class FormCreator(object):
    def __init__(self):
        pass

    def file_encode(file_path, fields=[]):
        BOUNDARY = '----------bundary------'
        CRLF = '\r\n'
        body = []
        # Add the metadata about the upload first
        for key, value in fields:
            body.extend(
              ['--' + BOUNDARY,
               'Content-Disposition: form-data; name="%s"' % key,
               '',
               value,
               ])
        # Now add the file itself
        file_name = os.path.basename(file_path)
        f = open(file_path, 'rb')
        file_content = f.read()
        f.close()
        body.extend(
          ['--' + BOUNDARY,
           'Content-Disposition: form-data; name="file"; filename="%s"'
           % file_name,
           # The upload server determines the mime-type, no need to set it.
           'Content-Type: application/octet-stream',
           '',
           file_content,
           ])
        # Finalize the form body
        body.extend(['--' + BOUNDARY + '--', ''])
        return 'multipart/form-data; boundary=%s' % BOUNDARY, CRLF.join(body)

    def form_encode(self, fields=list()):
        """

        :param fields:
        :return:
        """

        BOUNDARY = '----------bundary------'

        CRLF = '\r\n'

        body = []

        # Add the metadata about the upload first
        for key, value in fields:
            body.extend(['--' + BOUNDARY, 'Content-Disposition: form-data; name="%s"' % key, '', value, ])

        # Finalize the form body
        body.extend(['--' + BOUNDARY + '--', ''])

        return 'multipart/form-data; boundary=%s' % BOUNDARY, CRLF.join(body)

    def get_form_str(self, fields=list()):
        encode_res = self.form_encode(fields)
        return encode_res[1]
