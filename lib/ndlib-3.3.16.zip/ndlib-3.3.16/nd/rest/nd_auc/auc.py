# coding=utf-8

__author__ = 'linzh'

from ..nd_path import NdPath
from ..proc import CoProc


import urllib
from ..http import Http

from ..nd_auc.dev import Auth

import logging
from ..tornado.escape import json_decode

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(filename)s[%(lineno)d] %(levelname)s %(message)s')
logger = logging.getLogger(__name__)
logger.info(__name__)


class AucToken(object):
    """
    通过auc获取token
    """
    DEV = 1
    TEST = 2
    PROD = 3

    def __init__(self):
        # 1.默认的header
        self.header = {
            "Content-Type": "application/x-www-form-urlencoded"
        }

        # 2.读配置文件，获取host
        # my_cfg = MyCfg('cfg.ini')
        # my_cfg.set_section("test")

        self.version = '1'

        self.cfg = Auth.get_cfg()
        self.jlib_path = NdPath.get_jlib_path()
        self.host = 'test.userapi.huayu.nd'

        self.http_o = Http(self.host)
        self.http_o.set_header(self.header)

    def get_wrong_token(self):
        """
        获取错误的token
        """
        access = "d604c53601aa747f00524d"
        access_token = "Bearer \"" + access + "\""
        return access_token

    def get_token(self, user='', password='', org='', url='', method='', host=''):
        """
        获取token
        """
        access = self.get_access(user, password, org, url, method, host)

        access_token = "Bearer \"" + access + "\""
        return access_token

    def get_access(self, user='', password='', org='', url='', method='', host=''):
        """
        仅生成access
        密码通过加密后，还需要进行转义 转义的操作在这：urllib.urlencode(param)
        org='', url='', method='', host='' 这几个参数无用，仅是为了兼容
        """
        url = "/v1/oauth/token"
        if user == '':
            user = self.cfg['user']
        if password == '':
            password = self.cfg['password']

        # password_encrypt = self.unity_o.get_encrypt_password(password)

        md5_jar_path = self.jlib_path + 'AucToken.jar'
        command = 'java -jar ' + md5_jar_path + '  \"%s\"' % password

        proc_o = CoProc()
        res = proc_o.run(command)
        logger.info(res)
        password_encrypt = res['result']

        param = {
            "grant_type": "password",
            "username": user,
            "password": password_encrypt,
            "response_type": "token",
            "client_id": self.cfg['client_id'],
            "client_secret": self.cfg['client_secret'],
            "terminal_code": 1001,
            "solution": "uc101beta"
        }

        if len(param) != 0:
            url += '?' + urllib.urlencode(param)

        # print url
        res = self.http_o.get(url)

        data = res['data']
        res_data = json_decode(data)
        data = res_data['Data']
        access = data['access_token']

        return access

if __name__ == "__main__":
    o = AucToken()
    a = o.get_token()
    acc = o.get_access()
    logger.info(acc)
