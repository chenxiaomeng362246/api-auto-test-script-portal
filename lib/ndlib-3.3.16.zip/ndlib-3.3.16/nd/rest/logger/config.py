# coding=utf-8

__author__ = 'linzh'


class LogConfig(object):
    # HOST = "192.168.250.238"
    HOST = "fs.qa.huayu.nd"
    PORT = 1463

    HY_HOST = HOST
    HY_PORT = 11215

    def __init__(self):
        self.host = self.HOST
        self.port = self.PORT

    @staticmethod
    def set_def_host(host):
        LogConfig.HOST = host

    def set_host(self, host):
        self.host = host

    def set_port(self, port):
        self.port = port

    def get_host(self):
        return self.host

    def get_port(self):
        return self.port
