# coding=utf-8

import logging

from thrift.protocol import TBinaryProtocol

from thrift.transport import TTransport, TSocket

from scribe import scribe

from .config import LogConfig

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(filename)s[%(lineno)d] %(levelname)s %(message)s')
logger_o = logging.getLogger(__name__)


class ScribeHandler(logging.StreamHandler):
    """
    日志Scribe处理器

    将该handler加入日志记录设施，然后调用日志发送方法，即可发送到scribe服务器

    日志查看地址

    http://log.qa.huayu.nd:8088/

    .. code-block:: python

        # 添加日志handler，写向Scribe日志服务器
        >>> logger.addHandler(self.handler)
        # 正常调用
        >>> logger.info("Scribe日志测试: " + CoTime().iso8601())

    """
    def __init__(self, log_tag=None):
        self.agent_ip = LogConfig.HOST
        self.agent_port = LogConfig.PORT

        if log_tag is None:
            log_tag = __name__

        self.log_tag = log_tag

        try:
            sock = TSocket.TSocket(host=self.agent_ip, port=self.agent_port)

            sock.setTimeout(1500)

            self.sock = sock

            super(ScribeHandler, self).__init__(sock)

            self.transport = transport = TTransport.TFramedTransport(sock)

            transport.open()
            self.protocol = protocol = TBinaryProtocol.TBinaryProtocol(trans=transport, strictRead=False, strictWrite=True)
            self.client = scribe.Client(protocol)
        except Exception, e:
            from ..logger.sclient import SClient
            self.client = SClient()
            logger_o.error(e)

    def emit(self, record):
        """
        日志记录器日志发送函数

        record 日志记录

        logging模块中的record构造日志记录对象，可以直接用于传递给handler进行处理

        log record对象格式：

        .. code-block:: javascript

            // MakeRecord()

            {
                levelname: "INFO"
            }

        .. code-block:: python

            >>> import logging
            >>> ts_o = CoTime()
            >>> ts_str = ts_o.iso8601()
            >>> logger = logging.getLogger(__name__)
            >>> logger.info(ts_str)
        """

        try:
            if isinstance(record.getMessage(), unicode):
                msg_text = record.getMessage().encode('utf-8')
                record.message = msg_text
                record.msg = msg_text

            # 根据格式字符串生成消息文本
            log_message = msg = self.format(record)

            log_category = self.log_tag

            if isinstance(msg, unicode):
                try:
                    log_message = msg.encode('utf-8')
                except Exception, e:
                    logger_o.error(e)
                    logger_o.error(msg)
            else:
                log_message = msg

            log_entry = scribe.LogEntry(log_category, log_message)

            self.client.Log(messages=[log_entry])

            self.flush()

        except (KeyboardInterrupt, SystemExit), e:
            logger_o.error("错误-SystemExist")
            logger_o.error(e)

        except Exception, e:
            # 连接异常
            # sock = TSocket.TSocket(host=self.agent_ip, port=self.agent_port)
            # sock.setTimeout(1500)
            # transport = TTransport.TFramedTransport(sock)
            # transport.open()
            # protocol = TBinaryProtocol.TBinaryProtocol(trans=transport, strictRead=False, strictWrite=True)
            # self.client = scribe.Client(protocol)

            logger_o.error("日志发送异常")
            logger_o.error(self.format(record))
            logger_o.error("发生异常-log emit")
            logger_o.error(e)

    def close(self):
        """
        Closes the stream.
        """
        self.acquire()
        try:
            if self.stream:
                self.flush()
                if hasattr(self.stream, "close"):
                    self.stream.close()
                self.stream = None
            # Issue #19523: call unconditionally to
            # 阻止句柄泄露
            # prevent a handler leak when delay is set
            logging.StreamHandler.close(self)
            self.transport.close()
        finally:
            self.release()

    def __del__(self):
        self.transport.close()
