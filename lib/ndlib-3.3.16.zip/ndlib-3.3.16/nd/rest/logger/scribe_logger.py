# coding=utf-8

from ..Singleton import Singleton

from ..log import LogInfo

from ..logger.scribe_handler import ScribeHandler

import logging


class ScribeLogger(Singleton):
    """
    scribe日志记录器

    """
    def __init__(self):
        super(Singleton, self).__init__()

        log_info = LogInfo()

        format_str = log_info.get_format_str()
        log_file = log_info.get_log_file()

        logging.basicConfig(level=logging.INFO, format=format_str, filename=log_file)
        log_o = logging.getLogger(__name__)

        if not hasattr(self, 'handler'):

            self.handler = ScribeHandler()
            self.handler.setFormatter(log_info.get_format())

            log_o.addHandler(self.handler)

        self.logger = log_o

    def write(self, msg):
        """

        :param msg:
        :return:
        """
        self.logger.info(msg)


if __name__ == "__main__":
    logger = ScribeLogger()
    logger.write("hello, world")

