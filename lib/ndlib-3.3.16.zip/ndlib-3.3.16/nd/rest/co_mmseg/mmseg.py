# coding=utf-8

import re
from ..co_http.co_curl import Http
from ..tornado.escape import json_decode

__author__ = 'linzh'


class Mmseg(object):
    def __init__(self):
        pass

    def seg(self, data):
        host = "blog.qa.huayu.nd"
        port = 8100
        http_o = Http(host, port)
        header = dict()
        header['Content-Type'] = 'application/json'

        http_o.set_header(header)

        url = "/api/v1.0/mmseg"

        res = http_o.post(url, data)

        data = res['data']

        data = json_decode(data)

        data = data['word']

        data = data.split('\n')

        res = list()

        # ptn = re.compile('\s+(.*)/x')

        for item in data:
            if item.find('/x') != -1:
                seg_list = item.split(' ')
                for seg in seg_list:
                    if len(seg) > len('/x'):
                        # matches = re.findall(ptn, item)
                        seg = seg.replace('/x', '')
                        res.append(seg)

        return res
