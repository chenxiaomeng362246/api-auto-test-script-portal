# coding=utf-8

__author__ = 'linzh'

import os

os.environ.setdefault('IM_UID', '281474976720219')
os.environ.setdefault('IM_PASSWD', '4abb8356-d8bd-44eb-b8cc-ee6c2a281ad8')

os.environ.setdefault('CS_UID', '10003732')


if __name__ == '__main__':
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.info(__name__)

    logger.info(os.environ.get)

