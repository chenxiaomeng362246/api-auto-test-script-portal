# coding=utf-8
from .co_case import CoCase
from .co_report import CoReport
from ..logger.log_func import Logger
from ..conf.conf import CASELEVEL

__author__ = 'linzh'


import unittest
from hamcrest import *

logger = Logger("测试框架用例基类")

# 从命令行
TAG = CASELEVEL


class NdCase(unittest.TestCase):
    def __init__(self, *args, **kwargs):
        super(NdCase, self).__init__(*args, **kwargs)

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def assert_code(self, code, code_rtn):
        assert_that(code_rtn, equal_to(code), "HTTP响应码应该为" + str(code) + "，但是为" + str(code_rtn))

    def get_tag(self, doc):
        """
        从 doc 提取tag
        """
        if TAG is None:
            return True

        import re
        ptn = re.compile('tag:.*\d')
        matches = re.findall(ptn, doc)
        logger.info(matches)

        if len(matches) == 0:
            return False

        tag_str = matches[0]
        tag_info = tag_str.split(':')

        logger.info(tag_info)

        tag = int(tag_info[1].strip())
        logger.info(tag)

        if tag <= TAG:
            return True
        else:
            return False

    def run(self, result=None):
        """
        @TODO

        目前模式无法支持多线程运行，因为全局变量未加锁处理

        :param result:
        :return:
        """
        logger.info(self._testMethodDoc)
        logger.info(getattr(self, self._testMethodName))

        case = CoCase()
        case.set_case_name(self._testMethodName)
        case.set_case_doc(self._testMethodDoc)
        case.set_report_id(CoReport.REPORT_ID)
        CoCase.CASE_ID = case.save()
        logger.info("更新用例信息")
        logger.info(CoCase.CASE_ID)

        if hasattr(self, 'reporter'):
            logger.info(self.reporter)

        if self._testMethodDoc:
            # 解析注释，提取tag
            tag = self.get_tag(self._testMethodDoc)

            if tag:
                super(NdCase, self).run(result)
            else:
                pass

