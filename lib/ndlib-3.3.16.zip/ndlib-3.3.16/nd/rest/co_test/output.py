# coding=utf-8

# ------------------------------------------------------------------------
# The redirectors below are used to capture output during testing.
#
# Output
# sent to sys.stdout and sys.stderr are automatically captured.
#
# However
# in some cases sys.stdout is already cached before HTMLTestRunner is
# invoked (e.g. calling logging.basicConfig).
#
# In order to capture those
# output, use the redirectors for the cached stream.
#
# e.g.
# 使得日志输出
#
#   >>> logging.basicConfig(stream=HTMLTestRunner.stdout_redirector)
#   >>>
#

import sys


class OutputRedirector(object):
    """
    Wrapper to redirect stdout or stderr

    重定向输出，用于捕获unittest的输出，方便重定向到不同的介质
    """
    def __init__(self, fp):
        self.fp = fp

    def write(self, s):
        self.fp.write(s)

    def writelines(self, lines):
        self.fp.writelines(lines)

    def flush(self):
        self.fp.flush()

stdout_redirector = OutputRedirector(sys.stdout)
stderr_redirector = OutputRedirector(sys.stderr)
