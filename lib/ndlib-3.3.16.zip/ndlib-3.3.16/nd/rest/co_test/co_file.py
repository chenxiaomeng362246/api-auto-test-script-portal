# coding=utf-8

__author__ = 'linzh'


class CoFile(object):
    def __init__(self):
        pass
