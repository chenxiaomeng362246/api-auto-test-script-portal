# coding=utf-8

"""
using method:

    input command in cmd linke "python runner.py case_2 case_1"

    命令运行：python runner.py case_test

"""

import os
import sys

reload(sys)
sys.setdefaultencoding('utf8')
sys.path.insert(0, '..')

from optparse import OptionParser
from co_config import CoConfig
from co_report import CoReport
from co_send_strategy import CoSendStrategy
from co_sender import CoSender
from ..logger.log_func import Logger
from msg import get_result
from ..co_file import file as CoFileM
from ..conf import conf as CoConfM
from ..co_time import co_time as cofTime
from path import get_report_path
# todo 暂时屏蔽
# from driver import HTMLTestRunner
from HTMLTestRunner_SAL import HTMLTestRunner
from suite import generate_suites
from suite import set_case_list
from ..nd_path import search_project_root_path

__author__ = 'linzh'

# 获取当前时间
date = cofTime.get_date_ymd()  # 日期【20150213】
timestamp = str(cofTime.get_ts())  # 时间戳【1423813170】

opt_parser = OptionParser()

opt_parser.add_option("-s", "--suite", dest="suite", help=u"指定运行的测试套件", metavar="SUITE")

opt_parser.add_option("-t", "--type", dest="config_type", help=u"从命令行指定要运行的测试环境", metavar='CFGTYPE')

opt_parser.add_option("-f", "--flag", dest="case_tag", help=u"从命令行指定要运行的测试用例的标签", metavar='CASETAG')

opt_parser.add_option("-p", "--push", dest="push_id", help=u"从命令行判断是否要推送", metavar='PHSUID')

(options, opt_args) = opt_parser.parse_args()

suite_opt = options.suite

pro_id = options.push_id


def run_test_cases(app_loc, logger, test_sets, report_dir, report_title, contact=None, report=CoReport(), env='',
                   levels=[]):
    """
    运行测试用例

    -> (dentry_id): 目录项ID

    test_sets：字典格式的测试集
    """
    # 判断报告文件夹是否存在，若不存在则创建
    is_exist = os.path.exists(report_dir)

    if is_exist is False:
        os.makedirs(report_dir)

    # 指定测试集
    root = app_loc + "testcases"

    if not os.path.exists(root):
        raise Exception("测试用例目录不存在，请在项目目录下新建目录testcases")

    # 只运行指定测试用例集
    test_suites = generate_suites(root, test_sets, report, env=env, levels=levels)

    # 运行全部用例
    # test_suites = nose.collector()
    if report.pro_id:
        report_filename = date + timestamp + "_" + sys.argv[1] + '.html'
        file_path = report_dir + os.sep + date + timestamp + "_" + sys.argv[1] + '.html'
    else:   # 不传pro_id时，为初始值0
        report_filename = date + timestamp + '.html'
        file_path = report_dir + os.sep + date + timestamp + '.html'

    # 定义报告名称

    report.set_local_url(file_path)

    # 保存title
    report.set_title(report_title)

    # todo 将测试的测试报告推送到内容服务
    # from nd.rest.nd_cs import NdCs
    # nd_cs = NdCs()
    # upload_res = nd_cs.upload_html(session_id, file_path, file_name)

    # 构造测试信息参数
    # 将参数发送给服务端
    # dentry_id = ""

    logger.info(file_path)

    fp = file(file_path, 'wb')

    # 如：'共享平台接口测试[ApiTest for SDP]'
    runner = HTMLTestRunner(
        stream=fp,
        title=report_title
    )

    suite_name = sys.argv[1]
    runner.run(test_suites, suite_name, contact)

    try:
        fp.close()
    except Exception, err:
        logger.info("关闭报告文件")
        logger.info(err)

    return report_filename


def run(path):
    """

    :param path: 调用文件的路径
    :return:
    """
    # 工程根路径
    app_loc = search_project_root_path(path)

    logger = Logger("测试框架运行器", app_loc)

    # 参数对
    logger.info(options)

    # 参数列表
    logger.info(opt_args)

    if options.config_type is None:
        logger.info("未指定测试环境")
        cfg_type = CoConfM.get_cfg_type(app_loc)
    else:
        cfg_type = options.config_type

    if options.case_tag:
        CoConfM.CASELEVEL = options.case_tag

    CoConfM.CFGTYPE = cfg_type
    # CoConfM.set_cfg_type(cfg_type)

    app_cfg = CoConfM.get_cfg_type(app_loc)

    logger.info("测试环境")
    logger.info(app_cfg)

    # app_gbl_cfg_file = CoConfM.get_cfg_type_path()

    if not suite_opt:
        # 如果没有指定测试集配置文件，使用默认的配置
        suite_config = app_loc + os.sep + 'runner' + os.sep + "suites.json"
    else:
        # 到指定的目录获取对应的测试集配置
        suite_config = app_loc + "config" + os.sep + app_cfg + os.sep + suite_opt + ".json"

    logger.info("测试集配置路径")
    logger.info(suite_config)

    # 当前路径
    # path = os.path.abspath(__file__)
    # path = os.path.dirname(path)

    suite_config_exist = os.path.exists(suite_config)

    logger.info("测试套件配置是否存在")
    logger.info(suite_config_exist)

    # 获取划分的测试集信息列表
    case_list = set_case_list(suite_config)

    if case_list is None:
        print "case_list is empty"
        exit()

    for case_info in case_list:
        # ---------- 提取配置信息 ------------- #
        try:
            # 指定的环境，目前仅用于改变全局环境，不用于case过滤
            env = case_info[u'env']
        except Exception as e:
            env = ''

        try:
            # 需要跑的case层级，用于case过滤
            levels = case_info[u'levels']
        except Exception as e:
            levels = []

        # 测试报告名
        report_file = case_info[u'report_file']

        # 指定要运行的测试用例集
        test_sets = case_info[u'cases']

        # 接收人
        receivers = case_info[u'receivers']

        # 测试报告接收的群组
        group = case_info[u'group']

        # 测试报告标题
        title = case_info[u'title']

        # if case_info.get('project'):
        #     project = case_info['project']
        # else:
        #     project = case_info['report_file']
        # 针对开发预测试，必须保存组件名
        project = case_info['report_file']

        if 'api_count' in case_info:
            logger.info("接口数")

        jenkins_job = ""

        if 'jenkins' in case_info:
            logger.info("jenkins任务ID")
            jenkins_job = case_info['jenkins']

        contact = dict()

        if 'contact' in case_info:
            logger.info("联系人信息")
            contact = case_info['contact']
            for k in contact:
                logger.info(k)
                logger.info(contact[k])
                pass

        # 构造标题

        # 测试报告联系人
        # {}

        # 保证env是字符串
        if not isinstance(env.encode('utf-8'), str):
            print "the value of key environment is not type of string in configure file *.json"
            exit()
        else:
            # 只能指定一个环境
            env = str(env).strip(" ").lower()
            if env:
                sys.path.append(app_loc)
                import config.gbl
                config.gbl.ENVIRONMENT = env  # 修改运行时环境

        # 保证levels是列表
        if not isinstance(levels, list):
            print "the value of key levels is not type of list in configure file *.json"
            exit()
        # 保证levels中每个元素都是整型
        for level in levels:
            if not isinstance(level, int):
                print "the value " + str(level) + " in levels is not type of int in file suites.json"
                exit()

        report_dir = get_report_path(app_loc, report_file)
        logger.info("报告路径-runner")
        logger.info(report_dir)

        # 保存测试报告信息到数据库
        report = CoReport()
        report.set_project(project)
        report.set_project_id(pro_id)
        # report.save()

        report_filename = run_test_cases(app_loc, logger, test_sets, report_dir, title, contact, report=report, env=env,
                                         levels=levels)

        # 获取99u消息结果
        res = get_result(report_dir, title, report_filename, jenkins_job=jenkins_job, report=report)
        res["report_local_url"] = '/test_reports/' + report_file + '/' + report_filename

        # 针对开发准入测试将测试结果和报告地址保存到数据库
        report.save()  # 保存历史数据
        report.saveSummary()  # 保存实时统计最新数据

        config = CoConfig(case_info)

        strategy = CoSendStrategy(report, config)

        sender = CoSender(strategy, config)

        sender.send(res)
