# coding=utf-8

"""
添加用例分层处理 by linsx

分层规则：
1、在case的注释中指定适用层级，"level:2, 3"；
在测试集配置中指定要运行的层级列表，"levels":[1, 2]；
适用层级有符合配置层级（有交集）的case都会运行
2、未在注释中指定层级的case，不受影响
3、未在测试集配置中指定层级，则只运行无层级的case

场景：
1、指定到多个文件
2、指定到多个目录
3、指定到目录时，同目录下有同名不同level的case
4、指定到文件&目录混合
"""

import importlib
import json
from unittest.suite import _isnotsuite
from ..co_os import OsInfo
from ..co_test.co_case import CoCase
from ..co_test.co_report import CoReport
from ..co_test.co_suite import CoSuite
# from ..logger.log_func import Logger

# import unittest
import sys

# from unittest import loader
import logging
import time   # add laibaoyu
from ..unittest.unittest_suite import TestSuite   # add laibaoyu
from ..unittest import unittest_loader as loader   # add laibaoyu
from fnmatch import fnmatch # add laibaoyu
import os # add laibaoyu

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
# logger = Logger("测试框架测试集")
# logger.info("测试集生成模块加载..." + __name__)
logger.info("测试框架测试集")
logger.info("测试集生成模块加载..." + __name__)

__author__ = 'linzh'


class MyTestSuite(TestSuite):
    """

    """

    def __init__(self, *args, **kwargs):
        super(MyTestSuite, self).__init__(*args, **kwargs)
        self.suite = None
        self.report = CoReport()

    def set_suite(self, s=None):
        if s is None:
            self.suite = CoSuite()

    def set_report(self, r=None):
        if r is not None:
            self.report = r

    def run(self, result, debug=False):
        # 不执行默认运行方法
        # super(MyTestSuite, self).run(result, debug)
        topLevel = False

        if getattr(result, '_testRunEntered', False) is False:
            result._testRunEntered = topLevel = True

        for test in self:
            test_cls = test.__class__
            logger.info("测试类")
            logger.info(test_cls)

            dir_detail = dir(test)
            logger.info("测试用例")
            logger.info(dir_detail)
            # desc = test.shortDescription()
            logger.info("描述")
            # logger.info(desc)
            # 注释掉保存测试集到mongo库的操作
            # test_cases = test._tests
            # for test_case in test_cases:
            #     suite = CoSuite()
            #     suite.set_suite_info(str(test_case))
            #     suite.set_report_id(self.report.report_id)
            #     suite.save()

            if result.shouldStop:
                break

            if _isnotsuite(test):
                self._tearDownPreviousClass(test, result)

                self._handleModuleFixture(test, result)

                self._handleClassSetUp(test, result)

                result._previousTestClass = test.__class__

                if (getattr(test.__class__, '_classSetupFailed', False) or
                        getattr(result, '_moduleSetUpFailed', False)):
                    continue

            # 执行测试
            if not debug:
                test(result)
            else:
                test.debug()

        if topLevel:
            self._tearDownPreviousClass(None, result)
            self._handleModuleTearDown(result)
            result._testRunEntered = False

        return result

    def addTest(self, test):

        super(MyTestSuite, self).addTest(test)


def filter_by_doc(preche, test_case_del, env, levels):
    """

    :return:
    """
    for i in range(len(preche)):
        test = preche[i]
        try:
            doc = test._testMethodDoc
        except Exception as e:
            test_case_del = filter_by_doc(test._tests, test_case_del, env, levels)
            return test_case_del

        # 方法envs为None，默认运行
        envs = None
        # 方法lel为None，默认运行
        lel_s = list()
        if doc is not None:
            for line in doc.split("\n"):
                line = line.strip(" ").strip("\t").lower()
                if line.startswith("envs"):
                    tokens = line.split(":")
                    if len(tokens) > 1:
                        envs = tokens[1].split(",")
                        for j in range(len(envs)):
                            envs[j] = envs[j].strip(" ").strip("\t")
                elif line.startswith("level"):
                    tokens = line.split(":")
                    # level对应的字符串只包含数字
                    if len(tokens) > 1:
                        lel_list = tokens[1].split(',')
                        for lel in lel_list:
                            lel_s.append(int(lel.strip("\t").strip(" ")))

        # if ((envs is not None) and (env.lower() not in envs)) or \
        #         (len(lel_s) and len(set(lel_s).intersection(set(levels))) == 0):   # case和配置的level没有交集
        if len(lel_s) and len(levels) and len(set(lel_s).intersection(set(levels))) == 0:  # 配置的等级、case指定等级均不为空，且case和配置的level没有交集（ps：暂不判断环境过滤）
            test_case_del.append(test._testMethodName)
    return test_case_del


def del_by_name(preche, name):
    """

    :return:
    """
    for i in range(len(preche)):
        try:
            preche[i]._testMethodName
        except Exception as e:
            preche = del_by_name(preche[i]._tests, name)
            return preche
        if preche[i]._testMethodName is name:
            del preche[i]
            break
    return preche


def filter_case_by_level(current_suite, env, levels):
    """
    根据指定的等级，过滤case
    :return: case集合
    """
    # if len(current_suite._tests) > 0 and len(current_suite._tests[0]._tests) > 0:
    for tests in current_suite._tests:
        preche = tests._tests
        test_case_del = list()
        test_case_del = filter_by_doc(preche, test_case_del, env, levels)

        for name in test_case_del:
            preche = del_by_name(preche, name)
    return current_suite


def generate_suites(root, test_sets, report=CoReport(), case=CoCase(), env='', levels=[]):
    """
    生成测试套件

    :param root: 根路径

    :param test_sets:

    """

    # 测试套件
    # suites = suite.LazySuite()

    suites = MyTestSuite()
    suites.set_suite()
    suites.set_report(report)

    sys.path.append(root)
    logger.info(root)

    # TODO 没有验证对应的测试目录是否存在
    for ts_name, ts in test_sets.iteritems():
        logger.info("ts_name")
        logger.info(ts_name)
        for tc in ts:
            tc_complete = ts_name + "." + tc  # 用例文件完整的路径
            logger.info(tc_complete)

            # if OsInfo.is_linux():
            #     suites.addTest(loader.TestLoader().discover(tc_complete))
            # else:
                # module = importlib.import_module(tc_complete)
                # suites.addTest(loader.TestLoader().loadTestsFromModule(module))
            if fnmatch(tc_complete.split('.')[-1], 'test*') and not os.path.isdir(os.path.join(root, os.sep.join(tc_complete.split('.')))):   # 判断用例文件是目录还是文件 add laibaoyu
                module = importlib.import_module(tc_complete)
                suites.addTest(filter_case_by_level(loader.TestLoader().loadTestsFromModule(module), env, levels))
            else:
                suites.addTest(filter_case_by_level(loader.TestLoader().discover(tc_complete), env, levels))  # 通过用例路径搜索test*.py文件 add laibaoyu

                # suites.addTest(unittest.TestLoader().loadTestsFromModule(module))
                # 根据tag添加测试
                # suites.addTest(loader.TestLoader().discover2(tc_complete))
                # 默认添加所有测试
                # suites.addTest(loader.TestLoader().discover(tc_complete))

    # unittest.TextTestRunner(verbosity=2).run(suites)
    return suites


def set_case_list(suite_config):
    """
    从命令行读取需要运行的测试集，返回测试集列表
    """
    argvs = sys.argv

    if len(argvs) <= 1:  # 没有指定测试用例集，默认运行所有测试用例（nose自动识别）
        print "no specified cases, could run all cases"
        return None

    if argvs[1] == "--all":  # 运行配置文件中的所有用例集（待实现）
        print "run all cases specified in json file"
        return None

    # 读suites.json配置文件，获取所有划分的测试集
    file = open(suite_config)

    # 加载测试集配置文件
    try:
        case_set = json.load(file)
    except Exception, err:
        print "加载测试集配置时，发生错误"
        print str(err)
        raise Exception

    logger.info("加载测试集配置")
    logger.info(case_set)

    # 测试集
    suite_list = list()

    for i in range(1, len(argvs)):
        case_set_name = argvs[i]
        if case_set_name not in case_set.keys():
            # 输入的用例集名称不存在于配置文件指定的测试集中
            print "测试集不存在case set name(s): \"%s\" is(are) not include in case set names in json file" % case_set_name
            continue
        else:
            # 将测试集附加到测试集列表中
            case_tmp = case_set[case_set_name]
            suite_list.append(case_tmp)

    if len(suite_list) == 0:
        print "测试集为空，停止运行"
        exit(0)

    return suite_list
