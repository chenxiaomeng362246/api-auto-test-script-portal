# coding=utf-8

import re

import logging
logging.basicConfig(level=logging.INFO, format='%(filename)s[line:%(lineno)d] %(levelname)s %(message)s')
logger = logging.getLogger(__name__)
logger.info(__name__)


def get_case_desc(doc):
    """

    :param doc:
    :return:
    """
    ptn = re.compile('case:\s*(.*)')
    matches = re.findall(ptn, doc)
    logger.info(matches)

    if matches:
        match_len = len(matches)
        if match_len > 0:
            return matches[0]
    else:
        return "unknown"


def get_case_url(doc):
    """

    :param doc:
    :return:
    """
    ptn = re.compile('url:\s*(.*)')
    matches = re.findall(ptn, doc)
    logger.info(matches)

    if matches:
        match_len = len(matches)
        if match_len > 0:
            return matches[0]
    else:
        return "unknown"


def main():
    doc = """
    case: 测试test
    url: project
    """
    doc_res = get_case_desc(doc)
    url_res = get_case_url(doc)
    logger.info(url_res)
    logger.info(doc_res)

if __name__ == '__main__':
    main()
