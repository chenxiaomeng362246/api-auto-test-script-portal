# coding=utf-8
from ..co_os import OsInfo
import logging

__author__ = 'linzh'

import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
# logger = Logger("接口测试框架-" + __name__)
logger.info("接口测试框架- " + __name__)

# 当前路径
# path = os.path.abspath(__file__)
# path = os.path.dirname(path)


# logger.info(path)


def get_report_path(path, report_file):
    """
    根据配置的文件结构，生成文件路径

    path：工程根路径

    :param report_file: 测试报告名

    """
    logger.info(path)

    tmp = report_file.split('.')

    # report_file_path = os.sep + ".." + os.sep + "test_reports"
    report_file_path = "test_reports"

    for i in tmp:
        report_file_path += os.sep
        report_file_path += i

    if OsInfo.is_linux():
        report_dir = path + report_file_path
    elif OsInfo.is_windows():
        report_dir = path + report_file_path
    else:
        report_dir = path + report_file_path.encode('utf-8')

    logger.info("生成报告路径-get_report_path")
    logger.info(report_dir)

    return report_dir


if __name__ == '__main__':
    get_report_path("file")
