# coding=utf-8

__author__ = 'linzh'

# ------------------------------------------------------------------------
# HTML Template

# <!-- 样式 -->
# <link type="text/css" rel="stylesheet" href="http://192.168.19.97:7777/styles/pyunit.css" />
#
# <script type="text/javascript" src="http://192.168.19.97:7777/scripts/jquery.min.js"></script>
# <script type="text/javascript" src="http://192.168.19.97:7777/scripts/pyunit.js"></script>

HTML_TMPL = r"""
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <title>%(title)s</title>
    <meta name="generator" content="%(generator)s"/>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>

    <link type="text/css" rel="stylesheet" href="http://qa-demo.web.sdp.101.com/assets/js/pyunit.css" />
    <link type="text/css" rel="stylesheet" href="http://qa-demo.web.sdp.101.com/css/bootstrap/v3.3.5/bootstrap.min.css" />

    <script type="text/javascript" src="http://qa-demo.web.sdp.101.com/assets/js/jquery.min.js"></script>
    <script type="text/javascript" src="http://qa-demo.web.sdp.101.com/assets/js/pyunit.js"></script>
    <script type="text/javascript" src="http://qa-demo.web.sdp.101.com/assets/js/report.js"></script>

    %(stylesheet)s
</head>

<body>

%(heading)s

%(report)s

%(ending)s

</body>
</html>
"""

# variables: (title, generator, stylesheet, heading, report, ending)

# ------------------------------------------------------------------------
# Stylesheet
#
# alternatively use a <link> for external style sheet, e.g.
#   <link rel="stylesheet" href="$url" type="text/css">
# 样式模板
STYLESHEET_TMPL = ""

# ------------------------------------------------------------------------
# Heading
#
# 描述
# ------------------------------------------------------------------------
# variables: (title, parameters, description)
HEADING_TMPL = """
<div class='heading'>

<!-- 测试报告标题 -->
<h3>%(title)s</h3>

<!-- 测试整体信息 -->
%(parameters)s

<div class="contact">
    %(contact)s
</div>

<div class='description'>
    %(description)s
</div>

</div>

"""

# variables: (name, value)
# 属性：运行时间 通过数
HEADING_ATTRIBUTE_TMPL = """
<p class='attribute'>
<strong>%(name)s:</strong>
%(value)s
</p>
"""

# ------------------------------------------------------------------------
# Report
# ------------------------------------------------------------------------
REPORT_TMPL = """
<p id='show_detail_line'>显示：
<a href='javascript:showCase(0)'>概要信息</a>
<a href='javascript:showCase(1)'>失败的测试</a>
<a href='javascript:showCase(2)'>所有测试</a>
</p>

<table id='result_table' class="table">
<colgroup>
<col align='left' />
<col align='right' />
<col align='right' />
<col align='right' />
<col align='right' />
<col align='right' />
</colgroup>

<tr id='header_row'>
    <td>测试套件集/测试用例</td>
    <td>统计</td>
    <td>通过</td>
    <td>失败</td>
    <td>错误</td>
    <td>更多</td>
</tr>

%(test_list)s

<!-- 统计信息 -->
<tr id='total_row'>
    <td>Total</td>
    <td>%(count)s</td>
    <td>%(Pass)s</td>
    <td>%(fail)s</td>
    <td>%(error)s</td>
    <td>&nbsp;</td>
</tr>
</table>
"""

# 使用的变量variables: (test_list, count, Pass, fail, error)
# 测试类结果
REPORT_CLASS_TMPL = ur"""
<tr class='%(style)s'>
    <td>%(desc)s</td>
    <td>%(count)s</td>
    <td>%(Pass)s</td>
    <td>%(fail)s</td>
    <td>%(error)s</td>
    <td>
        <a href="javascript:showClassDetail('%(cid)s',%(count)s)" class="detail-link">查看详情
        </a>
    </td>
</tr>
"""
# variables: (style, desc, count, Pass, fail, error, cid)

# tid - case 标号
REPORT_TEST_WITH_OUTPUT_TMPL = r"""
<tr id='%(tid)s' class='%(Class)s'>
    <td class='%(style)s'>

    <div class='testcase'>%(desc)s</div>

    </td>

    <td colspan='4' align='center'>
    <!--css div popup start-->

    <a class="popup_link" onfocus='this.blur();' href="javascript:showTestDetail('div_%(tid)s')" >
        <!-- status -->
        %(status)s
    </a>

    <div id='div_%(tid)s' class="popup_window">

        <div style='text-align: right; color:red;cursor:pointer'>

        <!-- 关闭测试用例详情 -->
        <a onfocus='this.blur();' onclick="document.getElementById('div_%(tid)s').style.display = 'none' " >
           [x]
        </a>

        </div>

        <div class="error-info">
        <!-- script 脚本 -->
            %(script)s
        </div>

    </div>
    <!--css div popup end-->
    </td>

    <td colspan='1' align='center'>

    <div class='spendTime'>%(time)s</div>

    </td>
</tr>
"""
# variables: (tid, Class, style, desc, status)

# 报告
# variables: (tid, Class, style, desc, status)
REPORT_TEST_NO_OUTPUT_TMPL = r"""
<tr id='%(tid)s' class='%(Class)s'>
    <td class='%(style)s'>
    <!-- -->
    <div class='testcase'>
        %(desc)s
    </div>
    </td>

    <td colspan='4' align='center'>
    <div>%(status)s</div>
    </td>

    <td colspan='1' align='center'>
    <div class='spendTime'>%(time)s</div>
    </td>
</tr>
"""

#
REPORT_TEST_OUTPUT_TMPL = ur"""
%(id)s: %(output)s
"""
# variables: (id, output)

# ------------------------------------------------------------------------
# ENDING
#
# ENDING_TMPL = """<div id='ending'>&nbsp;</div>"""
ENDING_TMPL = ""

# -------------------- The end of the Template class -------------------
# 模板类定义结束

def main():
    fp = open("tpl.html", "w")
    fp.write(HTML_TMPL)
    fp.write(ENDING_TMPL)
    fp.close()

    fp = open("report.html", "w")
    fp.write(HEADING_TMPL)
    fp.write(HEADING_ATTRIBUTE_TMPL)
    fp.write(REPORT_TMPL)
    fp.write(REPORT_TEST_WITH_OUTPUT_TMPL)
    fp.close()
    print HTML_TMPL
    print ENDING_TMPL

if __name__ == '__main__':
    main()
