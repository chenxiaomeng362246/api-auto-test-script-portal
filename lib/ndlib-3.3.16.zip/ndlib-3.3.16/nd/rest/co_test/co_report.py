# coding=utf-8
from ..co_mongo.db_info import DbInfo
from ..co_time.co_time import get_ts, dt
from ..mongo import MongodbConn
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

__author__ = 'linzh'


class CoReport(object):
    REPORT_ID = ""

    def __init__(self, report_sender=None):
        """

        :return:
        """
        self.title = ""
        self.report_id = ""
        self.report_sender = report_sender
        self.fail = 0
        self.success = 0
        self.case_count = 0
        self.report_url = ""
        self.local_url = ""
        self.project = ""
        self.pro_id = 0
        self.create_ts = get_ts()
        self.create_dt = dt()
        # self.mongo = MongodbConn(DbInfo.MongoDev['host'], DbInfo.MongoDev['port'])
        # self.mongo.set_coll("py_tests", "Report")
        try:
            self.mongo = MongodbConn(DbInfo.MongoDev['host'], DbInfo.MongoDev['port'])
            self.mongo.set_coll("py_tests", "Report")
        except Exception, e:
            logger.info("DbInfo mongo connection failed")
            self.mongo = None
        # 针对开发预测试新加ReportSummary表连接
        try:
            self.mongoSummary = MongodbConn(DbInfo.MongoDev['host'], DbInfo.MongoDev['port'])
            self.mongoSummary.set_coll("py_tests", "ReportSummary")
        except Exception, e:
            logger.info("DbInfo mongo connection failed")
            self.mongoSummary = None

    def set_title(self, title):
        self.title = title

    def set_project(self, proj):
        self.project = proj

    def set_project_id(self, pro_id):
        if pro_id:
            self.pro_id = int(pro_id)

    def set_fail(self, fail):
        self.fail = fail

    def set_case_count(self, c):
        self.case_count = c

    def set_success(self, c):
        self.success = c

    def has_fail(self):
        if self.fail > 0:
            return True
        else:
            return False

    def set_report_url(self, url):
        """

        :return:
        """
        self.report_url = url

    def set_local_url(self, url):
        self.local_url = url

    def save(self):
        data = dict()
        data['title'] = self.title
        data['project'] = self.project
        data['create_ts'] = self.create_ts
        data['create_dt'] = self.create_dt
        data['total'] = self.case_count
        data['pass'] = self.success
        data['url'] = self.report_url
        if self.mongo is not None:
            oid = self.mongo.add(data)
            self.report_id = oid
            CoReport.REPORT_ID = oid
        else:
            oid = None

        return oid

    def saveSummary(self):
        data = dict()
        data['title'] = self.title
        data['update_dt'] = self.create_dt
        data['total'] = self.case_count
        data['pass'] = self.success
        data['url'] = self.report_url
        if self.mongoSummary is not None:
            is_find = self.mongoSummary.find_one({'project':self.project})
            if is_find is None:
                data['project'] = self.project
                self.mongoSummary.add(data)
            else:
                self.mongoSummary.update(is_find['_id'], data)
        else:
            logger.info("auxotest storage mongo failed")

