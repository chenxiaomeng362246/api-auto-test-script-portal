# coding=utf-8
# from ..logger.log_func import Logger
import logging

__author__ = 'linzh'

from unittest import TestResult
import StringIO
import sys

from ..co_test.output import stderr_redirector, stdout_redirector

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.info("测试框架运行结果" )


class _TestResult(TestResult):
    # note: _TestResult is a pure representation of results.
    # It lacks the output and reporting ability compares to unittest._TextTestResult.
    def __init__(self, verbosity=1):
        TestResult.__init__(self)

        self.stdout0 = None
        self.stderr0 = None
        self.success_count = 0
        self.failure_count = 0
        self.error_count = 0
        self.verbosity = verbosity

        # result is a list of result in 4 tuple
        # (
        #   result code (0: success; 1: fail; 2: error),
        #    TestCase object,
        #   Test output (byte string),
        #   stack trace,
        # )
        self.result = []

    def startTest(self, test):
        TestResult.startTest(self, test)

        # just one buffer for both stdout and stderr
        self.outputBuffer = StringIO.StringIO()

        stdout_redirector.fp = self.outputBuffer
        stderr_redirector.fp = self.outputBuffer
        self.stdout0 = sys.stdout
        self.stderr0 = sys.stderr
        sys.stdout = stdout_redirector
        sys.stderr = stderr_redirector

    def complete_output(self):
        """
        Disconnect output redirection and return buffer.
        Safe to call multiple times.
        """
        if self.stdout0:
            sys.stdout = self.stdout0
            sys.stderr = self.stderr0
            self.stdout0 = None
            self.stderr0 = None

        try:
            case_output = self.outputBuffer.getvalue()
            logger.info(case_output)
            return case_output
        except Exception:
            pass

    def stopTest(self, test):
        # Usually one of addSuccess, addError or addFailure would have been called.
        # But there are some path in unittest that would bypass this.
        # We must disconnect stdout in stopTest(), which is guaranteed to be called.
        self.complete_output()

    def addSuccess(self, test):
        self.success_count += 1

        TestResult.addSuccess(self, test)

        output = self.complete_output()

        self.result.append((0, test, output, ''))

        if self.verbosity > 1:
            sys.stderr.write('ok ')
            sys.stderr.write(str(test))
            sys.stderr.write('\n')
        else:
            sys.stderr.write('.')

    def addError(self, test, err):
        self.error_count += 1

        TestResult.addError(self, test, err)

        _, _exc_str = self.errors[-1]

        output = self.complete_output()

        self.result.append((2, test, output, _exc_str))

        if self.verbosity > 1:
            sys.stderr.write('E  ')
            sys.stderr.write(str(test))
            sys.stderr.write('\n')
        else:
            sys.stderr.write('E')

    def addFailure(self, test, err):
        # 错误数+1
        self.failure_count += 1

        # 测试结果
        TestResult.addFailure(self, test, err)

        _, _exc_str = self.failures[-1]

        output = self.complete_output()

        self.result.append((1, test, output, _exc_str))

        if self.verbosity > 1:
            sys.stderr.write('失败\n  ')
            sys.stderr.write(str(test))
            sys.stderr.write('\n')
        else:
            sys.stderr.write('失败\n')
