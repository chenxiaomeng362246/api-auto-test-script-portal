# coding=utf-8

# from nd.rest.nd_uc import *
__author__ = 'linzh'


class CoConfig(object):
    def __init__(self, case_info=None):
        if case_info is None:
            case_info = dict()

        if case_info.get('monitor'):
            # 除了''、""、0、()、[]、{}、None为False之外
            self.monitor = bool(case_info['monitor'])
        else:
            self.monitor = False

        if case_info.get('receivers'):
            self.receivers = case_info['receivers']
        else:
            self.receivers = []

        if case_info.get('group'):
            self.group = case_info['group']
        else:
            self.group = []

        self.contact = []
        if case_info.get('contact'):
            if case_info['contact'].get('users'):
                self.contact = case_info['contact']['users']

    def load(self):
        pass

    def set_path(self, p):
        self.path = p
