# coding=utf-8
from .nd_case import NdCase
from ..restful import Restful

__author__ = 'linzh'


class ApiNdCase(NdCase):
    GET_OK = 200
    CREATE_OK = 201
    REQUEST_ERROR = 400
    AUTH_FAILED = 403
    NOT_FOUND = 404
    SERVER_ERROR = 500

    def __init__(self, *args, **kwargs):
        super(ApiNdCase, self).__init__(*args, **kwargs)

        self.rest_o = Restful()

