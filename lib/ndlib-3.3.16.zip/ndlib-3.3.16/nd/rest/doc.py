# coding=utf-8

"""
文档生成样式

"""

import sys
import os

import sphinx_rtd_theme

sys.path.insert(0, os.path.abspath('..'))

html_theme = 'sphinx_rtd_theme'
html_theme_path = [sphinx_rtd_theme.get_html_theme_path()]
