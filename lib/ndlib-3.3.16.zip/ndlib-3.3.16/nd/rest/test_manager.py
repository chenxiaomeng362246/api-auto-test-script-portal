# coding=utf-8

"""

func：给测试管理平台发送各个接口测试项目的消息

"""
import httplib
import json
# import signal
# from exceptions import OSError
from .co_ip import get_lan_ip
import logging

__author__ = 'xiexinxi'

IMPORTLIB = False

if IMPORTLIB:
    # import lib.url as LibUrlM
    # import lib.log as LLog
    # logger = LLog.Logger()
    pass
else:
    # import co_http.co_statis as LibUrlM
    import logger.ILogger as LogM

    logger_o = LogM.ILogger()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.info("基础测试框架调用统计")


class TestManager(object):
    def __init__(self, timeout=0.5):
        self.host = 'plot.qa.sdp.nd'  # 测试管理平台主机
        self.host_usage_url = '/api/v1.0/api-statis'  # 给测试管理平台发送接口主机的访问情况
        self.api_usage_url = '/api/v1.0/api-url'  # 给测试管理平台发送接口的访问情况
        self.post_method = 'POST'
        self.get_method = 'GET'
        self.timeout = timeout

    def send_url(self, url, host=""):
        """
        向测试管理平台发送当前接口测试请求的url(不包括协议，host和port)
        """
        tp_host = self.host
        tp_url = self.api_usage_url
        tp_req_method = self.post_method

        host_ip = get_lan_ip()

        headers = dict()
        body = {
            'host': host,
            'url': str(url),
            'ip': host_ip,
            'full_url': host + str(url)
        }
        logger.info("发送接口请求信息 - " + str(url))
        logger.info(body)
        body = json.dumps(body)

        flag = False
        conn = None
        try:
            conn = httplib.HTTPConnection(tp_host, timeout=self.timeout)
            conn.request(tp_req_method, tp_url, body, headers)
            response = conn.getresponse()
            if response.status == 200:
                flag = True
        except Exception, e:  # 连接错误 or 读取错误
            logger.info("记录接口运行")
            print 'error : ', str(e)
        if conn is not None:
            conn.close()

    def send_host_port(self, host, port):
        """
        向测试管理平台发送当前接口测试请求的host和port，如果已经请求过了，就不会再发送
        :param host:
        :param port:
        :return:
        """
        if not self.host_port_is_used(host, port):
            tp_host = self.host
            tp_url = self.host_usage_url
            tp_req_method = self.post_method

            headers = dict()
            if port is not None:
                body = {
                    'host': str(host),
                    'port': long(port)
                }
            else:
                body = {
                    'host': str(host),
                    'port': 80
                }
            body = json.dumps(body)

            conn = None

            try:
                conn = httplib.HTTPConnection(tp_host, timeout=self.timeout)
                conn.request(tp_req_method, tp_url, body, headers)
                response = conn.getresponse()
                if response.status == 200:
                    flag = True
                # else:
                #     print '给测试管理平台发送"' + str(host) + ':' + str(port) + '"失败'
                if conn is not None:
                    conn.close()

            except Exception, e:  # 连接错误 or 读取错误
                logger.info("记录接口服务")
                print 'error : ', str(e)

    def host_port_is_used(self, host, port):
        """
        查询测试管理平台，指定的主机和端口是否已被请求过
        :param host:
        :param port:
        :return:
        """
        is_used = False  # 返回host:port是否已被请求过
        tp_host = self.host
        tp_url = self.host_usage_url + '?host=' + str(host)
        method = self.get_method

        headers = dict()
        body = None

        try:
            conn = httplib.HTTPConnection(tp_host, timeout=self.timeout)
            conn.request(method, tp_url, body, headers)
            response = conn.getresponse()
            if response.status == 200:
                data = response.read()  # 响应的返回值
                data = json.loads(data)
                for item in data:
                    if item['host'] == host and item['port'] == port:
                        is_used = True
                        break

            if conn is not None:
                conn.close()

        except Exception, e:  # 连接错误 or 读取错误
            logger.info("记录接口测试")
            print 'error : ', str(e)

        return is_used


if __name__ == "__main__":
    # TestManager().send_host_port('127.0.0.123', 80)

    # try:
    #     # Set the signal handler and a 1-second alarm
    #     signal.alarm(10000)
    #     signal.signal(signal.SIGALRM, handler)
    #     # This while loop hang indefinitely
    #     while True:
    #         print 'a'
    #     signal.alarm(0)  # Disable the alarm
    # except Exception as e:
    #     print 'timeout'

    print '__main__'
