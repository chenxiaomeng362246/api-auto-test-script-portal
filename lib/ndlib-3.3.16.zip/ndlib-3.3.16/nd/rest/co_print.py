# coding=utf-8


class CoPrint(object):
    CODE = "utf-8"

    def __init__(self):
        pass

    @staticmethod
    def output(msg):
        if CoPrint.CODE == "gbk":
            msg = msg.decode("utf-8").encode("gbk")
        elif CoPrint.CODE == "utf-8":
            msg = msg

        print(msg)


