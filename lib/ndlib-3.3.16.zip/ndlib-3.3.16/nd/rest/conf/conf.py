# coding=utf-8
import ConfigParser
import os
import logging
import re
from ..co_print import CoPrint
from ..co_time.co_time import get_log_time
from ..co_file import file as cofFile
from ..nd_path import search_project_root_path

# 全局变量
gblCfp = ConfigParser.ConfigParser()
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.info("配置信息对象: " + __name__)

CFGTYPE = None
CASELEVEL = None

__author__ = 'Administrator'


class MyCfg(object):
    """
    配置信息对象

    ..code-block:: python

        >>> conf_o = MyCfg('cfg.ini')
        >>> conf_o.set_section('section')
        >>> conf_o.get('key')

    """

    # 版本
    VERSION = ""

    # 测试标识
    TEST = "test-" + str(get_log_time())

    # 报告列表
    REPORTS = None

    # 日志级别
    LOGLEVEL = logging.ERROR

    CASE_INFO = dict()

    CASE_TYPE = 'ui'

    def __init__(self, cfg_name):
        self.cfg_path = ""
        self.cfg_name = cfg_name
        self.sec = ""
        self.cfg_obj = ConfigParser.ConfigParser()

    def set_section(self, section):
        self.sec = section

    def set_path(self, path):
        """
        设置工程的根路径
        """
        path = search_project_root_path(path)
        cfg_type = get_cfg_type(path)

        ex_path = cofFile.expand_links(path + 'config' + os.sep + cfg_type + os.sep + self.cfg_name)
        if not os.path.exists(ex_path):
            print "config file is not exist (" + ex_path + ")"
            raise Exception("配置文件不存在" + ex_path)
        self.cfg_path = ex_path
        self.cfg_obj.read(self.cfg_path)

    def get(self, key):
        try:
            return self.cfg_obj.get(self.sec, key)
        except Exception, err:
            CoPrint.output("读取section：" + self.sec + "下的key：" + key + " 失败")
            # print self.sec
            logger.error(err)

    # 为section的字段赋值
    def set(self, section, option, value):
        self.set(section, option, value)

    def get_section(self, sec_name):
        return self.cfg_obj.items(sec_name)

    # add by api monitor
    def has_option(self, section, option):
        return self.cfg_obj.has_option(section, option)

    # add by pts UC认证版本-获取头部信息
    def get_uc_header(self, section):
        sdp = re.compile(ur'(^sdp-(\S)+)')
        uc_org = ""
        uc_version = ''
        uc_header = dict()
        auth_header_switch = False
        for key, value in section:
            if sdp.match(key):
                uc_header[key] = value
            elif key == 'org_name' or key == 'org':
                uc_org = 'true'
                uc_header[key] = value
            elif key == 'auth-header-switch':
                auth_header_switch = True
                uc_header[key] = value
            elif key == 'uc_version':
                uc_version = value
            elif key == 'uc-vorg-id' or key == 'vorg':
                uc_header[key] = value
        try:
            if str(uc_version) == '1.0':
                if uc_header.has_key('sdp-migrated'):
                    if str(uc_header['sdp-migrated']) == 'true':
                        if uc_header.has_key('sdp-app-id') and uc_header['sdp-app-id'] !='':
                            logger.error("启用UC1.0认证服务")
                        else:
                            logger.error("启用UC1.0认证服务，但请求头未指定SDP-APP-ID")
                    else:
                        if auth_header_switch:
                            uc_header['auth-header-switch'] = 'false'
                        logger.error("启用UC1.0适配0.93版本服务，如果登录的组织为虚拟组织，请通过UC-VORG-ID请求头指定虚拟组织ID")
                else:
                    if auth_header_switch:
                        uc_header['auth-header-switch'] = 'false'
                    logger.error("启用UC1.0适配0.93版本服务，如果登录的组织为虚拟组织，请通过UC-VORG-ID请求头指定虚拟组织ID")
            elif str(uc_version) == '0.93':
                if auth_header_switch:
                    uc_header['auth-header-switch'] = 'false'
                if uc_header.has_key('sdp-migrated'):
                    uc_header['sdp-migrated'] = 'false'
                logger.error("启用UC0.93认证服务，如果登录的组织为虚拟组织，请通过UC-VORG-ID请求头指定虚拟组织ID")
            else:
                logger.error("UC认证服务版本（uc_version）未传或者指定有误！")
        except Exception as e:
            logger.error(e,"未传或为空 \n")

        return uc_header


# 获取配置目录
def get_cfg_type(path):
    if CFGTYPE is None:
        filepath = path + 'cfgtype.ini'
        logger.info(filepath)
        gblCfp.read(filepath)
        cfgtype = gblCfp.get('cfg', "type")

        if cfgtype is None or cfgtype == "None":
            cfgtype = "development"

        return cfgtype
    else:
        return CFGTYPE


# 获取配置类型
def get_cfg_type_path():
    filepath = cofFile.get_app_loc() + 'cfgtype.ini'
    logger.info(filepath)
    return filepath


def set_cfg_type(env='test'):
    filepath = get_cfg_type_path()
    gblCfp.read(filepath)
    cfgtype = gblCfp.set('cfg', "type", env)
    gblCfp.write(open(filepath, "w"))
    return cfgtype


def is_dev_config():
    pass


def read_db_cfg(cfgfile, db):
    """读取数据配置数据"""
    cf = ConfigParser.ConfigParser()
    cf.read(cfgfile)
    dbcfg = dict()
    dbcfg['host'] = cf.get(db, "hostname")
    dbcfg['user'] = cf.get(db, "username")
    dbcfg['pass'] = cf.get(db, "password")
    dbcfg['db'] = cf.get(db, "database")
    return dbcfg


if __name__ == "__main__":
    o = MyCfg('cfg.ini')
    o.set_section('report')
    print o.get('path')
