# coding=utf-8

"""
httplib的一层封装，更易于使用

.. doctest::

    >>> http_obj = cofHttp.Http(url, 80)
    >>> http_obj.set_header(header)
    >>> http_obj.post


import logging
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                    datefmt='%a, %d %b %Y %H:%M:%S',
                    filename='api.log',
                    filemode='a'
                    )

console = logging.StreamHandler()
formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
console.setFormatter(formatter)
logging.getLogger('').addHandler(console)


if IMPORTLIB:
    import lib.url as LibUrlM
    import lib.log as LLog

    logger = LLog.Logger()
else:
    #import co_http.co_statis as LibUrlM
    import logger.ILogger as LogM
    logger = LogM.ILogger()
"""

import pprint
import time
import datetime
import urllib2
import httplib
import json
import logging
from .conf.conf import MyCfg
# from test_manager import TestManager
from poster.encode import multipart_encode
from poster.streaminghttp import register_openers
from restful import Restful
import socket

__author__ = 'Administrator'

# IMPORTLIB = False
API_MONITOR = False

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.setLevel(MyCfg.LOGLEVEL)
logger.info(__name__)


def get_current_time():
    """
    获取当前时间
    """
    current_time = int(time.time()) * 1000 + datetime.datetime.now().microsecond / 1000
    return current_time


def send_url_using(url):
    """
    向测试管理平台发送当前接口测试请求的url(不包括协议，host和port)
    """
    host = 'plot.qa.sdp.nd'
    testing_platform_url = '/api/v1.0/api-url'
    method = 'POST'
    headers = dict()
    body = {
        'url': str(url)
    }
    body = json.dumps(body)

    flag = False

    conn = None

    try:
        conn = httplib.HTTPConnection(host)
        conn.request(method, testing_platform_url, body, headers)
        response = conn.getresponse()
        if response.status == 200:
            flag = True
    except Exception, e:  # 连接错误 or 读取错误
        logger.info("记录接口运行")
        print 'error : ', str(e)

    if conn is not None:
        conn.close()


def print_response_time(res):
    """
    打印某个接口的响应时间

    :param res: 响应

    .. code-block:: js

        {
            'request':
            'response_time':
            'read_time'
        }

    函数签名：

        res -> void

    .. code-block:: python
        :linenos:

        >>> http_o = Http()
        >>> print_response_time(res)

    """
    print "*** 接口 '%s'\n响应时间：%sms\n读取时间：%sms ***" % (
        res['request'], str(res['response_time']), str(res['read_time'])
    )


class Http(object):
    """对GET/POST进行了封装，让代码更简短易读
    :class:`cof.http.Http` 先初始化

    * `METHOD`: 默认请求方法
    """
    DEBUG = False

    METHOD = "GET"

    def __init__(self, host, port=None, ssl=False, timeout=60):
        """
        使用httplib库进行操作
        """
        self.host = host
        self.port = port
        self.header = dict()
        self.params = None
        self.timeout = timeout

        # 端口处理+（url）请求前缀拼装
        if ssl:
            # 未指定端口，则使用默认端口
            if self.port is None or self.port == '':
                self.port = 443
            self.url = "https://" + str(host) + ':' + str(self.port)
            self.conn = httplib.HTTPSConnection(self.host, self.port, timeout=self.timeout)
        else:
            if self.port is None or self.port == '':
                self.port = 80
            self.url = "http://" + str(host) + ':' + str(self.port)
            self.conn = httplib.HTTPConnection(self.host, self.port, timeout=self.timeout)

        # self.test_manager = TestManager(20)

    def parse_url(self):
        pass

    def set_header(self, header):
        """
        设置http请求头，可以设置AccessToken等
        """
        self.header = header

    def send_request(self, res, method, url, headers, body=None):
        """
        封装发送请求的过程
        """
        conn = self.conn
        http_url = self.url + str(url)

        logger.info("发送请求 - send_request")
        logger.info(http_url)

        # flag = False

        begin_time = 0
        end_time = 0

        # 添加接口测试脚本的固定UA头
        if 'User-Agent' in headers.keys():
            user_agent = headers['User-Agent']
            if user_agent.find('ApiAutotest') == -1:  # 还没有，就加上；已经有就不用加了
                user_agent += '; ApiAutotest'
                headers['User-Agent'] = user_agent
        else:
            headers['User-Agent'] = 'ApiAutotest'
        headers['Qa-tag'] = '0'
        res['request_header'] = headers

        retry_count = 0 # 重试次数
        for i in xrange(2):
            try:
                begin_time = get_current_time()
                conn.request(method=method, url=url, headers=headers, body=body)
                response = conn.getresponse()
                end_time = get_current_time()

                # 状态码
                res["code"] = response.status

                # 响应的返回值
                res["data"] = response.read()

                # 响应的头信息
                res["response_header"] = response.msg.dict

                cookie = response.getheader("set-cookie")

                if cookie is not None:
                    start = cookie.find("JSESSIONID=")
                    end = cookie.find(";", start + 11)
                    jsession = str(cookie[start + 11:end])
                    res['jsession'] = jsession
                break
                # flag = True

                # self.test_manager.send_host_port(self.host, self.port)
                # self.test_manager.send_url(url, self.url)

            except socket.error, e:  # 连接错误 or 读取错误  只捕获socket超时异常、10060、11004
                # if end_time == 0:
                logger.error(e)
                if (e.errno == 10060 or e.errno == 11004) and retry_count == 0:  # 如果为10060防火墙异常\11004域名解析异常重试一次
                    conn.close()
                    retry_count += 1
                    print ("<p><span style=\"color:blue\">socket %s错误，重试一次<span></p><hr/>" % str(e.errno))
                    continue
                elif e.message == 'timed out':
                    end_time = get_current_time()
                    res["code"] = 0
                    res["data"] = '{"message": "%s"}' % (e)
                    res["response_header"] = {}
                    break
                else:
                    conn.close()
                    raise

        # 读完数据的时间
        read_time = get_current_time()

        # http响应的间隔时间，单位ms
        run_time = end_time - begin_time
        res["response_time"] = run_time
        print "运行时间：" + str(run_time) + "ms"

        # 读数据使用的间隔时间，单位ms
        res["read_time"] = read_time - end_time

        # print_response_time(res)

        logger.info(url)

        logger.info("===============================")
        if 'data' in res:
            logger.info(res["data"])

        conn.close()
        # return flag

    def send_request_by_api_monitor(self, res, method, url, headers, body=None):
        """
        接口监控平台的发送方法
        :param res:
        :param method:
        :param url:
        :param headers:
        :param body:
        :return:
        """
        conn = self.conn

        # 添加接口测试脚本的固定UA头
        if 'User-Agent' in headers.keys():
            user_agent = headers['User-Agent']
            if user_agent.find('ApiAutotest') == -1:  # 还没有，就加上；已经有就不用加了
                user_agent += '; ApiAutotest'
                headers['User-Agent'] = user_agent
        else:
            headers['User-Agent'] = 'ApiAutotest'
        headers['Qa-tag'] = '0'
        res['request_header'] = headers

        count = 1
        while True:
            retry_count = 0  # 重试次数
            for i in xrange(2):
                try:
                    start_time = time.time()

                    conn.request(method=method, url=url, headers=headers, body=body)
                    response = conn.getresponse()

                    stop_time = time.time()
                    res["code"] = response.status
                    res["data"] = response.read()
                    res["response_header"] = response.msg.dict
                    break
                except socket.error, e:  # 连接错误 or 读取错误  只捕获socket超时异常、10060、11004
                    # if end_time == 0:
                    logger.error(e)
                    if (e.errno == 10060 or e.errno == 11004) and retry_count == 0:  # 如果为10060防火墙异常\11004域名解析异常重试一次
                        conn.close()
                        retry_count += 1
                        print ("<p><span style=\"color:blue\">socket %s错误，重试一次<span></p><hr/>" % str(e.errno))
                        continue
                    elif e.message == 'timed out':
                        end_time = get_current_time()
                        res["code"] = 0
                        res["data"] = '{"message": "%s"}' % (e)
                        res["response_header"] = {}
                        break
                    else:
                        conn.close()
                        raise
            run_time = int((stop_time - start_time) * 1000 + 0.5)
            res["response_time"] = run_time
            print "运行时间：" + str(run_time) + "ms"
            logger.info(url)
            logger.info(body)
            logger.info("===============================")
            if 'data' in res:
                logger.info(res["data"])
            conn.close()
            if "iframe" not in res["data"] and "Bad Gateway" not in res["data"] or count > 10:
                # self.test_manager.send_host_port(self.host, self.port)
                # self.test_manager.send_url(url, self.url)
                break
            time.sleep(0.001)
            f = open("error_prase.txt", 'a+')
            f.write("Time:" + time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())))
            f.write("\n")
            f.write("请求的次数" + str(count) + "请求是:" + str(res["request"]) + "数据结果是:" + str(res["data"]))
            f.write("\n")
            f.write("\n")
            f.close()
            count += 1
            time.sleep(5)
        return res

    def get(self, url):
        """
        GET 请求

        :param url: 请求地址

        :return: 响应

        .. code-block:: python

            # 创建http对象
            >>> http_o = Http(host, port)
            # 执行请求
            >>> res = http_o.get(url)
            # 获取响应码
            >>> code = res['code']
            >>> data = res['data']
            # 如果是json的话，需要解码
            >>> data_dec = json_decode(data)

        """
        res = dict()
        res["request"] = "GET " + self.url + str(url)

        if API_MONITOR:
            self.send_request_by_api_monitor(res, 'GET', url, self.header)
        else:
            self.send_request(res, 'GET', url, self.header)

        return res

    def post(self, url, params=None):
        """

        :param url:
        :param params:
        :return:
        """
        conn = self.conn

        http_url = self.url + url

        logger.info("post url")
        logger.info(http_url)

        if isinstance(params, dict):
            params = json.dumps(params)

        res = dict()
        res["request"] = "POST " + self.url + str(url)
        if params is not None:
            res["request"] += ",\nbody=" + params

        if API_MONITOR:
            self.send_request_by_api_monitor(res, 'POST', url, self.header, body=params)
        else:
            self.send_request(res, 'POST', url, self.header, body=params)

        return res

    def delete(self, url, params=None):
        """
        DELETE请求

        :param url: 请求地址

        :param params: body参数

        :return:

        """
        res = dict()
        res["request"] = "DELETE " + self.url + str(url)
        if params is not None:
            res["request"] += ",\nbody=" + params

        if API_MONITOR:
            self.send_request_by_api_monitor(res, 'DELETE', url, self.header, body=params)
        else:
            self.send_request(res, 'DELETE', url, self.header, body=params)

        return res

    def patch(self, url, params=None):
        """
        PATCH 请求

        :param url:
        :param params:
        :return:
        """
        res = dict()
        res["request"] = "PATCH " + self.url + str(url)
        if params is not None:
            res["request"] += ",\nbody=" + params

        if API_MONITOR:
            self.send_request_by_api_monitor(res, 'PATCH', url, self.header, body=params)
        else:
            self.send_request(res, 'PATCH', url, self.header, body=params)

        return res

    def put(self, url, params=None):
        """
        PUT 请求，用于修改资源

        :param url:
        :param params:
        :return:
        """
        res = dict()
        res["request"] = "PUT " + self.url + str(url)
        if params is not None:
            res["request"] += ",\nbody=" + params

        if API_MONITOR:
            self.send_request_by_api_monitor(res, 'PUT', url, self.header, body=params)
        else:
            self.send_request(res, 'PUT', url, self.header, body=params)
        return res

    def upload_files(self, url_in, file_path, params):
        """
        文件上传的方法 - 目前仅拼装http协议的情况

        参数：

        :param url_in:         请求url

        :param file_path:   文件路径，包含文件名

        :param params:     上传文件需要带有的参数，字典格式
        """
        if self.port is None:
            url = "http://" + str(self.host) + str(url_in)
        else:
            url = "http://" + str(self.host) + ":" + str(self.port) + str(url_in)
        file_o = open(file_path, "rb")
        params["fileUpload"] = file_o

        register_openers()

        datagen, headers = multipart_encode(
            params
        )
        print datagen
        print headers
        print params

        # 创建请求对象
        request_handle = urllib2.Request(url, datagen, headers)

        res = dict()

        res['request'] = "POST " + str(url)

        begin_time = get_current_time()

        try:
            # 实际执行请求并取得返回
            response_handle = urllib2.urlopen(request_handle)
            res['code'] = response_handle.code
            res['data'] = response_handle.read()
            read_time = get_current_time()
            logger.info("发送主机统计信息")
            # self.test_manager.send_host_port(self.host, self.port)
            logger.info("发送调用信息")
            # self.test_manager.send_url(url_in)
        except urllib2.HTTPError as e:
            res['code'] = e.code
            res['data'] = e.read()
            read_time = get_current_time()

        end_time = get_current_time()
        res["response_time"] = end_time - begin_time
        res["read_time"] = read_time - end_time  # 读数据使用的间隔时间，单位ms

        # print_response_time(res)

        file_o.close()

        return res

    def post_upload_files(self, url,  file_params={}, text_params={}):
        """
        文件上传的方法 - 目前仅拼装http协议的情况

        参数：

        :param url:         请求url

        :param file_path:   文件路径，包含文件名

        :param file_params:     文件字典，如{"key1": "value1", "key2": "value2"}

        :param text_params:     上传文件需要带有的参数，字典格式
        """
        url = self.url + str(url)

        logger.info("发送请求 - send_request")
        logger.info(url)

        file_o_list = list()
        # 读取文件，并入总参数
        for k,v in file_params.items():
            file_o = open(v, "rb")
            text_params[k] = file_o
            file_o_list.append(file_o)

        register_openers()

        datagen, headers = multipart_encode(
            text_params
        )
        print datagen
        print headers
        print text_params

        # 创建请求头参数
        for k,v in self.header.items():
            if k != 'Content-Type':
                headers[k] = v

        begin_time = 0
        end_time = 0
        res = dict()

        # 添加接口测试脚本的固定UA头
        if 'User-Agent' in headers.keys():
            user_agent = headers['User-Agent']
            if user_agent.find('ApiAutotest') == -1:  # 还没有，就加上；已经有就不用加了
                user_agent += '; ApiAutotest'
                headers['User-Agent'] = user_agent
        else:
            headers['User-Agent'] = 'ApiAutotest'
        headers['Qa-tag'] = '0'
        res['request_header'] = headers

        # 创建请求对象
        request_handle = urllib2.Request(url, datagen, headers)

        res['request'] = "POST " + str(url)

        begin_time = get_current_time()

        retry_count = 0  # 重试次数
        for i in xrange(2):
            try:
                # 实际执行请求并取得返回
                response_handle = urllib2.urlopen(request_handle)
                end_time = get_current_time()
                res['code'] = response_handle.code
                res['data'] = response_handle.read()
                # 响应的头信息
                res["response_header"] = response_handle.headers.dict
                logger.info("发送主机统计信息")
                # self.test_manager.send_host_port(self.host, self.port)
                logger.info("发送调用信息")
                # self.test_manager.send_url(url_in)
                break
            except IOError, e:
                logger.error(e)
                if isinstance(e.reason, str) == False:
                    if (e.reason.errno == 10060 or e.reason.errno == 11004) and retry_count == 0:  # 如果为10060防火墙异常\11004域名解析异常重试一次
                        retry_count += 1
                        print ("<p><span style=\"color:blue\">socket %s错误，重试一次<span></p><hr/>" % str(e.reason.errno))
                        continue
                    elif e.reason.message == 'timed out':
                        end_time = get_current_time()
                        res["code"] = 0
                        res["data"] = '{"message": "%s"}' % (e)
                        res["response_header"] = {}
                        break
                for file_o in file_o_list:
                    file_o.close()
                raise

        # 读完数据的时间
        read_time = get_current_time()

        # http响应的间隔时间，单位ms
        run_time = end_time - begin_time
        res["response_time"] = run_time
        print "运行时间：" + str(run_time) + "ms"

        # 读数据使用的间隔时间，单位ms
        res["read_time"] = read_time - end_time

        logger.info("===============================")
        if 'data' in res:
            logger.info(res["data"])

        # print_response_time(res)

        for file_o in file_o_list:
            file_o.close()

        return res

if __name__ == '__main__':
    # http_o = Http("aqapi.101.com", 80, ssl=True)
    http_o = Http("aqapi.101.com", ssl=True)
    res = http_o.post("/v0.93/bearer_tokens", "")
    logger.info(res)
