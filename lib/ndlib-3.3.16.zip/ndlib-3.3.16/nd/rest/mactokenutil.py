__author__ = 'cl'

import random
import hashlib
from datetime import datetime as dt
from hmac import new as hmac
import base64

dtnull = dt(1970, 1, 1, 8)


def hmac256(content, key):
    data = hmac(key, content, hashlib.sha256).digest()
    return base64.b64encode(data)


def maxrnd(sum):
    rndStr = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    slen = len(rndStr) - 1
    outs = ""
    for i in range(0, sum):
        outs = outs + rndStr[random.randint(0, slen)]

    return outs


def getMacContent(host, method, path, token, macKey):
    ts = int((dt.now() - dtnull).total_seconds() * 1000)
    # ts = int(round(time.time() * 1000))
    nonce = str(ts) + ":" + maxrnd(8)
    print nonce
    # nonce="1428740526785:12345678"
    content = nonce + "\n" + method.upper() + "\n" + path + "\n" + host + "\n"
    macContent = hmac256(content, macKey)
    return "MAC id=\"" + token + "\",nonce=\"" + nonce + "\",mac=\"" + macContent + "\""
