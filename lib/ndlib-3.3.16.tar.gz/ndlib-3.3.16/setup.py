from setuptools import find_packages, setup

extra_opts = {
    "packages": ["nd"]
}

setup(
    name="ndlib",
    version="3.3.16",
    description="test framework for python",
    author="linzh",
    author_email="cleardo@gmail.com",
    platforms=["any"],  # or more specific, e.g. "win32", "cygwin", "osx"
    license="BSD",
    url="http://github.com/cleardo/cof",
    install_requires=['poster', 'pyhamcrest', 'tornado', 'pymongo<=2.8.1', 'six', 'pydes==2.0.1'],
    packages=find_packages(),
    package_data={
        'nd.jlibs': ['*.jar']
    },
    # **extra_opts
    # data_files=[('nd/jlibs', ['*.jar'])],
    # include_package_data=True,
)
