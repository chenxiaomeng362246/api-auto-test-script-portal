# coding=utf-8

# import json

import urllib2

from ..conf.conf import MyCfg

__author__ = 'linzh'

"""
http://www.pythonbackend.com/topic/1259317996

http://zhuoqiang.me/python-urllib2-usage.html

http://oldj.net/article/python-upload-file-via-form-post/
"""

"""
import logging
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                    datefmt='%a, %d %b %Y %H:%M:%S',
                    filename='api.log',
                    filemode='a'
                    )

console = logging.StreamHandler()
formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
console.setFormatter(formatter)
logging.getLogger('').addHandler(console)
"""

"""
if IMPORTLIB:
    import lib.url as LibUrlM
    import lib.log as LLog

    logger = LLog.Logger()
else:
    #import co_http.co_statis as LibUrlM
    import logger.ILogger as LogM
    logger = LogM.ILogger()
"""

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.setLevel(MyCfg.LOGLEVEL)
logger.info(__name__)


class Http(object):
    """
    使用urllib2 http库进行调用
    """
    def __init__(self, host, port=80, url="", ssl=False):
        self.host = host
        self.port = port
        self.header = dict()

        # 请求body
        self.params = None

        if ssl:
            scheme = 'https://'
        else:
            scheme = 'http://'

        self.req_url = scheme + host + ':' + port + url

    def set_header(self, header):
        # print header
        for k in header:
            v = header[k]
            self.conn.add_header(k, v)

    def post(self, url, params):
        self.conn = urllib2.Request(self.req_url)
        response = urllib2.urlopen(self.conn, params)
        res = response.read()
        return res

if __name__ == '__main__':
    host = "aqapi.101.com"
    port = 80
    http_o = Http(host, port, ssl=True)
    res = http_o.post("/v0.92/bearer_tokens", "")

