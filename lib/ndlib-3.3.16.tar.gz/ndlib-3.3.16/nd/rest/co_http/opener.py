# coding=utf-8
import cookielib
import urllib2

__author__ = 'linzh'

class Http(object):
    def __init__(self, host, port, url=''):
        cookies = cookielib.LWPCookieJar()

        handlers = [
            urllib2.HTTPHandler(),
            urllib2.HTTPSHandler(),
            urllib2.HTTPCookieProcessor(cookies)
        ]

        self.opener = urllib2.build_opener(*handlers)
        self.req_url = 'http://' + host + ':' + str(port)

    def set_header(self, header):
        # print header
        for k in header:
            v = header[k]
            self.opener.addheaders.append((k, v))

    def post(self, url, params):
        url = self.req_url + url
        req = urllib2.Request(url)
        return self.opener.open(req, params).read()

    def get(self, url):
        url = self.req_url + url
        req = urllib2.Request(url)
        return self.opener.open(req).read()

