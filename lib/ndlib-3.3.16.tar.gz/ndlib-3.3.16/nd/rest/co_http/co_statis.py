# coding=utf-8

__author__ = 'linzh'

def save_api(*args, **kwargs):
    pass


class IStatis(object):
    def save_api(self, *args, **kwargs):
        pass

