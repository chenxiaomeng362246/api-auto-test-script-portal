# coding=utf-8
import httplib
import time
from ..restful import Restful
import socket

__author__ = 'linzh'

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.info(__name__)


class Http(object):
    """对GET/POST进行了封装，让代码更简短易读 添加了获取jsession
    :class:`cof.http.Http` 先初始化

    * `METHOD`: 默认请求方法
    """

    METHOD = "GET"

    def __init__(self, host, port=80, url='', ssl=False, timeout=60):
        """
        使用httplib库进行操作
        """
        self.host = host
        self.port = str(port)
        if self.port == "":
            self.port = None
        self.url = url
        self.header = dict()
        self.timeout = timeout
        # 请求body
        self.params = None
        if ssl:
            self.conn = httplib.HTTPSConnection(self.host, self.port, timeout=self.timeout)
        else:
            self.conn = httplib.HTTPConnection(self.host, self.port, timeout=self.timeout)

    def parse_url(self):
        pass

    def set_header(self, header):
        """
        设置http请求头，可以设置AccessToken
        """
        self.header = header

    def send_request(self, res, method, url, headers, body=None):
        """
        封装发送请求的过程
        """
        retry_count = 0  # 重试次数
        for i in xrange(2):
            try:
                headers['Qa-tag'] = '0'
                start_time = time.time()
                conn = self.conn
                conn.request(method=method, url=url, headers=headers, body=body)
                response = conn.getresponse()
                stop_time = time.time()
                res["code"] = response.status
                res["data"] = response.read()
                res["request_header"] = headers
                res["response_header"] = response.getheaders()
                jsession = ""
                cookie = response.getheader("set-cookie")
                if cookie is not None:
                    start = cookie.find("JSESSIONID=")
                    end = cookie.find(";", start + 11)
                    jsession = str(cookie[start + 11:end])
                    res["jsession"] = jsession
                break
            except socket.error, e:  # 连接错误 or 读取错误  只捕获socket超时异常、10060、11004
                logger.error(e)
                if (e.errno == 10060 or e.errno == 11004) and retry_count == 0:  # 如果为10060防火墙异常\11004域名解析异常重试一次
                    conn.close()
                    retry_count += 1
                    print ("<p><span style=\"color:blue\">socket %s错误，重试一次<span></p><hr/>" % str(e.errno))
                    continue
                elif e.message == 'timed out':
                    stop_time = time.time()
                    res["code"] = 0
                    res["data"] = '{"message": "%s"}' % (e)
                    res["response_header"] = {}
                    break
                else:
                    conn.close()
                    raise
        run_time = int((stop_time - start_time) * 1000 + 0.5)
        res["response_time"] = run_time
        print "运行时间：" + str(run_time) + "ms"
        res["request_header"] = headers
        logger.info(url)
        logger.info("===============================")
        if 'data' in res:
            logger.info(res["data"])
        conn.close()

    def get(self, url):
        res = dict()
        if self.port is None:
            res["request"] = "GET " + self.host + url
        else:
            res["request"] = "GET " + self.host + ":" + self.port + url
        self.send_request(res, 'GET', url, self.header)
        return res

    def post(self, url, params):
        res = dict()
        if self.port is None:
            res["request"] = "POST " + self.host + url + ",\nbody=" + params
        else:
            res["request"] = "POST " + self.host + ":" + self.port + url + ",\nbody=" + params
        self.send_request(res, 'POST', url, self.header, body=params)
        return res

    def delete(self, url, params=None):
        res = dict()
        if self.port is None:
            res["request"] = "DELETE " + self.host + url
        else:
            res["request"] = "DELETE " + self.host + ":" + self.port + url
        if params != None:
            res["request"] += ",\nbody=" + params
        self.send_request(res, 'DELETE', url, self.header, body=params)
        return res

    def patch(self, url, params):
        res = dict()
        if self.port is None:
            res["request"] = "PATCH " + self.host + url + ",\nbody=" + params
        else:
            res["request"] = "PATCH " + self.host + ":" + self.port + url + ",\nbody=" + params
        self.send_request(res, 'PATCH', url, self.header, body=params)
        return res

    def put(self, url, params):
        res = dict()
        if self.port is None:
            res["request"] = "PUT " + self.host + url + ",\nbody=" + params
        else:
            res["request"] = "PUT " + self.host + ":" + self.port + url + ",\nbody=" + params
        self.send_request(res, 'PUT', url, self.header, body=params)
        return res
