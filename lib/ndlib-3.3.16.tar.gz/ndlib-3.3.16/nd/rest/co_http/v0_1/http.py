__author__ = 'linzh'

# import poster
# import json

"""
import logging
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                    datefmt='%a, %d %b %Y %H:%M:%S',
                    filename='api.log',
                    filemode='a'
                    )

console = logging.StreamHandler()
formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
console.setFormatter(formatter)
logging.getLogger('').addHandler(console)
"""

"""
if IMPORTLIB:
    import lib.url as LibUrlM
    import lib.log as LLog

    logger = LLog.Logger()
else:
    #import co_http.co_statis as LibUrlM
    import logger.ILogger as LogM
    logger = LogM.ILogger()
"""

