# coding=utf-8
from ..http import Http

__author__ = 'linzh'


class Rest(object):
    def __init__(self, host, port):
        self.http_o = Http(host, port)

        header = dict()

        self.http_o.set_header(header)

    def set_auth(self):
        pass

    def get(self, url, data=None):
        self.set_auth()
        pass

    def post(self, url, data=None):
        self.set_auth()
        pass

    def put(self, url, data=None):
        self.set_auth()
        pass

    def delete(self, url, data=None):
        self.set_auth()
        pass


