# coding=utf-8
__author__ = 'linzh'


class CoInte(object):
    """
    http库接口
    """

    def __init__(self):
        """

        """
        self.header = dict()
        pass

    def get(self, url):
        pass

    def post(self, url):
        pass

    def patch(self, url):
        pass

    def put(self, url):
        pass

    def delete(self, url):
        pass

    def set_header(self, header):
        """
        合并header
        当key不存在时，则进行设置
        """
        self.header = header
