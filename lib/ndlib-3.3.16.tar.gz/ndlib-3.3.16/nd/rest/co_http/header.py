# coding=utf-8

__author__ = 'linzh'


class HttpHeader(object):
    AUTH_KEY = ""
    GAEA_KEY = ""

    def __init__(self):
        self.header = dict()

    def get_header(self):
        return self.header
