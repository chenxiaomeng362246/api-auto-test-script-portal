# coding=utf-8

__author__ = 'linzh'

import numpy as np

class CoMatrix(object):
    def __init__(self, m):
        self.mt = np.array(m)

    def det(self):
        return np.linalg.det(self.mt)
