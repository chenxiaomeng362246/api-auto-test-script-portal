# coding=utf-8

__author__ = 'linzh'

import numpy as np


class CoMatrix(object):
    def __init__(self, m):
        # self.mt = np.array(l)
        self.mt = np.matrix(m)

    def get_type(self):
        """

        :return:
        """
        pass

    def is_int32(self):
        """

        :return:
        """
        pass

    def det(self):
        """
        计算行列式

        :return:
        """
        return np.linalg.det(self.mt)

    def dot(self, mt):
        """

        :param mt:
        :return:
        """
        np.dot(self.mt, mt)
