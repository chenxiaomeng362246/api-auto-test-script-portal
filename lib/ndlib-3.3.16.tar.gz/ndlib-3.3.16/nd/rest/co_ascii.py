# coding=utf-8

__author__ = 'linzh'


import binascii


def get_hex(str_in):
    """

    :param str_in:
    :return:
    """
    return binascii.hexlify(str_in)
