# coding=utf-8

__author__ = 'linzh'

import os
import socket

if os.name != "nt":
    # 非NT内核的操作系统
    import fcntl
    import struct

    def get_interface_ip(ifname):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        return socket.inet_ntoa(fcntl.ioctl(s.fileno(), 0x8915,
                                            struct.pack('256s', ifname[:15]))[20:24])

def get_lan_ip():
    """
    获取ip，返回网卡设置的ip

    .. code-block::python

        >>> ip = get_lan_ip()
        >>> print(ip)

    """
    ip = socket.gethostbyname(socket.gethostname())
    if ip.startswith("127.") and os.name != "nt":
        interfaces = [
            "eth0",
            "eth1",
            "eth2",
            "wlan0",
            "wlan1",
            "wifi0",
            "ath0",
            "ath1",
            "ppp0",
        ]
        for ifname in interfaces:
            try:
                ip = get_interface_ip(ifname)
                break
            except IOError:
                pass
    return ip

def get_ip():
    """
    获取主机名解析后的ip

    :return:
    """
    # hostname = socket.gethostname()
    # 先获取主机名
    local_ip = socket.gethostbyname(socket.gethostname())
    return local_ip


def main():
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.info(__name__)

    ip = get_ip()
    logger.info(ip)
    lan_ip = get_lan_ip()
    logger.info(lan_ip)


if __name__ == "__main__":
    main()
