# coding=utf-8

__author__ = 'linzh'

import cv2
import numpy as np


def thresh_callback(thresh, blur, img):
    """
    处理图像边界

    :param thresh:
    :param blur:
    :param img:
    :return:
    """
    edges = cv2.Canny(blur, thresh, thresh*2)

    drawing = np.zeros(img.shape, np.uint8)     # Image to draw the contours

    contours, hierarchy = cv2.findContours(edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    rtn = "output2.png"

    for cnt in contours:

        # color = np.random.randint(0,255,(3)).tolist()  # Select a random color
        color = [255, 255, 255]

        cv2.drawContours(drawing,[cnt],0,color,2)

    cv2.imwrite(rtn, drawing)

    return rtn

def gauss(ofile):
    """
    高斯法

    :param ofile:
    :return:
    """

    img = cv2.imread(ofile)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # 高斯
    blur = cv2.GaussianBlur(gray, (5,5), 0)

    return thresh_callback(100, blur, img)

