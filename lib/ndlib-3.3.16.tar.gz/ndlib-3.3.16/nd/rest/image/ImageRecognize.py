# coding=utf-8

# Source Generated with Decompyle++
# File: ImageRecognize.pyc (Python 2.7)

'''
Created on 2014-12-15
@author: LiWei
'''
import Image
import cv2

import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(filename)s[%(lineno)d] %(levelname)s %(message)s')
logger = logging.getLogger(__name__)
logger.info(__name__)


class ImageRecognize(object):
    '''
\t\tImage.resize can not  satisfy me ,have to change another way.
\t'''
    
    def uniteResolution(sourcePath, srcX=720, srcY=1280, orientation="", format = 'png'):
        """

        :param sourcePath:
        :param srcX:
        :param srcY:
        :param orientation:
        :param format:
        :return:
        """
        img = Image.open(sourcePath)

        size = img.size

        logger.info(size)

        sizelist = [size[0], size[1]]

        reimg = None

        if orientation == 1:
            # 旋转
            reimg = img.transpose(Image.ROTATE_90)

            temp = sizelist[0]

            sizelist[0] = sizelist[1]
            sizelist[1] = temp
            if srcX != size[1] or srcY != size[0]:
                reimg = reimg.resize((srcX, srcY))
        elif srcX != size[0] or srcY != size[1]:
            # 缩放
            reimg = img.resize((srcX, srcY))

        if reimg != None:
            reimg.save(sourcePath, format)

        return sizelist

    uniteResolution = staticmethod(uniteResolution)
    
    def imageComparison(templatePath, sourcePath, targetPath, defaultAccurate=0.5, defaultMethod = 'cv2.TM_CCOEFF_NORMED'):
        """

        :param templatePath:
        :param sourcePath:
        :param targetPath:

        :param defaultAccurate: 匹配精确度

        :param defaultMethod:
        :return:
        """
        result = {
            'match': False,
            'maxVal': 0,
            'maxLocX': 0,
            'maxLocY': 0
        }

        img_rgb = cv2.imread(sourcePath)

        img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)

        img_template = cv2.imread(templatePath, 0)

        # 获取模板宽高
        (w, h) = img_template.shape[::-1]

        logger.info(w)
        logger.info(h)

        method = eval(defaultMethod)

        res = cv2.matchTemplate(img_gray, img_template, method)

        (min_val, max_val, min_loc, max_loc) = cv2.minMaxLoc(res)

        if method in [
            cv2.TM_SQDIFF,
            cv2.TM_SQDIFF_NORMED]:
            top_left = min_loc
        else:
            top_left = max_loc

        bottom_right = (top_left[0] + w, top_left[1] + h)

        cv2.rectangle(img_rgb, top_left, bottom_right, (0, 0, 255), 2)

        cv2.imwrite(targetPath, img_rgb)

        if max_val >= defaultAccurate:
            result['match'] = True
            # 匹配度
            result['maxVal'] = max_val
            # 匹配坐标
            result['maxLocX'] = max_loc[0] + w / float(2)
            result['maxLocY'] = max_loc[1] + h / float(2)

        return result

    imageComparison = staticmethod(imageComparison)
    
    def proxy(templatePath, sourcePath, targetPath, srcX = 720, srcY = 1280, orientation = 0, defaultAccurate = 0.5):
        """

        :param templatePath:
        :param sourcePath: 原图片
        :param targetPath:
        :param srcX:
        :param srcY:
        :param orientation:
        :param defaultAccurate:
        :return:

        .code-block:: python

            >>> reco = ImageRecognize()

            # 进行图像比较，并返回比较结果
            >>> reco.imageComparison()

        """

        # 处理后的图片尺寸
        (targetX, targetY) = ImageRecognize.uniteResolution(sourcePath, srcX, srcY, orientation)

        #
        result = ImageRecognize.imageComparison(templatePath, sourcePath, targetPath, defaultAccurate)

        result['maxLocX'] = int((targetX / float(srcX)) * result['maxLocX'])

        result['maxLocY'] = int((targetY / float(srcY)) * result['maxLocY'])

        return result

    proxy = staticmethod(proxy)


if __name__ == '__main__':
    reco = ImageRecognize()
    # reco.proxy()

    pic_name = "pic001.png"

    # 进行缩放，并保存
    # reco.uniteResolution("pic001.png")
    res = reco.imageComparison(pic_name, pic_name, pic_name)
    logger.info(res)

