# coding=utf-8

"""
生成各种符合要求的随机串
"""
__author__ = 'Administrator'

import random
import string
import uuid


class CoRand(object):
    def __init__(self):
        pass

    @staticmethod
    def randomword(length):
        """
        生成指定长度的随机小写字母字符串
        """
        return ''.join(random.choice(string.lowercase) for i in range(length))

    # @staticmethod
    # def uuid(length=16):
    #     uuid_str = str(uuid.uuid4())
    #     # print uuid_str
    #     uuid_str = uuid_str.replace('-', '')
    #
    #     return uuid_str[:length]

    @staticmethod
    def uuid_str():
        return str(uuid.uuid4())

    @staticmethod
    def get_rand_num(num, start=0, end=100):
        serial_arr = list()
        rand_arr = list()
        i = start
        while i <= end:
            serial_arr.append(i)
            i += 1

        for i in range(num):
            rnd_num = random.choice(serial_arr)
            rand_arr.append(rnd_num)
            serial_arr.remove(rnd_num)

        return rand_arr

    @staticmethod
    def get_rand_int(start=0, end=100):
        return random.randrange(start, end)

    @staticmethod
    def randomwordspecialcode(length):
        """
        生成指定长度的随机标点字符串
        """
        return ''.join(random.choice(string.punctuation) for i in range(length))

    @staticmethod
    def randomwordmulcode(length):
        """
        生成指定长度的随机可打印字符字符串
        """
        return ''.join(random.choice(string.printable) for i in range(length))

    @staticmethod
    def randomword_typecode(length):
        return ''.join(random.choice(string.type_code) for i in range(length))

    @staticmethod
    def randomwordnumber(length):
        """
        生成指定长度的随机数字字符串
        """
        return ''.join(random.choice(string.digits) for i in range(length))

    @staticmethod
    def randomspecialwords(length):
        """
        生成指定长度的随机特殊字符串
        """
        return ''.join(random.choice('`~!@#$%^&*()-+={[}]|\\:;"\'<,>.?/') for i in range(length))

    @staticmethod
    def uuid(length=16):
        uuid_str = str(uuid.uuid4())
        # print uuid_str
        # uuid_str = uuid_str.replace('-', '')

        return uuid_str

    @staticmethod
    def randomdigits(length):
        """
        生成指定长度的随机数字字符串
        """
        return ''.join(random.choice(string.digits) for i in range(length))

    @staticmethod
    def randomletter(length):
        """
        生成指定长度的随机所有字母（大小写）字符串
        """
        return ''.join(random.choice(string.letters) for i in range(length))

    @staticmethod
    def randomupper(length):
        """
        生成指定长度的随机大写字母字符串
        """
        return ''.join(random.choice(string.uppercase) for i in range(length))

    @staticmethod
    def randomunicodechar(length):
        """
        生成指定长度的随机unicode中文字符
        """
        return ''.join(unichr(random.randint(0x4e00,0x9fbb)) for i in range(length))

if __name__ == "__main__":
    rand_o = CoRand()
    # 生成10个字符长度的字符串
    # print rand_o.randomword(10)
    # print rand_o.uuid()
    # print rand_o.get_rand_num(5, end=9)
    print rand_o.randomunicodechar(15)
