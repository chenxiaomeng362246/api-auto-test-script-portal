# coding=utf-8

__author__ = 'linzh'


class CoInfo(object):
    HOST = "plot.qa.sdp.nd"
    PORT = 80

    FormDataUrl = "/db_bind/test"

class GuiServerInfo(object):
    HOST = "127.0.0.1"
    PORT = 8882

    FormDataUrl = "/v1/"
