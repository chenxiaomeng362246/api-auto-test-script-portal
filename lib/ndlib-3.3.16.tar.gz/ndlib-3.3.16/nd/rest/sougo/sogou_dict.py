# -*- coding: UTF-8 -*-

import os
import collections
import time


class MyDict(object):
    d = None


def init(filename='SogouLabDic.dic'):
    """
    初始化
    """
    d = collections.defaultdict(lambda: 1)

    cur_dir = os.path.dirname(os.path.abspath(__file__))

    f = open(cur_dir + os.sep + filename, 'r')

    total = 0

    while True:

        line=f.readline()

        if not line: break

        word, freq = line.split('\t')[0:2]
        #print word.decode('gbk').encode('utf-8')
        #print freq

        # 进行平滑处理
        # smooth
        # 词频初始化+1，保证不会出现词频为0的情况
        total += int(freq)+1

        #print total

        try:
            # 使用unicode编码
            d[word.decode('gbk')] = int(freq)+1
        except Exception, e:
            d[word] = int(freq)+1

    f.close()

    d['_t_'] = total

    MyDict.d = d


def solve(s):
    """
    对s进行分词处理
    s: 要分词的字符串
    """

    # 字符串的长度
    l = len(s)

    # 初始化为全0
    p = [0 for i in range(l+1)]
    # print p

    # 最后个字变为1
    p[l] = 1

    # 初始化为全1
    div = [1 for i in range(l+1)]
    # print "div", div

    t = [1 for i in range(l)]

    d = MyDict.d

    for i in range(l-1, -1, -1):
        # l-1 到 -1
        for k in range(1, l-i+1):
            # l-i+1
            # 循环计算概率
            # print "i, k", i, k

            # 算出字典d中指定字符串的频率
            #print s[i:i+k]
            tmp = d[s[i:i+k]]

            if k > 1 and tmp == 1:
                # tmp 为0，表示频率为0
                continue

            #print "p i+k", i+k, p[i+k]
            #print "div i+k", div[i+k]
            # 乘以相同分母，比较分子
            # if(d[s[i:i+k]]*p[i+k]*div[i] > p[i]*d['_t_']*div[i+k]):
            if d[s[i:i+k]] * p[i+k] > p[i]:
                # 如果概率有变大

                # 更新p[i]为: 词频 * 概率
                p[i] = d[s[i:i+k]] * p[i+k]

                # 感觉没必要啊?
                div[i] = d['_t_']*div[i+k]

                t[i] = k

    i = 0

    res = []
    while i < l:
        # print s[i:i+t[i]],
        res.append(s[i:i+t[i]])
        i=i+t[i]

    # time.sleep(3)
    return res


if __name__ == '__main__':
    init()
    #print d

    s = "其中最简单的就是最大匹配的中文分词"
    # s="匹配的中文分词"

    s = s.decode('utf8')

    solve(s)


