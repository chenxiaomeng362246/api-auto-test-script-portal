# coding=utf-8

import socket
from ..http import Http
from ..restful import *

__author__ = 'laibaoyu'


class SendSLA(object):
    """
    发送测试报告到SLA监控平台的接口封装
    """

    def __init__(self):
        """
        初始化
        """
        self.host = "192.168.239.192"  # 生产环境地址
        self.url = "/YunPro/task/insertTask?a="
        self.port = 8080
        self.http_obj = Http(self.host, self.port)
        self.header = {
            "Content-Type": "application/json"
        }
        self.rest_o = Restful()

    def send(self, reportUrl, pro_id):
        """
       GET /YunPro/task/insertTask?a={"reportUrl":"URL","proId":"ID"}
        参数：
        proId     必填  项目id（平台分配给各项目对应的ID，可咨询林存旅）
        URL必填 拨测结果地址
        返回结果：
        {
          {"code":1,
            "message":"success"
            }
        }
        reportUrl: 测试报告地址
        proid: 项目ID
        """
        # 发送CS上的测试报告到接口监控平台
        self.http_obj.set_header(self.header)

        report_url = reportUrl.split('&')[0]
        url = self.url + '{"reportUrl":"' + str(report_url) + '","proId":"' + str(pro_id) + '"}'
        res = self.http_obj.get(url)
        try:
            if res['code'] == 200:
                if json.loads(res['data'])['code'] == 1:
                    print "Send test report to SLA monitoring platform success"
                else:
                    print "Send test report to SLA monitoring platform failed"
        except Exception, e:
            print "SLA Report Push failed, The server is exception"

    def send_local_report_url(self, report_local_url, pro_id):
        # 获取本地ip
        local_ip = socket.gethostbyname(socket.gethostname())
        port = '9111'  # 报告地址的端口，若使用默认端口（80）可以为空

        # 获取报告的相对目录，作为url目录
        if self.port:
            report_url = "http://" + local_ip + ":" + port + report_local_url
        else:
            report_url = "http://" + local_ip + report_local_url

        # 发送本机的测试报告到接口监控平台
        self.http_obj.set_header(self.header)

        url = self.url + '{"reportUrl":"' + str(report_url) + '","proId":"' + str(pro_id) + '"}'
        res = self.http_obj.get(url)
        try:
            if res['code'] == 200:
                if json.loads(res['data'])['code'] == 1:
                    print "Send test report to SLA monitoring platform success"
                else:
                    print "Send test report to SLA monitoring platform failed"
        except Exception, e:
            print "SLA Report Push failed, The server is exception"


if __name__ == "__main__":
    send_o = SendSLA()
    reportUrl = 'http://cdncs.101.com/v0.1/download?dentryId=a8868dce-89b4-4eaa-a0ae-6b207f8ebcab'
    proid = 13
    send_o.send(reportUrl, proid)
