# coding=utf-8

from unittest import skip
from unittest.case import _id

__author__ = 'linzh'

TAG = 3


def skipIf(condition, reason=""):
    """
    """
    if condition < TAG:
        return skip(reason)
    return _id
