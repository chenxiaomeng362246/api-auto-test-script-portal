# coding=utf-8

from tornado.escape import json_decode, json_encode

import os
from ..co_test.co_report import CoReport
from ..co_time.co_time import *
#from ..logger.log_func import Logger
from ..nd_cs.html import get_download_url
from ..co_test.parser import get_data

# 获取当前时间
date = get_date_ymd()  # 日期【20150213】
timestamp = str(get_ts())  # 时间戳【1423813170】

# 当前路径
path = os.path.abspath(__file__)
path = os.path.dirname(path)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
# logger = Logger("接口消息推送")
logger.info("接口消息推送" )


class Report(object):
    """
    测试结果报告数据结构

    """

    def __init__(self):
        self.title = ""
        self.total = 0
        self.success = 0
        self.fail = 0
        self.path = ""

        # 文件名
        self.filename = ""


def get_result(report_dir, report_title, report_filename="", jenkins_job="", report=CoReport()):
    """
    获取测试报告结果内容，组成推送信息

    report_dir：报告所在的文件夹路径

    :param report_dir: 报告路径

    :param report_title: 报告标题

    :param report_filename: 报告名称

    """

    # 打开文件
    file_path = report_dir + os.sep + report_filename

    logger.info(file_path)
    logger.info("文件大小-get_result")
    logger.info(os.path.getsize(file_path))

    if os.path.exists(file_path):
        # 上传
        from ..nd_cs import NdCs

        nd_cs_o = NdCs()

        session = nd_cs_o.get_session('10003732')

        nd_cs_o.set_file_path(report_dir + os.sep)

        logger.info("上传测试结果报告-runner")
        upload_res = nd_cs_o.upload_html(session['session'], session['path'] + u'/接口测试报告', report_filename)
        logger.info(upload_res)

        upload_res = upload_res['data']
        upload_res = json_decode(upload_res)
        dentry_id = upload_res['dentry_id']
    else:
        dentry_id = ""

    # from ..http import Http
    # host = "plot.qa.sdp.nd"
    # http_o = Http(host)
    # param = dict()
    # param["dentry_id"] = dentry_id
    # param["report_file"] = report_title
    # param["jenkins_job"] = jenkins_job
    # http_o.post("/api/v1.0/api-test", json_encode(param))

    file_object = open(file_path)

    all_the_text = ""

    try:
        all_the_text = file_object.read()
    finally:
        file_object.close()

    data = get_data(all_the_text)

    logger.info("总用例数")
    logger.info(data[-1]['total'])

    report_url = get_download_url(dentry_id)

    result = dict()
    result['title'] = "[" + data[0] + "]" + report_title + "测试结果"
    result['content'] = "所有测试： " + str(data[2]) + "个" \
                        + "，通过： " + str(data[3]) + "个" \
                        + "，错误： " + str(data[5]) + "个" \
                        + "，失败： " + str(data[4]) + "个" \
                        + "，通过率： " + str(data[6]) \
                        + "%，运行时间： " + str(data[1]) + "s"
    result['url'] = report_url.replace('&', '&amp;')
    result['failed'] = int(data[4] + data[5])

    report.set_case_count(data[2])
    report.set_success(data[3])
    report.set_fail(data[4])
    report.set_report_url(result['url'])

    logger.info("99U消息推送内容")
    logger.info(result)

    return result
