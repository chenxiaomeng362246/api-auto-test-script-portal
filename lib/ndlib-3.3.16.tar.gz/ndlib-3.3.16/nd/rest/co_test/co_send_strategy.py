# coding=utf-8
from ..co_test.co_config import CoConfig
from ..co_test.co_report import CoReport
import logging

__author__ = 'linzh'

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# logger = Logger("接口消息推送")


class CoSendStrategy(object):
    def __init__(self, report=CoReport(), config=CoConfig()):
        self.config = config
        self.report = report

    def to_send(self):
        logger.info("失败case")
        logger.info(self.report.fail)
        logger.info("测试配置")
        logger.info(self.config.monitor)

        # 有配置为“线上监控”时，则有失败才推送
        flag = True
        if self.config.monitor and self.report.has_fail() is False:
            flag = False

        return flag
