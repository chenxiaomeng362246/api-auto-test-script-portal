# coding=utf-8

__author__ = 'linzh'


def get_data(all_the_text):
    """
    获取结果报告中每一项的数值

    解析报告

    text:报告内容

    keyword：该项内容的关键字
    """
    # runtime
    start = all_the_text.find("<strong>该次测试执行于:</strong>")

    end = all_the_text.find("</p>", start+40)

    # runtime = str(all_the_text[start+40:end-1])
    # modify by api monitor
    runtime = str(all_the_text[start+40:end])

    # timeSpend
    start = all_the_text.find("<strong>接口运行时间:</strong>")
    end = all_the_text.find("</p>", start+37)

    time_spend = str(all_the_text[start+37:end])

    hour_end = time_spend.find(":")
    hour = int(time_spend[0:hour_end])

    min_start = hour_end+1
    min_end = time_spend.find(":", min_start)

    min = int(time_spend[min_start:min_end])

    second_start = min_end+1
    second_end = time_spend.find(".", second_start)

    second = int(time_spend[second_start:second_end])

    mis = time_spend[second_end:]

    time_spend = float(str(3600*hour+60*min+second)+mis)

    # total
    start = all_the_text.find("<td>Total</td>")
    end = all_the_text.find("</td>", start+23)
    total_num = int(all_the_text[start+23:end])

    # pass
    start = end
    end = all_the_text.find("</td>", start+14)
    pass_num = int(all_the_text[start+14:end])

    # failed
    start = end
    end = all_the_text.find("</td>", start+14)
    failed_num = int(all_the_text[start+14:end])

    # error
    start = end
    end = all_the_text.find("</td>", start+14)
    error_num = int(all_the_text[start+14:end])

    # percent + avgTime
    percent = 0.0

    avg_time = 0.0

    if total_num != 0:
        percent = int((float(total_num-failed_num-error_num)/total_num)*10000)/100.0
        avg_time = int(float(time_spend/total_num)*100)/100.0

    report_dict = dict()
    report_dict['total'] = total_num

    return [runtime, time_spend, total_num, pass_num, failed_num, error_num, percent, avg_time, report_dict]

