# coding=utf-8

__author__ = 'linzh'


class Page(object):
    """
    页面对象
    """
    def __init__(self):
        pass

