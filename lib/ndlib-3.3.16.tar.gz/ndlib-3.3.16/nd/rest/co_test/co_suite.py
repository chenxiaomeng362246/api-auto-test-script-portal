# coding=utf-8
from ..co_mongo.db_info import DbInfo
from ..mongo import MongodbConn
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

__author__ = 'linzh'


class CoSuite(object):
    def __init__(self):
        try:
            self.mongo = MongodbConn(DbInfo.MongoDev['host'], DbInfo.MongoDev['port'])
            self.mongo.set_coll("py_tests", "suites")
        except Exception, e:
            logger.info("DbInfo mongo connection failed")
            self.mongo = None
        self.suite_info = ""
        self.report_id = ""

    def set_suite_info(self, info):
        self.suite_info = info

    def set_report_id(self, rid):
        self.report_id = rid

    def save(self):
        data = dict()
        data['suite_info'] = self.suite_info
        data['report_id'] = self.report_id
        if self.mongo is not None:
            oid = self.mongo.add(data)
        else:
            oid = None
        return str(oid)
