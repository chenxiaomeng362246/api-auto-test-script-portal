# coding=utf-8
from ..co_test.co_config import CoConfig
from ..co_test.co_send_strategy import CoSendStrategy
from ..nd_im.new import SendNew99U
import logging
import urllib2
import json
import socket

__author__ = 'linzh'

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.info("接口消息推送")

__author__ = 'linzh'


class CoSender(object):
    """
    报告发送
    """

    def __init__(self, strategy=CoSendStrategy(), config=CoConfig()):
        self.strategy = strategy
        self.config = config

    def set_strategy(self, s):
        self.strategy = s

    def send(self, res):
        self.strategy.report.set_fail(res['failed'])

        if self.strategy.report.pro_id:
            self.send_mot(res)

        logger.info("推送99u")
        if self.strategy.to_send():
            logger.info("策略：允许消息推送")
            sender_o = SendNew99U()
            receivers = self.config.receivers
            group = self.config.group

            if len(receivers):
                if receivers is not None:
                    print "推送人："
                    print receivers
                    sender_o.send_to_receivers_in_box(res, receivers, 1)

            if len(group):
                if group is not None:
                    print "推送群："
                    print group
                    sender_o.send_to_receivers_in_box(res, group, 2, self.config.contact)

    def send_mot(self, res):
        """
        发送到线上监控平台
        """
        pro_id = str(self.strategy.report.pro_id)
        report_local_url = res['report_local_url']

        # 获取本地ip
        local_ip = socket.gethostbyname(socket.gethostname())
        port = "10000"  # 报告地址的端口，若使用默认端口（80）可以为空
        if port != "":
            report_url = "http://" + local_ip + ":" + port + "/project/pro_" + pro_id + report_local_url
        else:
            report_url = "http://" + local_ip + "/project/pro_" + pro_id + report_local_url
        print '传送数据至监控平台服务器', report_url
        url = 'http://192.168.239.192:8080/YunPro/task/insertTask?a={"reportUrl":"' + report_url + '","proId":' + pro_id + '}'
        print url

        req = urllib2.Request(url)
        res_data = urllib2.urlopen(req)
        res = res_data.read()
        res = json.loads(res)
        print '数据传送完毕', res
