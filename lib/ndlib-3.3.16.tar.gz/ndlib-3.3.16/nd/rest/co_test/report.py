# coding=utf-8
from ..co_os import OsInfo
from ..http import Http

import re
from xml.sax import saxutils

import types  # by linsixiao
import cgi    # by laibaoyu 将特殊字符转义为html字符

from . import __version__

# 基础模板
from ..co_test.base_tpl import Template_mixin

import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.info(__name__)
logger.info("测试框架报告")

#from ..logger.log_func import Logger

# logger = Logger("测试框架报告")


class Report(Template_mixin):
    """
    报告生成

    """

    def __init__(self):
        self.description = ""
        self.contact_info = ""
        # self.HTML_TMPL = ""
        self.HTML_TMPL = Template_mixin.HTML_TMPL

    def sortResult(self, result_list):
        # unittest does not seems to run in any particular order.
        # Here at least we want to group them together by class.
        # 排序
        rmap = {}
        classes = []
        for n, t, o, e in result_list:
            cls = t.__class__  # by laibaoyu
            # cls = t.context  # by linsixiao
            if not rmap.has_key(cls):
                rmap[cls] = []
                classes.append(cls)
            rmap[cls].append((n, t, o, e))
        r = [(cls, rmap[cls]) for cls in classes]
        return r

    def getReportAttributes(self, result):
        """
        Return report attributes as a list of (name, value).
        Override this to add custom attributes.

        执行时间点
        运行时长
        通过数
        """

        logger.info("获取报告属性")

        startTime = str(self.startTime)[:19]

        duration = str(self.stopTime - self.startTime)

        status = []

        if result.success_count: status.append(u'通过 %s' % result.success_count)
        if result.failure_count: status.append(u'失败 %s' % result.failure_count)
        if result.error_count:
            status.append(u'错误 %s' % result.error_count)

        if status:
            status = ' '.join(status)
        else:
            status = 'none'

        return [
            (u'该次测试执行于', startTime),
            (u'接口运行时间', duration),
            (u'状态', status),
        ]

    def set_template(self, content):
        self.HTML_TMPL = content

    def generateReport(self, test, result, contact=None):
        """
        生成报告

        :param test: 用例列表

        :param result: 测试结果

        :param contact: 联系方式

        """
        print "测试生成器", test

        report_attrs = self.getReportAttributes(result)

        logger.info("报告属性-generateReport")
        logger.info(test)
        logger.info(report_attrs)

        generator = 'HTMLTestRunner %s' % __version__

        logger.info(generator)

        stylesheet = self._generate_stylesheet()

        heading = self._generate_heading(report_attrs, contact)

        report = self._generate_report(result)

        ending = self._generate_ending()

        # 填充变量

        output = self.HTML_TMPL % dict(title=saxutils.escape(self.title),
            generator=generator,
            stylesheet = stylesheet,
            heading = heading,
            report = report,
            ending=ending,
        )

        self.stream.write(output.encode('utf8'))

    def _generate_stylesheet(self):
        """
        样式
        """
        return self.STYLESHEET_TMPL

    def _generate_heading(self, report_attrs, contact=None):
        """
        #. 生成标题
        #.

        """
        a_lines = []

        for name, value in report_attrs:
            line = self.HEADING_ATTRIBUTE_TMPL % dict(
                name=saxutils.escape(name),
                value=saxutils.escape(value),
            )

            a_lines.append(line)

        logger.info("generate heading")
        logger.info(contact)
        if contact:
            self.contact_info += "<h5><b>紧急联系人：</b></h5>"
            for k in contact:
                info = ''
                if k == 'users':
                    for user in contact[k]:
                        if info:
                            info += '，'
                        info += user
                    k = '联系人'
                else:
                    info = str(contact[k])
                self.contact_info += '<p>'
                self.contact_info += k + '(' + info + ')'
                self.contact_info += '</p>'

        heading = self.HEADING_TMPL % dict(
            title=saxutils.escape(self.title),
            parameters=''.join(a_lines),
            contact=self.contact_info,
            description=saxutils.escape(self.description),
        )

        logger.info("报告头")
        logger.info(self.description)

        return heading

    def _generate_report(self, result):
        """
        生成测试报告

        结果
        """
        logger.info("_generate_report")

        # 测试类
        rows = []

        # 对测试结果进行排序
        sortedResult = self.sortResult(result.result)

        logger.info("测试结果排序")
        logger.info(sortedResult)

        logger.info("用例状态")
        for cid, (cls, cls_results) in enumerate(sortedResult):
            # subtotal for a class
            np = nf = ne = 0

            logger.info("cid")
            logger.info(cid)
            logger.info(cls)
            for n, t, o, e in cls_results:
                case_status = n
                logger.info(case_status)
                logger.info("t-测试用例")
                logger.info(t)
                logger.info("用例输出")
                case_output = o
                logger.info(case_output)
                case_error = e
                logger.info("用例错误堆栈")
                logger.info(case_error)
                logger.info(e)
                if n == 0:
                    np += 1
                elif n == 1:
                    nf += 1
                else:
                    ne += 1

            # format class description  # by linsixiao
            desc = ""

            # print "type:", str(type(cls))

            if (type(cls) is types.ClassType):
                desc = str(cls)
            elif (type(cls) is types.ModuleType):
                desc = cls.__name__
            elif (type(cls) is types.TypeType):
                if cls.__module__ == "__main__":
                    name = cls.__name__
                else:
                    name = "%s.%s" % (cls.__module__, cls.__name__)
                    doc = cls.__doc__ and cls.__doc__.split("\n")[0] or ""
                    desc = doc and '%s: %s' % (name, doc) or name
            else:
                print "error type"
            # print "dec:", desc

            row = self.REPORT_CLASS_TMPL % dict(
                style=ne > 0 and 'errorClass' or nf > 0 and 'failClass' or 'passClass',
                desc=desc,
                count=np + nf + ne,  # 总用例数
                Pass=np,
                fail=nf,
                error=ne,
                cid='c%s' % (cid + 1),
            )

            rows.append(row)

            # 构造测试用例结果行
            for tid, (n, t, o, e) in enumerate(cls_results):
                self._generate_report_test(rows, cid, tid, n, t, o, e)

        # 使用构造的行，生成报告
        report = self.REPORT_TMPL % dict(
            test_list=''.join(rows),
            count=str(result.success_count + result.failure_count + result.error_count),
            Pass=str(result.success_count),
            fail=str(result.failure_count),
            error=str(result.error_count),
        )

        return report

    def _generate_report_test(self, rows, cid, tid, n, t, o, e):
        """
        生成测试报告

        :param rows: 用例表格行

        """
        # e.g. 'pt1.1', 'ft1.1', etc
        logger.info("generate report test - 生成测试报告")
        logger.info("用例数")
        logger.info(n)

        # test cases
        logger.info(t)

        logger.info("test cases")
        logger.info(o)
        logger.info(e)

        has_output = bool(o or e)

        tid = (n == 0 and 'p' or 'f') + 't%s.%s' % (cid + 1, tid + 1)

        name = t.id().split('.')[-1]

        try:
            if t._testMethodDoc is not None:                # 增加用例描述为空，类型为None判断 add laibaoyu
                t._testMethodDoc = t._testMethodDoc.strip()  # 预先处理前后空格 add laibaoyu
        except AttributeError:
            pass
        doc = t.shortDescription() or ""

        """
        desc = doc and ('%s: %s' % (name, doc)) or name
        desc_str = str(t._testMethodDoc)
        desc_str_arr = desc_str.split('\n')
        if len(desc_str_arr) > 1:
           desc += "(" + desc_str_arr[1].strip() + ")"
        else:
           desc += "()"
        """

        desc = name + "(" + cgi.escape(doc, quote='"') + ")"  # by laibaoyu  转义特殊字符为html能识别的字符

        if hasattr(t, "spend_time"):
            spend_time = t.spend_time  # add by linsixiao
        else:
            spend_time = '0'

        logger.debug("运行时间: " + str(spend_time))

        logger.info("模板")
        logger.info(has_output)
        tmpl = has_output and self.REPORT_TEST_WITH_OUTPUT_TMPL or self.REPORT_TEST_NO_OUTPUT_TMPL

        # output
        # o and e should be byte string because they are collected from stdout and stderr?
        if isinstance(o, str):
            # TODO: some problem with 'string_escape': it escape \n and mess up formating
            # uo = unicode(o.encode('string_escape'))
            # uo = o.decode('latin-1')
            uo = o.decode('utf-8')
        else:
            uo = o

        # error
        if isinstance(e, str):
            # TODO: some problem with 'string_escape': it escape \n and mess up formating
            # ue = unicode(e.encode('string_escape'))
            # ue = e.decode('latin-1')
            logger.info("错误输出")
            logger.info(e)

            if OsInfo.is_linux():
                ue = e.decode('utf-8')
            else:
                # unicode
                # ue = e.decode('latin-1').encode('utf-8')
                # 转义字符串(UTF-8和GBK字符将被强制转义为unicode)
                # ue = unicode(e.encode('string_escape'))
                try:
                    ue = e.decode('utf-8')
                except Exception, err:
                    logger.info("处理错误时发生编码异常")
                    logger.info(Exception)
                    print str(t)
                    print "*** testcase error info decode error happened ***"
                    print str(err)
                    ue = unicode(e.encode('string_escape'))

                ue = ue.encode('utf-8')
        else:
            ue = e

        script_str = saxutils.escape(ue)

        if OsInfo.is_linux():
            script = self.REPORT_TEST_OUTPUT_TMPL % dict(id=tid, output=saxutils.escape(uo+ue), )
        else:
            # 处理异常 codec can't decode byte 0xd4
            script = self.REPORT_TEST_OUTPUT_TMPL % dict(id=tid, output=script_str, )

        # script = str(script)
        logger.info(script)
        logger.info(spend_time)

        # 替换为<br>
        # script = re.sub('\n', '&lt;br&gt;', script)

        # can't decode byte 0xd4
        # script = script.decode('latin-1').encode("utf-8")

        row = tmpl % dict(
            tid=tid,
            Class=(n == 0 and 'hiddenRow' or 'none'),
            style=(n == 2 and 'errorCase' or (n == 1 and 'failCase' or 'none')),
            desc=desc,
            script=script,
            status=self.STATUS[n],
            time=spend_time       # 单个用例所花费的时间  add by linsixiao
        )

        rows.append(row)

        if not has_output:
            return

    def _generate_ending(self):
        return self.ENDING_TMPL


def get_cs_url(dentry_id):
    """

    :param dentry_id:

    :return:
    """

    host = "plot.qa.sdp.nd"

    http_o = Http(host)

    res = http_o.get("/v1.0/report?dentry_id" + dentry_id)

    logger.info(res)
