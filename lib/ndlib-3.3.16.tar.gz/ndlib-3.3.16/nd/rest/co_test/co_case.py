# coding=utf-8
from ..co_mongo.db_info import DbInfo
from ..mongo import MongodbConn
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

__author__ = 'linzh'


class CoCase(object):
    CASE_ID = ""

    def __init__(self):
        try:
            self.mongo = MongodbConn(DbInfo.MongoDev['host'], DbInfo.MongoDev['port'])
            self.mongo.set_coll("py_tests", "cases")
        except Exception, e:
            logger.info("DbInfo mongo connection failed")
            self.mongo = None

        self.report_id = ""
        self.case_name = ""
        self.case_doc = ""
        self.path = ""
        self.log_path = ""
        self.html_path = ""
        self.status = ""
        self.snap_url = ""
        self.exception = ""

    def set_case_doc(self, doc):
        self.case_doc = doc

    def set_case_name(self, name):
        self.case_name = name

    def set_report_id(self, report_id):
        self.report_id = report_id

    def set_path(self, p):
        self.path = p

    def save(self):
        data = dict()
        data['case_name'] = self.case_name
        data['path'] = self.path
        data['log_path'] = self.log_path
        data['html_path'] = self.html_path
        data['report_id'] = self.report_id
        data['status'] = self.status
        data['snap_url'] = self.snap_url
        data['exception'] = self.exception
        data['case_doc'] = self.case_doc

        return self.mongo.add(data)

    def load_case_info(self):
        """

        :return:
        """
        return CoCase.CASE_ID

    def update(self, log_path=None, report_id=None, exception=None, snap_url=None, status=None, report_url=None):
        data = dict()

        if log_path:
            data['log_path'] = log_path
        if report_id:
            data['report_id'] = report_id
        if exception:
            data['exception'] = exception
        if snap_url:
            data['snap_url'] = snap_url
        if status:
            data['status'] = status
        if report_url:
            data['html_path'] = report_url

        self.mongo.update(CoCase.CASE_ID, data)
