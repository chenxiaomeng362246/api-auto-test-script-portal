# coding=utf-8

__author__ = 'linzh'


class CoMedia(object):
    def __init__(self):
        pass

    def output(self):
        pass
