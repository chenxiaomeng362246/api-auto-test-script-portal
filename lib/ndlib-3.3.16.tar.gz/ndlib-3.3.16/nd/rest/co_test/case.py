# coding=utf-8

__author__ = 'linzh'


import unittest
from hamcrest import *

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.info(__name__)


class Case(unittest.TestCase):
    def __init__(self, *args, **kwargs):
        super(Case, self).__init__(*args, **kwargs)

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def assert_code(self, code, code_rtn):
        assert_that(code_rtn, equal_to(code), "HTTP响应码应该为" + str(code) + "，但是为" + str(code_rtn))

    def get_tag(self, doc):
        """
        从 doc 提取tag
        """
        return 0

    def run(self, result=None):
        logger.info(self._testMethodDoc)
        logger.info(getattr(self, self._testMethodName))

        if self._testMethodDoc:
            # 解析注释，提取tag
            tag = self.get_tag(self._testMethodDoc)

            if not tag:
                super(Case, self).run(result)
            else:
                pass

