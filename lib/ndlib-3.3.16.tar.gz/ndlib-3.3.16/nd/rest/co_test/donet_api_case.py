# coding=utf-8
from ..co_test.api_nd_case import ApiNdCase

__author__ = 'linzh'


class DonetApiCase(ApiNdCase):
    OK_CODE = 200
    SERVER_ERROR = 500000

    def __init__(self, *args, **kwargs):
        super(DonetApiCase, self).__init__(*args, **kwargs)
