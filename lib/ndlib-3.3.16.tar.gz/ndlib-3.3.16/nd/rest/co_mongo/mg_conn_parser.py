# coding=utf-8

__author__ = 'linzh'

class CoMgConnParser(object):
    """
    解析mongodb数据库连接字符串

    """

    def __init__(self):
        pass

    def parser(self):
        """

        :return:
        """
