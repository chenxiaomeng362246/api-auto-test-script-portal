# coding=utf-8

from ..mysql import *
from ..rand import CoRand


__author__ = 'linzh'


mysql_o = MysqlConn()
conn = mysql_o.get_def_conn()


def get_user_by_name(name):
    sql = """
    SELECT user_id, name, work_nr
    FROM user
    WHERE name="%s"
    """ % (name)
    print sql
    rec = conn.exec_sql(sql)
    data = dict()
    if len(rec) > 0:
        item = rec[0]
        data["id"] = item[0]
        data["name"] = item[1]
        data["work_nr"] = item[2]
        return data
    else:
        return None


def get_qa_list():
    sql = """
    SELECT user_id, name, work_nr
    FROM user
    """

    user_list = list()

    rec = conn.exec_sql(sql)

    for item in rec:
        user = dict()
        user["id"] = item[0]
        user["name"] = item[1]
        user["uid"] = item[2]
        user_list.append(user)

    return user_list


def add_user(name, work_nr, pwd="123456", leader_nr="871101", key="F9X6L8PWD", ver="dev"):
    from ..co_md5 import get_md5
    pwd1 = get_md5(key + pwd + ver)
    pwd2 = get_md5(pwd1)
    rand_o = CoRand()
    data = dict()
    data["user_id"] = rand_o.uuid()
    data["name"] = name
    data["work_nr"] = work_nr
    data["leader_nr"] = leader_nr
    data["password"] = pwd2
    data["kind"] = 0
    data["ukey"] = 0
    data["unit_id"] = 0
    data["is_leader"] = 0

    # 不存在时
    user = get_user_by_name(name)
    if not user:
        conn.set_table("user")
        conn.save(data)

    print user


def get_sdp_qa():
    conf_o = CoConfM.MyCfg("team.ini")
    members = conf_o.get_section("members")
    return members


if __name__ == "__main__":
    print "start..."

    user_list = get_qa_list()

    users = get_sdp_qa()

    for user in users:
        # print user[0]
        name = user[1]
        print name
        add_user(user[1], user[0])
    # get_user_by_name("林志宏")
    # add_user("王欢", "140521")
    # add_user("刘东", "512104")
    add_user("陈钦", "606290")
    add_user("卢七珍", "117121")
