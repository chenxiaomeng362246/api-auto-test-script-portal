# coding=utf-8
from cof.thread import Thread

__author__ = 'linzh'


class ThreadVar(object):
    def __init__(self):
        self.var = 2

    def run(self):
        def set_var(v):
            self.var = v

        Thread(set_var, 3)

        print self.var


if __name__ == '__main__':
    o = ThreadVar()
    o.run()
