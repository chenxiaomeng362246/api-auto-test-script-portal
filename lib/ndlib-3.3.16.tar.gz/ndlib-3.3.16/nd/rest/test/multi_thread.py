# coding=utf-8
import time
from cof.logger.log_func import Logger
from cof.thread import Thread

__author__ = 'linzh'

# logger = Logger("test01")

import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(filename)s[%(lineno)d] %(levelname)s %(message)s')
logger = logging.getLogger(__name__)
logger.info(__name__)


class ThreadRun(object):
    def __init__(self):
        self.share = 0

    def run(self):
        def func1():
            logger.info("func1")

        t1 = Thread(func1)
        logger.info(t1)
        t1.join()

        def func2():
            time.sleep(3)
            logger.info("func2")

        t2 = Thread(func2)
        logger.info(t2)
        t2.join()

        def func3():
            logger.info("func3")

        Thread(func3)


if __name__ == '__main__':
    o = ThreadRun()
    o.run()
