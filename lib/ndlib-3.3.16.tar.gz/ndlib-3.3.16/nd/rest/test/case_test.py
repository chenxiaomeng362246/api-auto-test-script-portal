# coding=utf-8

__author__ = 'linzh'


import sys
sys.path.insert(0, '..')


from cof.co_test.comment import main

main()

