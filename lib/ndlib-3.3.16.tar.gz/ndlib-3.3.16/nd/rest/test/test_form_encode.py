# coding=utf-8
from ..co_http.form_creator import FormCreator
from ..co_test.nd_case import NdCase

__author__ = 'linzh'

from hamcrest import *


class FormEncodeTest(NdCase):
    def test_encode(self):
        """

        :return:
        """
        form_creator = FormCreator()

        fields = [('name', 'myname'), ('test_xml', '<Task></Task>')]

        encode_res = form_creator.form_encode(fields)

        print encode_res

    def test_encode_str(self):
        """

        :return:
        """
        form_creator = FormCreator()

        fields = [('name', 'myname'), ('test_xml', '<Task></Task>')]

        encode_res = form_creator.get_form_str(fields)

        assert_that(encode_res, is_(str))

    def test_encode_dict(self):
        """

        :return:
        """

        data = dict()
        data['name'] = 'creat_ta'
        data['task_xml'] = '<Task></Task>'

