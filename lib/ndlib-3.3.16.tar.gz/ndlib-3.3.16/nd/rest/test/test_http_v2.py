# coding=utf-8
from poster.encode import multipart_encode
from ..co_conf.CoInfo import CoInfo
from ..co_http.co_curl import Http
from ..co_test.api_nd_case import ApiNdCase

__author__ = 'linzh'


class HttpTestV2(ApiNdCase):
    def test_form_data(self):
        """
        测试 form-data

        :return:
        """
        http_o = Http(CoInfo.HOST)

        data = dict()
        data['name'] = 'creat_ta'
        data['task_xml'] = '<Task></Task>'

        # data = multipart_encode(data)

        res = http_o.post(CoInfo.FormDataUrl, data)

        self.rest_o.parse_response(res, self.GET_OK, "")
