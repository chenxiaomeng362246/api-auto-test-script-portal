# coding=utf-8

__author__ = 'linzh'

from prettytable import PrettyTable

job = ['introduce', 'attention', 'teachers']

x = PrettyTable(job)

x.add_row(['测试简介', '注意事项', "[{'uc_user_id': '871101@nd'}]"])

print x
