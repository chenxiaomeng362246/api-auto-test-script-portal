# coding=utf-8

__author__ = 'linzh'

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.info(__name__)

import sys
sys.path.insert(0, '..')

from cof.nd_uc import NdUc


nd_uc_o = NdUc()

password_md5 = nd_uc_o.get_password_md5('123456')

logger.info(password_md5)

bearer_token = nd_uc_o.get_bearer_token('waf_loginer', '123456')

logger.info(bearer_token)

token_info = nd_uc_o.get_token('10003732@nd', 'lm213215')

logger.info(token_info)

server_time = nd_uc_o.get_server_time()
logger.info(server_time)

token = nd_uc_o.get_access_token(token_info['access_token'], server_time, 'GET', '/api', token_info['mac_key'])