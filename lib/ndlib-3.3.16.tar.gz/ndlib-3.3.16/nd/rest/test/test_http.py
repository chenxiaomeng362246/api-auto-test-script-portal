# coding=utf-8
from ..co_test.nd_case import NdCase
from ..http import Http
from ..logger.log_func import Logger

__author__ = 'linzh'

logger = Logger("接口测试框架单元测试-" + __name__)


class HttpTest(NdCase):
    def setUp(self):
        pass

    def test_get(self):
        pass

    def test_uc(self):
        """
        测试UC

        :return:
        """
        http_o = Http("aqapi.101.com", 443, ssl=True)
        res = http_o.post("/v0.93/bearer_tokens", "")
        logger.info(res)

