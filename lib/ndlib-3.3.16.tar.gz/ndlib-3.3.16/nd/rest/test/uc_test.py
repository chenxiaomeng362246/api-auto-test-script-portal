# coding=utf-8

import sys
sys.path.insert(0, '../../../')

from cof.nd_uc import NdUc
from cof.co_test.nd_case import NdCase

__author__ = 'linzh'


class UcTest(NdCase):
    def setUp(self):
        self.uc_o = NdUc()

    def test_md5(self):
        """

        :return:
        """
        self.uc_o.get_password_md5("123456")

