# coding=utf-8
from ..co_conf.CoInfo import CoInfo, GuiServerInfo
from ..co_http.form_creator import FormCreator
from ..co_test.api_nd_case import ApiNdCase
from ..http import Http

__author__ = 'linzh'


class HttpTestV1(ApiNdCase):
    def setUp(self):
        pass

    def test_form_data(self):
        """

        :return:
        """
        http_o = Http(GuiServerInfo.HOST, GuiServerInfo.PORT)

        form_creator = FormCreator()

        fields = [('name', 'myname'), ('test_xml', '<Task></Task>')]

        data = form_creator.get_form_str(fields)

        res = http_o.post(GuiServerInfo.FormDataUrl, data)

        self.rest_o.parse_response(res, self.GET_OK, "")

