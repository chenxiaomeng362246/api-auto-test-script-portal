# coding=utf-8
from cof.nd_cs import NdCs
from cof.co_test.nd_case import NdCase

__author__ = 'linzh'

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.info(__name__)


class CsTest(NdCase):
    def setUp(self):
        self.cs_o = NdCs()

    def test_session(self):
        session = self.cs_o.get_session()
        logger.info("会话信息")
        logger.info(session)

