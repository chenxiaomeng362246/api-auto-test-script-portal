# coding=utf-8
from cof.android.coa_dev import CoaDev
from cof.co_test.nd_case import NdCase

__author__ = 'linzh'

import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(filename)s[%(lineno)d] %(levelname)s %(message)s')
logger = logging.getLogger(__name__)
logger.info(__name__)


class DevTest(NdCase):
    def test_get_dev(self):
        """
        case: 测试设备获取

        :return:
        """
        dev_o = CoaDev()
        sid = dev_o.getDeviceSerial()

        logger.info(sid)

