# coding=utf-8
from ..co_test.nd_case import NdCase
from ..nd_uc import NdUc

__author__ = 'linzh'


class BearerTest(NdCase):
    def setUp(self):
        self.uc_o = NdUc()

    def test_get_tok(self):
        """

        :return:
        """
        tok = self.uc_o.get_bearer_token('971643', '80fba977d063a6f7262a8a9c95f61140', True)
        print tok

