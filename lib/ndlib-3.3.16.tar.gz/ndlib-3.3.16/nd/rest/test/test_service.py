# coding=utf-8

__author__ = 'linzh'

import sys
sys.path.insert(0, '..')

from cof.service import Service

service = Service()

base_url = service.get_url()

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.info(__name__)

logger.info(base_url)

data = {
    "dentry_id": "http://www.baidu.com",
    "report_file": "elearning"
}

res = service.send_test(data)
logger.info(res)
