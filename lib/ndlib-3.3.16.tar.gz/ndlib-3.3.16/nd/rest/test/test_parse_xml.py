# coding=utf-8
from ..co_test.nd_case import NdCase

from bs4 import BeautifulSoup

__author__ = 'linzh'


data = """
    <Jobs>
            <Task>
            <target>172.24.133.166-centos.flexWeb.tomcat.inner.stage</target>
            <function>sdp_tomcat_salt_null.create_instance</function>
            <args>
                <arg>
                    {"server_ip":"172.24.133.166",
                    "app_name":"tomcat_demo",
                    "domain":"demo.sdv.nd.test",
                    "port":"8080",
                    "reh":"172.24.133.166-centos.flexWeb.tomcat.inner.stage",
                    "jdk_version":"1.7.01",
                    "protocol":"http",
                    "container_version":"tomcat1.7",
                    "cpu":"2",
                    "memory":"2048",
                    "java_opts":"-server -Xms512m -Xmx512m  -XX:MaxNewSize=256m -XX:PermSize=512M -XX:MaxPermSize=512m",
                    "max_threads":"150",
                    "min_spare_threads":"75"}
                </arg>
            </args>
        </Task>
    </Jobs>
"""

class ParseXmlTest(NdCase):
    def setUp(self):
        pass

    def test_get_tree(self):
        """

        :return:
        """
        # print data
        soup = BeautifulSoup(data, "lxml")

        # print soup.html.body.jobs
        # print soup.jobs
        print soup.function.text

    def test_xml_tree(self):
        """

        :return:
        """
        import xml.etree.ElementTree as ET
        root = ET.fromstring(data)
        print root.tag
        print root[0][0].tag
        print root[0][0].text
        print root[0][1].tag
        print root[0][1].text

        for child in root:
            print child[0].text
