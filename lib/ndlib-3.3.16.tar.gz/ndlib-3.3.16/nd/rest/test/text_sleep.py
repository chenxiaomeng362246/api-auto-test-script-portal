# coding=utf-8
from Tkinter import Button
import time
from cof.co_gui.co_app import CoApp
from cof.co_gui.co_text import CoText
from cof.logger.log_func import Logger
from cof.semaphore import Semaphore
from cof.thread import Thread

# logger = Logger("测试01")

import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(filename)s[%(lineno)d] %(levelname)s %(message)s')
logger = logging.getLogger(__name__)
logger.info(__name__)

__author__ = 'linzh'


class TextSleep(object):
    def __init__(self):
        self.text = None
        self.var = 2

    def run(self):
        sema = Semaphore(1)

        def sleep_func(text_in):
            time.sleep(2)
            print "sleep"
            # text的操作，会阻塞该线程，所以不能用join
            # text_in.append("row 1")
            # text_in.println("row 2")

            self.var = 3
            sema.signal()

        logger.info("wait")
        logger.info(sema.value())
        sema.wait()
        logger.info(sema.value())
        t1 = Thread(sleep_func, self.text)
        logger.info(t1)

        def sleep_func2(text):
            logger.info("sleep func2")
            logger.info(sema.value())
            sema.wait()
            text.println(str(self.var))

            text.println("after thread")

            text.println("run")
            sema.signal()

        # 这里不能使用wait()，否则会发生死锁
        t2 = Thread(sleep_func2, self.text)
        logger.info(t2)
        t2.join()

        def sleep_func3(text):
            logger.info("sleep func3")
            logger.info(sema.value())
            sema.wait()
            text.println(str(self.var))

            text.println("after thread")

            text.println("run")
            sema.signal()

        t3 = Thread(sleep_func3, self.text)
        t3.join()

    def main(self):
        root = CoApp().get_root()
        self.text = CoText(root)
        btn = Button(root, text="run", command=self.run)
        btn.pack()

        # text.append("row 1")
        # text.println("row 1")
        # sema = Semaphore()

        root.mainloop()


if __name__ == '__main__':
    o = TextSleep()
    o.main()
