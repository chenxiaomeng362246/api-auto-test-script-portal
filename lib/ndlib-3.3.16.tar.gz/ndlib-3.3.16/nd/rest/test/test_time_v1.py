# coding=utf-8
from cof.co_test.nd_case import NdCase

__author__ = 'linzh'


class TimeTestV1(NdCase):
    def setUp(self):
        pass

    def get_time_str(self):
        pass
