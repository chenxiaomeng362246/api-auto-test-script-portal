# coding=utf-8
from nd.rest.co_time.co_time import CoTime
from cof.log import LogInfo
from cof.co_test.nd_case import NdCase
from cof.logger.scribe_handler import ScribeHandler

__author__ = 'linzh'

import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(filename)s[%(lineno)d] %(levelname)s %(message)s')
logger = logging.getLogger(__name__)
logger.info(__name__)


class ScribeHandlerTest(NdCase):
    def setUp(self):
        self.handler = ScribeHandler()

    def test_info(self):
        """
        case: test info

        :return:
        """
        log_o = LogInfo()

        self.handler.setFormatter(log_o.get_format())

        logger.addHandler(self.handler)

        logger.info("Scribe日志测试: " + CoTime().iso8601())

