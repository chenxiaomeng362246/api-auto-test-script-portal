# coding=utf-8
from ..co_test.nd_case import NdCase
from ..proc import get_proc_count, get_proc_ids, get_proc_list, kill_procs, CoProc

__author__ = 'linzh'

import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(filename)s[%(lineno)d] %(levelname)s %(message)s')
logger = logging.getLogger(__name__)
logger.info(__name__)


class ProcTest(NdCase):
    def test_count(self):
        """
        测试进程数统计

        :return:
        """
        proc_cnt = get_proc_count('appium')
        logger.info(proc_cnt)

    def test_get_ids(self):
        """
        获取进程id

        :return:
        """
        proc_ids = get_proc_ids('appium')
        logger.info(proc_ids)

    def test_get_proc(self):
        """
        获取进程

        :return:
        """
        proc_list = get_proc_list('appium')
        logger.info(proc_list)

    def test_kill(self):
        kill_procs('appium.js')
        proc_list = get_proc_list('appium')
        logger.info(proc_list)

    def test_run_appium(self):
        proc_o = CoProc()
        proc_o.run('start_appium %s' % 4723)
        proc_list = get_proc_list('appium.js')
        proc_ids = get_proc_ids('appium.js')
        logger.info(proc_ids)
        logger.info(proc_list)

