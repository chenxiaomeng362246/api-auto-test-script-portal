# coding=utf-8
from bson.objectid import ObjectId
from ..co_mongo.db_info import DbInfo
from ..co_test.nd_case import NdCase
from ..logger.log_func import Logger
from ..mongo import MongodbConn
from ..rand import CoRand

from hamcrest import *

__author__ = 'linzh'

logger = Logger("Mongodb服务测试")


class MongoTestV1(NdCase):
    def setUp(self):
        host = DbInfo.MongoDev['host']
        port = DbInfo.MongoDev['port']

        self.mongo_conn = MongodbConn(host, port)
        self.mongo_conn.set_coll("test_db", "test_doc")

    def test_conn(self):
        """
        测试创建连接

        :return:
        """
        host = DbInfo.MongoDev['host']
        port = DbInfo.MongoDev['port']

        mongo_conn = MongodbConn(host, port)

        assert_that(mongo_conn, is_(MongodbConn))

    def test_set_coll(self):
        """

        :return:
        """
        self.mongo_conn.set_coll("test_db", "test_doc")

        data = {
            "doc_id": CoRand.uuid_str(),
            "content": "test-" + CoRand.randomword(100)
        }

        self.mongo_conn.add(data)

    def test_find_doc_by_content(self):
        """

        :return:
        """
        query = {
            "title": "mytitle"
        }

        data = {
            "title": "mytitle"
        }

        self.mongo_conn.add(data)

        res = self.mongo_conn.find_one(query)

        logger.info(res)

    def test_find_doc_part(self):
        """
        模糊搜索，失败

        :return:
        """
        query = {
            "title": "mytitle-search"
        }

        data = {
            "title": "mytitle-search-01"
        }

        self.mongo_conn.add(data)

        res = self.mongo_conn.find_one(query)

        logger.info(res)

        assert_that(res, is_(None))

    def test_find_by_id(self):
        """
        插入一条记录，应该返回数据库记录id - ObjectId

        :return:
        """
        data = {
            "title": CoRand.randomword(10)
        }

        res = self.mongo_conn.add(data)

        logger.info(res)

        id_len = len("57198cab763d057098493d4c")

        assert_that(len(str(res)), equal_to(id_len))

    def test_obj_id(self):
        """

        :return:
        """

        try:
            oid = ObjectId("test")
            logger.info(oid)
        except Exception, e:
            logger.info(Exception)
            logger.info(e)



