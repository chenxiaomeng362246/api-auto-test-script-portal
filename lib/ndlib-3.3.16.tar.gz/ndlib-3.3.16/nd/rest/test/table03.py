# coding=utf-8
import sys

reload(sys)

sys.setdefaultencoding('utf-8')

from tabulate import tabulate

__author__ = 'linzh'

data = [
    (u'状态', u'说明'),
    ('80', u'考试已结束，用户已交卷'),
    ('96', u'考试已结束，用户已完成考试，成绩已出')
]

print tabulate(data, tablefmt="rst")
