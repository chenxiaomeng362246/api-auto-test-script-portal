# coding=utf-8
from cof.co_test.nd_case import NdCase

__author__ = 'linzh'


class StrTest(NdCase):
    def setUp(self):
        pass

    def test_latin(self):
        """

        :return:
        """
        str_cn = "\xe8\xaf\xbe\xe7\xa8\x8b\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8"
        print str_cn
