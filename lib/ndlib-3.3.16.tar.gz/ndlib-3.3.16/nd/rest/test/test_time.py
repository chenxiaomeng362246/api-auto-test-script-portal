
from cof.co_time import co_time as CoTime

__author__ = 'linzh'


CoTime.info()

