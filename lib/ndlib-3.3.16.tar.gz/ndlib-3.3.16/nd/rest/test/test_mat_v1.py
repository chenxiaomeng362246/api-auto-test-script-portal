# coding=utf-8
from ..co_matrix.np import CoMatrix
from ..co_test.nd_case import NdCase

__author__ = 'linzh'


class MatTestV1(NdCase):
    def setUp(self):
        pass

    def test_get_det(self):
        """

        :return:
        """
        mat = CoMatrix([[1, 2], [3, 4]])
        print mat.det()

    def tearDown(self):
        pass
