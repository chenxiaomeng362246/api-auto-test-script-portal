# coding=utf-8
from thrift.protocol import TBinaryProtocol
from nd.rest.co_time.co_time import CoTime

__author__ = 'Administrator'

import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(filename)s[%(lineno)d] %(levelname)s %(message)s')
logger = logging.getLogger(__name__)
logger.info(__name__)

# import scribe

from thrift.transport import TTransport, TSocket

from scribe import scribe

# scribe.Client
host = "192.168.248.150"
port = 1463

socket = TSocket.TSocket(host=host, port=port)

transport = TTransport.TFramedTransport(socket)
transport.open()

protocol = TBinaryProtocol.TBinaryProtocol(trans=transport, strictRead=False, strictWrite=True)

client = scribe.Client(protocol)

log_category = "test02"

for i in range(0, 10):
    time_o = CoTime()
    log_message = "测试: " + time_o.iso8601()
    log_entry = scribe.LogEntry(log_category, log_message)
    result = client.Log(messages=[log_entry])
    logger.info(log_message)
    logger.info(result)

transport.close()

