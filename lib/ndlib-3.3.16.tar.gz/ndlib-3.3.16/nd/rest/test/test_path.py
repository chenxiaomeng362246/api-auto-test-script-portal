# coding=utf-8

__author__ = 'linzh'

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.info(__name__)


from cof.nd_path import NdPath


nd_path_o = NdPath()

logger.info(nd_path_o.get_jlib_path())
