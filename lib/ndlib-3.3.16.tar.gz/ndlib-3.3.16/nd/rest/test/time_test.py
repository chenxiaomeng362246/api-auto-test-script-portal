# coding=utf-8
from cof.co_test.nd_case import NdCase
from cof.co_time.co_time import CoTime

__author__ = 'linzh'

import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(filename)s[%(lineno)d] %(levelname)s %(message)s')
logger = logging.getLogger(__name__)
logger.info(__name__)


class TimeTest(NdCase):
    def setUp(self):
        self.time_o = CoTime()

    def test_get_expired_time(self):
        ts = self.time_o.get_ts()
        logger.info(ts)

    def test_get_iso8601(self):
        """

        :return:
        """
        res = self.time_o.iso8601()
        logger.info(res)

