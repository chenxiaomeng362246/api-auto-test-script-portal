# coding=utf-8
from cof.co_test.nd_case import NdCase

__author__ = 'linzh'


class XmlTest(NdCase):
    def setUp(self):
        pass

    def test_post_xml(self):
        pass
