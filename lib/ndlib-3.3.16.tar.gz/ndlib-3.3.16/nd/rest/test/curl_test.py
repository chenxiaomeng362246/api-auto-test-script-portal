from cof.co_test.nd_case import NdCase
import pycurl

__author__ = 'linzh'


class CurlTest(NdCase):
    def main03(self):
        """
        http://cs.101.com/v0.1/static/release_package_repository/com.nd.app.factory.appupdates/updates/809997/updates.ipa

        表单文件上传，模拟http表单
        """
        # upload binary file with pycurl by http post
        c = pycurl.Curl()
        c.setopt(c.POST, 1)
        c.setopt(c.URL, "http://192.168.240.63:5000/db_bind/test")
        c.setopt(c.HTTPPOST, [("file", (c.FORM_FILE, "/home/linzh/soapui-settings.xml"))])
        c.setopt(c.VERBOSE, 1)
        c.perform()
        c.close()


    def main05():
        """
        body文件上传

        :return:
        """
        import os

        class FileReader:
            def __init__(self, fp):
                self.fp = fp

            def read_callback(self, size):
                return self.fp.read(size)

        # Initialize pycurl
        c = pycurl.Curl()
        c.setopt(pycurl.PROXY, "http://127.0.0.1:8888")
        c.setopt(pycurl.URL, "http://192.168.240.63:5000/db_bind/test")
        c.setopt(pycurl.UPLOAD, 1)
        c.setopt(pycurl.CUSTOMREQUEST, "POST")

        filename = "/home/linzh/soapui-settings.xml"

        # Two versions with the same semantics here, but the filereader version
        # is useful when you have to process the data which is read before returning
        if 1:
            c.setopt(pycurl.READFUNCTION, FileReader(open(filename, 'rb')).read_callback)
        else:
            c.setopt(pycurl.READFUNCTION, open(filename, 'rb').read)

        # Set size of file to be uploaded.
        filesize = os.path.getsize(filename)
        c.setopt(pycurl.INFILESIZE, filesize)

        # Start transfer
        c.perform()
        c.close()


    def main01():
        print "start..."
        url = "http://api.account.service.debug.sdp.nd/v0.6/organizations/1/orgnodes"
        o = Http()
        print o.ver()
        # 打印body
        print o.get(url)


    def main02():
        http_o = Http("192.168.19.97", 7777)
        res = http_o.status("/")
        return res


    def main06():
        """

        :return:
        """
        filename = "/home/linzh/soapui-settings.xml"

        c = pycurl.Curl()
        c.setopt(pycurl.PROXY, "http://127.0.0.1:8888")
        c.setopt(c.URL, "http://192.168.240.63:5000/db_bind/test")
        c.setopt(c.HTTPPOST, [
            ("fieldname1", "value1"),
            ("fieldname2", "value2"),
            ("uploadfieldname", (c.FORM_FILE, filename, c.FORM_CONTENTTYPE, "application/json"))
        ])

        # Start transfer
        c.perform()
        c.close()
