# coding=utf-8
from cof.co_test.nd_case import NdCase
from cof.jsession import Jsession

__author__ = 'linzh'

from hamcrest import *

import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(filename)s[%(lineno)d] %(levelname)s %(message)s')
logger = logging.getLogger(__name__)
logger.info(__name__)


class SingletonTest(NdCase):
    def setUp(self):
        pass

    def test_jsess(self):
        """
        case: 测试单实例

        :return:
        """
        one = Jsession()
        two = Jsession()

        # 3
        two.a = 3
        assert_that(one.a, equal_to(3))

        # one和two完全相同,可以用id(), ==, is检测
        # print id(one)
        logger.info(id(one))

        # print id(two)
        logger.info(id(two))

