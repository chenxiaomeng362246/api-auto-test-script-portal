# coding=utf-8
from ..co_test.api_nd_case import ApiNdCase

__author__ = 'linzh'


class HttpReqTest(ApiNdCase):
    def setUp(self):
        pass

    def test_http_agent(self):
        pass

    def test_http_proxy(self):
        pass

    def tearDown(self):
        pass
