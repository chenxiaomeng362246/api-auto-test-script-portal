# coding=utf-8
from cof.co_sys.cmd import CoCmd
from cof.co_test.nd_case import NdCase

from hamcrest import *
from cof.logger.log_func import Logger

__author__ = 'linzh'

logger = Logger("基础测试框架-" + __name__)


class SysTest(NdCase):
    def setUp(self):
        self.cmd = CoCmd()

    def test_get_find(self):
        """

        :return:
        """
        cmd_str = self.cmd.get_find_cmd()

        logger.info(cmd_str)

        assert_that(cmd_str, is_(str))
