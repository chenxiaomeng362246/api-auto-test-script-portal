# coding=utf-8
__author__ = 'Administrator'

"""
restful规范接口的返回值处理方法
"""

import sys

sys.path.insert(0, '..')

import json
import re
import cgi
from hamcrest import *  # 断言库


class Restful(object):
    def __init__(self):
        """

        """
        pass

    def parse_response(self, response, code, message="请求失败", is_json=True):
        """
        解析请求接口返回的数据。

        若与期望相符，则返回data_dec；否则直接就断言失败，跳出case。

        response: 返回的数据;
        code：[整型]该次请求所期望返回的code;
        message：错误时需要的指明的信息
        is_json：是否期望data为json格式，默认为True；若为True，则解析data为字典时若报错就抛出异常，否则不抛出异常

        :return：data_dec，转换为json格式之后的data字段
        """
        error_info = ""

        if len(re.findall(r'<[^>]+>', response['request'])):
            response['request'] = cgi.escape(response['request'], quote='"')
        request_info = "<p>接口请求： " \
                       + str(response['request']) + ", "
        if 'request_header' in response:
            request_info += "<br>request_headers=" + str(response['request_header']) + ",</p>"
        else:
            request_info += "</p>"

        # 请求、响应信息拼装&打印
        if 'data' not in response:
            error_info = message + "，\n状态码：" + str(response['code']) + "，\n错误信息：返回数据没有data内容" \
                         + "，\n请求为：" + str(response['request'])
            assert_that(response, has_key('data'), error_info)

        data = response['data']
        transferred_data = data
        response_info = "<p>实际返回数据：" \
                        "<br/>code: " + str(response['code'])
        try:
            json.loads(transferred_data)
            if len(re.findall(r'<[^>]+>', data)):
                transferred_data = cgi.escape(data, quote='"')
            response_info += "<br/>body: " + str(transferred_data)
        except Exception as e:
            # todo 如果不是json，很可能是文件，转义特殊字符后打印，否则编码问题会导致无法生成报告
            try:
                data.decode('utf-8')
                response_info += "<br/>body: " + cgi.escape(data, quote='"')
            except Exception as e:
                response_info += "<br/>body: 数据带有特殊编码，解析异常"

        if 'response_header' in response:
            response_info += "<br/>response_headers=" + str(response['response_header']) + "</p>"
        else:
            response_info += "</p>"
        print request_info
        print response_info

        data_dec = dict()
        if response['code'] != code:  # 1、状态码错误
            # 错误信息 + 状态码
            if len(data) == 0:  # 1.1、data没有内容
                # error_info += request_info + response_info
                error_info = message + "，\n状态码：" + str(response['code']) + "，\n错误信息：数据为空" \
                             + "，\n请求为：" + str(response['request'])
                assert_that(response['code'], equal_to(code), error_info)
            else:  # 1.2、data有内容，无论是不是报错，都应该是json：
                # 1.2.1 data是报错（期望的code是2xx）
                # 1.2.2 data不是报错（期望的code是代表错误的状态码）
                try:
                    data_dec = json.loads(data)
                except Exception as e:
                    # error_info += request_info + response_info
                    error_info = message + "，\n状态码：" + str(response['code']) + "，\n错误信息：数据不是json格式" \
                                 + "，\n请求为：" + str(
                        response['request'])
                    assert_that(response['code'], equal_to(code), error_info)

                # 如果返回的data里面没有message字段，直接输出data
                detail_info = ""
                exception_info = ""
                # todo 暂时屏蔽
                # if "detail" in data_dec.keys() and data_dec['detail']:
                #     detail_info = "\n" + data_dec['detail'][:data_dec['detail'].rindex('\n\t', 0, 1000)].encode('utf-8')
                if "message" in data_dec:
                    if data_dec['message']:
                        exception_info = data_dec['message'].encode('utf-8')
                        if response['code'] == 0 and exception_info == 'timed out':
                            exception_info = '接口长时间未响应-已按照设置的超时时间断开连接'
                        # error_info += "错误信息：" + exception_info + "\n详细信息：" + detail_info + request_info + response_info
                        # error_info += "<p>错误信息：" + exception_info + "<br/>详细信息：" + detail_info + "</p>"
                        error_info = message + "，\n状态码：" + str(response['code']) + "，\n错误信息：" + exception_info \
                                     + "，\n请求为：" + str(response['request'])
                    else:
                        error_info = message + "，\n状态码：" + str(response['code']) + "，\n错误信息：空，\n请求为：" \
                                     + str(response['request'])
                else:
                    error_info = message + "，\n状态码：" + str(response['code']) + "，\n错误信息：返回数据没有错误信息-" + transferred_data \
                                 + "，\n请求为：" + str(response['request'])
                assert_that(response['code'], equal_to(code), error_info)
        else:  # 2、状态码正确
            if len(data) == 0:  # 2.1、判断data有没有内容，如果没有，就返回一个空的字典
                print '<hr/>'
                return data_dec
            else:
                try:  # 2.2、data不为空，尝试转换为字典
                    # data_dec = json.loads(data, encoding='gb2312')
                    data_dec = json.loads(data)
                except Exception as e:
                    if is_json:  # 2.2.1、data不为json，抛出异常
                        error_info = message + "，\n状态码：" + str(response['code']) + "，\n错误信息：数据不是json格式" \
                                     + "，\n请求为：" + str(response['request'])
                        assert_that(data, instance_of(dict), error_info)
                    else:  # 2.2.2、data不为json，但不抛出异常，保留原始的data
                        data_dec = data
                print '<hr/>'
                return data_dec

    def parse_response_isNotJson(self, response, code, message="请求失败",is_json=True):
        """
        解析请求接口返回的数据。
        若与期望相符，则返回data_dec；否则直接就断言失败，跳出case。
        response: 返回的数据;
        code：[整型]该次请求所期望返回的code;
        message：错误时需要的指明的信息
        ret：data_dec，转换为json格式之后的data字段
        """


        data = response['data']
        data_dec = dict()
        if response['code'] != code:    # 状态码错误
            print "<p>\n实际返回的数据为：\n</p>" ,str(response['data'])
            if len(data) == 0:            # 判断data有没有内容
                error = message + "，\n状态码：" + str(response['code']) + "，\n请求为：" + str(response['request'])
                assert_that(response['code'], equal_to(code), error)
            else:                       # 判断状态码
                try:
                    data_dec = json.loads(data)
                except Exception as e:
                    error = "<p>" +message + "，\n状态码：" + str(response['code']) + "，数据不是json格式的，\n请求为：" + str(response['request']) + "</p>"
                    assert_that(response['code'], equal_to(code), error)
                # 如果返回的data里面没有message字段，直接输出data
                if 'message' in data_dec:
                    error = ""
                    if data_dec['message']:
                        error = message + "，\n状态码：" + str(response['code']) + "，\n错误信息：" + data_dec['message'].encode('utf-8') + "，\n请求为：" + str(response['request'])
                    else:
                        error = message + "，\n状态码：" + str(response['code']) + "，\n错误信息为空，\n请求为：" + str(response['request'])
                    assert_that(response['code'], equal_to(code), error)
                else:
                    error = message + ",\n返回的数据是： " + data + "，\n请求为：" + str(response['request'])
                    assert_that(response['code'], equal_to(code), error)
        else:
            # 状态码正确
            print  "<p>接口请求：" ,str(response['request']),"</p>"
            print "<p>\n实际返回数据：<br/>code: " , response['code'], "<br/>body: " , str(response['data']),"<br/></p><hr/>"
            if len(data) == 0:          # 判断data有没有内容
                #data_dec = CodingTransform().dict_by_utf(data_dec)
                return data_dec
            else:
                try:
                    data_dec = json.loads(data)
                    #data_dec = CodingTransform().dict_by_utf(data_dec)
                except Exception as e:
                    error = message + "，\n状态码：" + str(response['code']) + "，数据不是json格式的，\n请求为：" + str(response['request'])
                    #assert_that(error, equal_to(""), error)
                return data_dec

    def parse_error_info(self, data_dec, error_code, error_message="", detail='', cause=''):
        """
        使用于restful逆向用例；
        当状态码符合期望时，再进一步判断返回值是否为指定的格式，如下：
        {
            "code":"UC/ORG_NOT_EXIST",               // 表示错误信息
            "message":"{error message}",             // 错误信息的文字说明
            "request_id":"1234567",                  // 请求id
            "host_id":"{server identity}",           // 主机id
            "server_time":"2014-01-01T12:00:00Z"     // 服务器时间
        }
        """
        # code
        assert_that(data_dec, has_key('code'))
        assert_that(
            str(data_dec['code']).encode('utf-8'), equal_to(error_code), "实际返回的错误码与预期的错误码不符合")
        # message
        assert_that(data_dec, has_key('message'))
        if error_message != "":
            assert_that(data_dec['message'].encode('utf-8'), contains_string(error_message), "实际返回的错误信息与预期的错误信息不符合")
        # request_id
        if "request_id" not in data_dec:
            print "there's no request_id in data: " + str(data_dec)
        # host_id
        assert_that(data_dec, has_key('host_id'))
        # server_time
        assert_that(data_dec, has_key('server_time'))
        # cause
        # assert_that(data_dec, has_key('cause'))
        if 'cause' in data_dec.keys() and cause != '':
            assert_that(data_dec['cause'], equal_to(cause))
        # detail
        # assert_that(data_dec, has_key('detail'))
        if 'detail' in data_dec.keys() and detail != '':
            assert_that(data_dec['detail'], contains_string(detail))

    def request_timeout(self, error, timeout, request):
        """
        针对接口请求超时断言
        error: 接口超时返回的错误信息;
        timeout：超时时间;
        request：请求接口信息
        :return:
        """
        messages = "接口响应时长超过" + str(timeout) + "s，\n状态码：504" + "，\n错误信息：接口长时间未响应" + "，\n请求为：" + str(
            request)
        assert_that(error, is_not('timed out'), messages)


def main():
    o = Restful()
    res = {'code': 200,
           'request': 'GET http://elearning-service.pre1.web.nd:80/v1/projects/1732/mix_organizations',
           'read_time': 313L,
           'response_header': {
               'access-control-allow-headers': 'Origin, Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers, Authorization, Cache-control, Orgname, vorg, X-Gaea-Authorization, sdp-app-id, Accept-Language',
               'x-application-context': 'elearning-service:testhuayu', 'access-control-max-age': '1800',
               'transfer-encoding': 'chunked', 'server': 'nginx/1.12.1', 'connection': 'keep-alive',
               'date': 'Wed, 20 Dec 2017 06:06:51 GMT', 'p3p': 'CP=INT NAV UNI',
               'access-control-allow-methods': 'GET, POST, HEAD, OPTIONS, PUT, DELETE, TRACE, PATCH',
               'content-type': 'application/sdp+json;charset=UTF-8', 'access-control-allow-origin': '*'},
           'data': 'html',
           'response_time': 0L,
           'request_header': {'Accept-Language': 'zh-CN,zh;q=0.8', 'Content-Type': 'application/json',
                              'Accept': 'application/sdp+json',
                              'Authorization': 'MAC id="EE8CCF03966C572F16E0E5079A3F0FA5DCC46917FB6AAA62C7FFA9731A564F3C77BA41DAD1B0DCFF",nonce="1513750009000:Bm9PiiUJ",mac="AswixuTVsxX2aC/KpRw0oB4r77VKCOQXnAXNlcmJ0aE="',
                              'User-Agent': 'ApiAutotest'}}
    code = 200
    msg = "hello"
    r = o.parse_response(res, code, msg)
    print r
