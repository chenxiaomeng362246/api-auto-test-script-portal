# coding=utf-8

__author__ = 'linzh'


class Bayes(object):
    def __init__(self):
        pass
