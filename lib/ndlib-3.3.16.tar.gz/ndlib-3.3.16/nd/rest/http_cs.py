# coding=utf-8
"""
httplib的一层封装，更易于使用

.. doctest:: 

    >>> http_obj = cofHttp.Http(url, 80)
    >>> http_obj.set_header(header)
    >>> http_obj.post("/syslog", self.data)
"""
import poster
import os

__author__ = 'Administrator'

import json
import time
import datetime
import urllib2
import httplib
import json

from test_manager import TestManager
from poster.encode import multipart_encode
from poster.streaminghttp import register_openers
import random
import socket

IMPORTLIB = False

"""
import logging
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                    datefmt='%a, %d %b %Y %H:%M:%S',
                    filename='api.log',
                    filemode='a'
                    )

console = logging.StreamHandler()
formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
console.setFormatter(formatter)
logging.getLogger('').addHandler(console)
"""

"""
if IMPORTLIB:
    import lib.url as LibUrlM
    import lib.log as LLog

    logger = LLog.Logger()
else:
    #import co_http.co_statis as LibUrlM
    import logger.ILogger as LogM
    logger = LogM.ILogger()
"""

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.info(__name__)

def get_current_time():
    """
    获取当前时间
    """
    current_time = int(time.time()) * 1000 + datetime.datetime.now().microsecond/1000
    return current_time

def send_url_using(url):
    """
    向测试管理平台发送当前接口测试请求的url(不包括协议，host和port)
    """
    host = 'plot.qa.sdp.nd'
    testing_platform_url = '/api/v1.0/api-url'
    method = 'POST'
    headers = dict()
    body = {
        'url': str(url)
    }
    body = json.dumps(body)

    flag = False

    conn = None

    try:
        conn = httplib.HTTPConnection(host)
        conn.request(method, testing_platform_url, body, headers)
        response = conn.getresponse()
        if response.status == 200:
            flag = True
    except Exception, e:  # 连接错误 or 读取错误
        logger.info("记录接口运行")
        print 'error : ', str(e)

    if conn is not None:
        conn.close()

def send_host_port_using(host, port):
    """
    向测试管理平台发送当前接口测试请求的host和port，如果已经请求过了，就不会再发送
    :param host:
    :param port:
    :return:
    """
    if not host_port_is_used(host, port):
        host_platform_host = 'plot.qa.sdp.nd'
        testing_platform_url = '/api/v1.0/api-statis'
        method = 'POST'
        headers = dict()
        if port is not None:
            body = {
                'host': str(host),
                'port': long(port)
            }
        else:
            body = {
                'host': str(host),
                'port': 80
            }
        body = json.dumps(body)

        for index in range(3):  # 三次重试
            flag = False
            conn = None
            try:
                conn = httplib.HTTPConnection(host_platform_host)
                conn.request(method, testing_platform_url, body, headers)
                response = conn.getresponse()
                if response.status == 200:
                    flag = True
                # else:
                #     print '给测试管理平台发送"' + str(host) + ':' + str(port) + '"失败'
            except Exception, e:  # 连接错误 or 读取错误
                logger.info("记录接口服务")
                print 'error : ', str(e)
            if conn is not None:
                conn.close()
            if flag:
                break

def host_port_is_used(host, port):
    """
    查询测试管理平台，指定的主机和端口是否已被请求过
    :param host:
    :param port:
    :return:
    """
    is_used = False     # 返回host:port是否已被请求过
    host_platform_host = 'plot.qa.sdp.nd'
    testing_platform_url = '/api/v1.0/api-statis?host=' + str(host)
    method = 'GET'
    headers = dict()
    body = None

    for index in range(3):  # 三次重试
        flag = False
        conn = None
        try:
            conn = httplib.HTTPConnection(host_platform_host)
            conn.request(method, testing_platform_url, body, headers)
            response = conn.getresponse()
            if response.status == 200:
                data = response.read()  # 响应的返回值
                data = json.loads(data)
                for item in data:
                    if item['host'] == host and item['port'] == port:
                        is_used = True
                        break
            flag = True
        except Exception, e:  # 连接错误 or 读取错误
            logger.info("记录接口测试")
            print 'error : ', str(e)
        if conn is not None:
            conn.close()
        if flag:
            break

    return is_used

class Http(object):
    """对GET/POST进行了封装，让代码更简短易读
    :class:`cof.http.Http` 先初始化

    * `METHOD`: 默认请求方法
    """

    METHOD = "GET"

    def __init__(self, host, port='', url='', ssl=False, timeout=60):
        """
        使用httplib库进行操作
        """
        # 解析host来判断是否使用https

        self.host = host
        self.port = str(port)
        if self.port == "":
            self.port = None
        # self.url = url
        self.header = dict()
        self.header["Content-Type"] = "application/json"

        # 请求body
        self.params = None
        self.timeout = timeout
        if ssl is True or ssl == 1 or ssl == '1':
            self.url = "https://" + str(host) + ':' + str(port)
            self.conn = httplib.HTTPSConnection(self.host, self.port, timeout=self.timeout)
        else:
            if port == 80 or port is None or port == "":
                self.url = "http://" + str(host)
            else:
                self.url = "http://" + str(host) + ':' + str(port)

            self.conn = httplib.HTTPConnection(self.host, self.port, timeout=self.timeout)
        # self.conn.set_tunnel(self.host, int(self.port))

        self.test_manager = TestManager(2)

    def parse_url(self):
        pass

    def set_header(self, header):
        """
        设置http请求头，可以设置AccessToken
        """
        self.header = header

    def send_request(self, res, method, url, headers, body=None):
        """
        封装发送请求的过程
        """
        conn = self.conn
        http_url = self.url + str(url)
        logger.info("发送请求 - send_request")
        logger.info(http_url)

        flag = False

        begin_time = 0
        end_time = 0

        retry_count = 0  # 重试次数
        for i in xrange(2):
            try:
                headers['Qa-tag'] = '0'
                begin_time = get_current_time()
                conn.request(method=method, url=url, headers=headers, body=body)
                response = conn.getresponse()
                end_time = get_current_time()

                # 状态码
                res["code"] = response.status

                # 响应的返回值
                res["data"] = response.read()

                # 响应的头信息
                res["response_header"] = response.msg.dict

                cookie = response.getheader("set-cookie")

                if cookie is not None:
                    start = cookie.find("JSESSIONID=")
                    end = cookie.find(";", start+11)
                    jsession = str(cookie[start+11:end])
                    res['jsession'] = jsession

                flag = True
                break
                #self.test_manager.send_host_port(self.host, self.port)
                #self.test_manager.send_url(url, self.url)

            except socket.error, e:  # 连接错误 or 读取错误  只捕获socket超时异常、10060、11004
                # if end_time == 0:
                logger.error(e)
                if (e.errno == 10060 or e.errno == 11004) and retry_count == 0:  # 如果为10060防火墙异常\11004域名解析异常重试一次
                    conn.close()
                    retry_count += 1
                    print ("<p><span style=\"color:blue\">socket %s错误，重试一次<span></p><hr/>" % str(e.errno))
                    continue
                elif e.message == 'timed out':
                    end_time = get_current_time()
                    res["code"] = 0
                    res["data"] = '{"message": "%s"}' % (e)
                    res["response_header"] = {}
                    break
                else:
                    conn.close()
                    raise

        # 读完数据的时间
        read_time = get_current_time()

        # http响应的间隔时间，单位ms
        res["response_time"] = end_time - begin_time

        # 读数据使用的间隔时间，单位ms
        res["read_time"] = read_time - end_time

        res["request_header"] = headers

        self.print_response_time(res)

        logger.info(url)

        logger.info("===============================")
        if 'data' in res:
            logger.info(res["data"])

        conn.close()
        return flag

    def get(self, url,host=None):
        res = dict()
        i_test=0
        if self.port is None:
            res["request"] = "GET " + str(self.host) + str(url)
        else:
            res["request"] = "GET " + str(self.host) + ":" + str(self.port) + str(url)
        for index in range(3):  # 三次重试
            if host is None:
                if self.send_request(res, 'GET', url, self.header) is True:
                    break
                else:
                    i_test +=1
            else:
                header=dict()
                header["Host"]=host
                header["Content-Type"] = "application/json"
                if self.send_request(res,'GET',url,header) is True:
                    break
                else:
                    i_test +=1



        if i_test>0:
            print '重试次数：',i_test

        return res

    def post(self, url, params=None):
        """

        :param url:
        :param params(string):
        :return:
        """
        conn = self.conn

        http_url = self.url + url

        # logger.info("post url")
        # logger.info(http_url)

        if isinstance(params, dict):
            params = json.dumps(params)

        """
        begin_time = get_current_time()
        conn.request(method="POST", url=url, headers=self.header, body=params)
        end_time = get_current_time()
        response = conn.getresponse()
        """

        res = dict()

        if self.port is None:
            res["request"] = "POST " + str(self.host) + str(url)
        else:
            res["request"] = "POST " + str(self.host) + ":" + str(self.port) + str(url)

        if params is not None:
            res["request"] += ",\nbody=" + params

        i_test =0
        for index in range(3):  # 三次重试
            if self.send_request(res, 'POST', url, self.header, body=params) is True:
                break
            else:
                i_test +=1
        if i_test>0:
            print '重试次数：',i_test

        return res

    def delete(self, url, params=None):
        res = dict()
        i_test=0
        if self.port is None:
            res["request"] = "DELETE " + str(self.host) + str(url)
        else:
            res["request"] = "DELETE " + str(self.host) + ":" + str(self.port) + str(url)
        if params is not None:
            res["request"] += ",\nbody=" + params
        for index in range(3):  # 三次重试
            if self.send_request(res, 'DELETE', url, self.header, body=params) is True:
                break
            else:
                i_test +=1
        if i_test>0:
            print '重试次数：',i_test

        return res

    def patch(self, url, params=None):
        res = dict()
        i_test=0
        if self.port is None:
            res["request"] = "PATCH " + str(self.host) + str(url)
        else:
            res["request"] = "PATCH " + str(self.host) + ":" + str(self.port) + str(url)
        if params is not None:
            res["request"] += ",\nbody=" + params
        for index in range(3):  # 三次重试
            if self.send_request(res, 'PATCH', url, self.header, body=params) is True:
                break
            else:
                i_test +=1

        if i_test>0:
            print '重试次数：',i_test

        return res

    def head(self, url):
        res = dict()
        i_test=0
        if self.port is None:
            res["request"] = "HEAD " + str(self.host) + str(url)
        else:
            res["request"] = "HEAD " + str(self.host) + ":" + str(self.port) + str(url)
        for index in range(3):  # 三次重试
            if self.send_request(res, 'HEAD', url, self.header) is True:
                break
            else:
                i_test +=1

        if i_test>0:
            print '重试次数：',i_test

        return res

    def put(self, url, params=None):
        res = dict()
        i_test=0
        if self.port is None:
            res["request"] = "PUT " + str(self.host) + str(url)
        else:
            res["request"] = "PUT " + str(self.host) + ":" + str(self.port) + str(url)
        if params is not None:
            res["request"] += ",\nbody=" + params
        for index in range(3):  # 三次重试
            if self.send_request(res, 'PUT', url, self.header, body=params) is True:
                break
            else:
                i_test +=1
        if i_test>0:
            print '重试次数：',i_test

        return res

    def upload_files(self, url_in, file_path, params):
        """
        文件上传的方法

        参数：

        :param url:         请求url

        :param file_path:   文件路径，包含文件名

        :param params:     上传文件需要带有的参数，字典格式

        """
        if self.port is None:
            url = "http://" + str(self.host) + str(url_in)
        else:
            url = "http://" + str(self.host) + ":" + str(self.port) + str(url_in)
        file_o = open(file_path, "rb")
        params["fileUpload"] = file_o

        register_openers()

        datagen, headers = multipart_encode(
            params
        )
        print datagen
        print headers
        print params

        # 创建请求对象
        request_handle = urllib2.Request(url, datagen, headers)

        res = dict()

        res['request'] = "POST " + str(url)

        # logging.info(res['request'])
        begin_time = get_current_time()

        try:
            # 实际执行请求并取得返回
            response_handle = urllib2.urlopen(request_handle)
            res['code'] = response_handle.code
            res['data'] = response_handle.read()
            read_time = get_current_time()
            self.test_manager.send_host_port(self.host, self.port)
            self.test_manager.send_url(url_in)
            response_handle.close()
        except urllib2.HTTPError as e:
            res['code'] = e.code
            res['data'] = e.read()
            read_time = get_current_time()

        end_time = get_current_time()

        res["response_time"] = end_time - begin_time
        res["read_time"] = read_time - end_time  # 读数据使用的间隔时间，单位ms

        self.print_response_time(res)

        file_o.close()

        return res

    def upload_files_bucket(self, url_in, file_path, params):
        """
        文件上传的方法, 验证bucket功能（header，覆盖自定义传入的header）

        参数：

        :param url:         请求url

        :param file_path:   文件路径，包含文件名

        :param params:     上传文件需要带有的参数，字典格式

        """
        if self.port is None:
            url = "http://" + str(self.host) + str(url_in)
        else:
            url = "http://" + str(self.host) + ":" + str(self.port) + str(url_in)
        file_o = open(file_path, "rb")
        params["fileUpload"] = file_o

        register_openers()

        datagen, headers = multipart_encode(
            params
        )
        #覆盖自定义传入的header
        headers=dict(headers.items()+self.header.items())

        print datagen
        print headers
        print params

        # 创建请求对象
        request_handle = urllib2.Request(url, datagen, headers)

        res = dict()

        res['request'] = "POST " + str(url)

        # logging.info(res['request'])
        begin_time = get_current_time()

        try:
            # 实际执行请求并取得返回
            response_handle = urllib2.urlopen(request_handle)
            res['code'] = response_handle.code
            res['data'] = response_handle.read()
            read_time = get_current_time()
            self.test_manager.send_host_port(self.host, self.port)
            self.test_manager.send_url(url_in)
            response_handle.close()
        except urllib2.HTTPError as e:
            res['code'] = e.code
            res['data'] = e.read()
            read_time = get_current_time()

        end_time = get_current_time()

        res["response_time"] = end_time - begin_time
        res["read_time"] = read_time - end_time  # 读数据使用的间隔时间，单位ms

        self.print_response_time(res)

        file_o.close()

        return res

    def upload_files_chunk(self, url_in,file_path, temp_path,params):
        """
        文件分块上传（文件流）的方法 每块的大小按1m大小来切分
        参数：

        :param url:         请求url

        :param file_path:   文件路径，包含文件名

        :param params:     上传文件需要带有的参数，字典格式

        """
        if self.port is None:
            url = "http://" + str(self.host) + str(url_in)
        else:
            url = "http://" + str(self.host) + ":" + str(self.port) + str(url_in)

        # if not os.path.exists(temp_path):
        #     os.mkdir(temp_path)

        #设定分块大小
        chunk_size = 1000*1000
        pos = 0
        chunk = 0
        file_length = os.path.getsize(file_path)
        chunks = file_length / chunk_size
        if file_length % chunk_size != 0:
            chunks += 1
        #文件分块
        file_o = open(file_path, "rb")
        res = dict()
        while chunk < chunks:
            ostream = open(temp_path,"wb")
            file_o.seek(0,1)
            chunk_content = file_o.read(chunk_size)
            #print chunk_content
            ostream.write(chunk_content)
            ostream.flush()
            ostream.close()
            print("length:")
            print(os.path.getsize(temp_path))

            params["fileUpload"] = open(temp_path, "rb")
            #添加分块所需的参数
            if chunk == chunks - 1:
                chunk_size = file_length % chunk_size
            params["chunk_size"] = chunk_size
            params["pos"] = pos
            params["chunks"] = chunks
            params["chunk"] = chunk
            params["size"] = file_length
            pos += chunk_size
            chunk += 1
            register_openers()
            datagen, headers = multipart_encode(
                params
            )
            print datagen
            print headers
            print params
            request_handle = urllib2.Request(url, datagen, headers)


            res['request'] = "POST " + str(url)

            # logging.info(res['request'])
            begin_time = get_current_time()

            try:
                # 实际执行请求并取得返回
                response_handle = urllib2.urlopen(request_handle)
                res['code'] = response_handle.code
                res['data'] = response_handle.read()
                read_time = get_current_time()
                self.test_manager.send_host_port(self.host, self.port)
                self.test_manager.send_url(url_in)
                response_handle.close()
            except urllib2.HTTPError as e:
                res['code'] = e.code
                res['data'] = e.read()
                read_time = get_current_time()

            end_time = get_current_time()

            res["response_time"] = end_time - begin_time
            res["read_time"] = read_time - end_time  # 读数据使用的间隔时间，单位ms
            self.print_response_time(res)
            params["fileUpload"].close()
        file_o.close()

        #删除创建的临时文件
        os.remove(temp_path)

        return res

    def upload_files_chunk_ip(self, url_in,file_path, temp_path,params):
        """
        文件分块上传（文件流）的方法 每块的大小按1m大小来切分(指定ip发送请求)
        参数：

        :param url:         请求url

        :param file_path:   文件路径，包含文件名

        :param params:     上传文件需要带有的参数，字典格式

        """
        if self.port is None:
            url = "http://" + str(self.host) + str(url_in)
        else:
            url = "http://" + str(self.host) + ":" + str(self.port) + str(url_in)

        # if not os.path.exists(temp_path):
        #     os.mkdir(temp_path)
        httpproxy_handler = urllib2.ProxyHandler({"http": "64.64.108.141"})
        nullproxy_handler = urllib2.ProxyHandler({})
        proxySwitch = True  # 定义一个代理开关

        #设定分块大小
        chunk_size = 1000*1000
        pos = 0
        chunk = 0
        file_length = os.path.getsize(file_path)
        chunks = file_length / chunk_size
        if file_length % chunk_size != 0:
            chunks += 1
        #文件分块
        file_o = open(file_path, "rb")
        res = dict()
        while chunk < chunks:
            ostream = open(temp_path,"wb")
            file_o.seek(0,1)
            chunk_content = file_o.read(chunk_size)
            #print chunk_content
            ostream.write(chunk_content)
            ostream.flush()
            ostream.close()
            print("length:")
            print(os.path.getsize(temp_path))

            params["fileUpload"] = open(temp_path, "rb")
            #添加分块所需的参数
            if chunk == chunks - 1:
                chunk_size = file_length % chunk_size
            params["chunk_size"] = chunk_size
            params["pos"] = pos
            params["chunks"] = chunks
            params["chunk"] = chunk
            params["size"] = file_length
            pos += chunk_size
            chunk += 1
            register_openers()
            datagen, headers = multipart_encode(
                params
            )
            print datagen
            print headers
            print params
            if proxySwitch:
                opener = urllib2.build_opener(httpproxy_handler)
            else:
                opener = urllib2.build_opener(nullproxy_handler)

            request_handle = urllib2.Request(url,datagen, headers)


            res['request'] = "POST " + str(url)

            # logging.info(res['request'])
            begin_time = get_current_time()

            try:
                # 实际执行请求并取得返回
                response_handle = urllib2.urlopen_by_ip(url,'64.64.108.65')
                res['code'] = response_handle.code
                res['data'] = response_handle.read()
                read_time = get_current_time()
                self.test_manager.send_host_port(self.host, self.port)
                self.test_manager.send_url(url_in)
                response_handle.close()
            except urllib2.HTTPError as e:
                res['code'] = e.code
                res['data'] = e.read()
                read_time = get_current_time()

            end_time = get_current_time()

            res["response_time"] = end_time - begin_time
            res["read_time"] = read_time - end_time  # 读数据使用的间隔时间，单位ms
            self.print_response_time(res)
            params["fileUpload"].close()
        file_o.close()

        #删除创建的临时文件
        os.remove(temp_path)

        return res

    def upload_files_chunk_host_is_range(self, url_in,file_path, temp_path,params):
        """
        文件分块上传（文件流）的方法 每块的大小按1m大小来切分
        混合host请求，如分3块进行上传，前2块用cs.101.com域名进行请求，后一块用uploadcs.101.com域名进行请求
        参数：

        :param url:         请求url

        :param file_path:   文件路径，包含文件名

        :param params:     上传文件需要带有的参数，字典格式

        """


        # if not os.path.exists(temp_path):
        #     os.mkdir(temp_path)

        #设定分块大小
        chunk_size = 1000*1000
        pos = 0
        chunk = 0
        file_length = os.path.getsize(file_path)
        chunks = file_length / chunk_size
        if file_length % chunk_size != 0:
            chunks += 1
        #文件分块
        file_o = open(file_path, "rb")
        res = dict()
        while chunk < chunks:
            ostream = open(temp_path,"wb")
            file_o.seek(0,1)
            chunk_content = file_o.read(chunk_size)
            #print chunk_content
            ostream.write(chunk_content)
            ostream.flush()
            ostream.close()
            print("length:")
            print(os.path.getsize(temp_path))

            params["fileUpload"] = open(temp_path, "rb")
            #添加分块所需的参数
            if chunk == chunks - 1:
                chunk_size = file_length % chunk_size
            params["chunk_size"] = chunk_size
            params["pos"] = pos
            params["chunks"] = chunks
            params["chunk"] = chunk
            params["size"] = file_length
            pos += chunk_size
            chunk += 1
            register_openers()
            datagen, headers = multipart_encode(
                params
            )
            print datagen
            print headers
            print params

            new_host_list=[self.host,'uploadcs.101.com']
            new_host=random.sample(new_host_list,1)
            if self.port is None:
                url = "https://" + str(new_host[0]) + str(url_in)
            else:
                url = "https://" + str(new_host[0]) + ":" + str(self.port) + str(url_in)
            print 'test_url_is:',url

            request_handle = urllib2.Request(url, datagen, headers)


            res['request'] = "POST " + str(url)

            # logging.info(res['request'])
            begin_time = get_current_time()

            try:
                # 实际执行请求并取得返回
                response_handle = urllib2.urlopen(request_handle)
                res['code'] = response_handle.code
                res['data'] = response_handle.read()
                read_time = get_current_time()
                self.test_manager.send_host_port(self.host, self.port)
                self.test_manager.send_url(url_in)
                response_handle.close()
            except urllib2.HTTPError as e:
                res['code'] = e.code
                res['data'] = e.read()
                read_time = get_current_time()

            end_time = get_current_time()

            res["response_time"] = end_time - begin_time
            res["read_time"] = read_time - end_time  # 读数据使用的间隔时间，单位ms
            self.print_response_time(res)
            params["fileUpload"].close()
        file_o.close()

        #删除创建的临时文件
        os.remove(temp_path)

        return res

    def upload_files_chunk_notequal(self, url_in,file_path, temp_path,params):
        """
        文件分块上传（文件流）的方法 每块的大小为不等分 （待实现）
        参数：

        :param url:         请求url

        :param file_path:   文件路径，包含文件名

        :param params:     上传文件需要带有的参数，字典格式

        """
        if self.port is None:
            url = "http://" + str(self.host) + str(url_in)
        else:
            url = "http://" + str(self.host) + ":" + str(self.port) + str(url_in)

        # if not os.path.exists(temp_path):
        #     os.mkdir(temp_path)

        #设定分块大小
        chunk_size = 1000*1000
        pos = 0
        chunk = 0
        file_length = os.path.getsize(file_path)
        chunks = file_length / chunk_size
        if file_length % chunk_size != 0:
            chunks += 1

        #文件分块
        file_o = open(file_path, "rb")
        res = dict()
        while chunk < chunks:
            ostream = open(temp_path,"wb")
            file_o.seek(0,1)
            chunk_content = file_o.read(chunk_size)
            #print chunk_content
            ostream.write(chunk_content)
            ostream.flush()
            ostream.close()
            print("length:")
            print(os.path.getsize(temp_path))

            params["fileUpload"] = open(temp_path, "rb")
            #添加分块所需的参数
            if chunk == chunks - 1:
                chunk_size = file_length % chunk_size
            params["chunk_size"] = chunk_size
            params["pos"] = pos
            params["chunks"] = chunks
            params["chunk"] = chunk
            params["size"] = file_length
            pos += chunk_size
            chunk += 1
            register_openers()
            datagen, headers = multipart_encode(
                params
            )
            print datagen
            print headers
            print params
            request_handle = urllib2.Request(url, datagen, headers)


            res['request'] = "POST " + str(url)

            # logging.info(res['request'])
            begin_time = get_current_time()

            try:
                # 实际执行请求并取得返回
                response_handle = urllib2.urlopen(request_handle)
                res['code'] = response_handle.code
                res['data'] = response_handle.read()
                read_time = get_current_time()
                self.test_manager.send_host_port(self.host, self.port)
                self.test_manager.send_url(url_in)
                response_handle.close()
            except urllib2.HTTPError as e:
                res['code'] = e.code
                res['data'] = e.read()
                read_time = get_current_time()

            end_time = get_current_time()

            res["response_time"] = end_time - begin_time
            res["read_time"] = read_time - end_time  # 读数据使用的间隔时间，单位ms
            self.print_response_time(res)
            params["fileUpload"].close()
        file_o.close()

        #删除创建的临时文件
        os.remove(temp_path)

        return res

    def upload_files_chunk_by_bucket(self, url_in,file_path, temp_path,params):
        """
        文件分块上传（文件流）的方法 每块的大小按1m大小来切分
        参数：

        :param url:         请求url

        :param file_path:   文件路径，包含文件名

        :param params:     上传文件需要带有的参数，字典格式

        """
        if self.port is None:
            url = "http://" + str(self.host) + str(url_in)
        else:
            url = "http://" + str(self.host) + ":" + str(self.port) + str(url_in)

        # if not os.path.exists(temp_path):
        #     os.mkdir(temp_path)

        #设定分块大小
        chunk_size = 1000*1000
        pos = 0
        chunk = 0
        file_length = os.path.getsize(file_path)
        chunks = file_length / chunk_size
        if file_length % chunk_size != 0:
            chunks += 1
        #文件分块
        file_o = open(file_path, "rb")
        res = dict()
        while chunk < chunks:
            ostream = open(temp_path,"wb")
            file_o.seek(0,1)
            chunk_content = file_o.read(chunk_size)
            #print chunk_content
            ostream.write(chunk_content)
            ostream.flush()
            ostream.close()
            print("length:")
            print(os.path.getsize(temp_path))

            params["fileUpload"] = open(temp_path, "rb")
            #添加分块所需的参数
            if chunk == chunks - 1:
                chunk_size = file_length % chunk_size
            params["chunk_size"] = chunk_size
            params["pos"] = pos
            params["chunks"] = chunks
            params["chunk"] = chunk
            params["size"] = file_length
            pos += chunk_size
            chunk += 1
            register_openers()
            datagen, headers = multipart_encode(
                params
            )
            #覆盖传入的header
            headers=dict(headers.items()+self.header.items())

            print datagen
            print headers
            print params
            request_handle = urllib2.Request(url, datagen, headers)


            res['request'] = "POST " + str(url)

            # logging.info(res['request'])
            begin_time = get_current_time()

            try:
                # 实际执行请求并取得返回
                response_handle = urllib2.urlopen(request_handle)
                res['code'] = response_handle.code
                res['data'] = response_handle.read()
                read_time = get_current_time()
                self.test_manager.send_host_port(self.host, self.port)
                self.test_manager.send_url(url_in)
                response_handle.close()
            except urllib2.HTTPError as e:
                res['code'] = e.code
                res['data'] = e.read()
                read_time = get_current_time()

            end_time = get_current_time()

            res["response_time"] = end_time - begin_time
            res["read_time"] = read_time - end_time  # 读数据使用的间隔时间，单位ms
            self.print_response_time(res)
            params["fileUpload"].close()
        file_o.close()

        #删除创建的临时文件
        os.remove(temp_path)

        return res

    def upload_files_chunk_and_chunks_is_6m(self, url_in,file_path, temp_path,params):
        """
        文件分块上传（文件流）的方法  每块的大小按6m大小来切分
        参数：

        :param url:         请求url

        :param file_path:   文件路径，包含文件名

        :param params:     上传文件需要带有的参数，字典格式

        """
        if self.port is None:
            url = "http://" + str(self.host) + str(url_in)
        else:
            url = "http://" + str(self.host) + ":" + str(self.port) + str(url_in)

        # if not os.path.exists(temp_path):
        #     os.mkdir(temp_path)

        #设定分块大小
        chunk_size = 1000*6000
        pos = 0
        chunk = 0
        file_length = os.path.getsize(file_path)
        chunks = file_length / chunk_size
        if file_length % chunk_size != 0:
            chunks += 1
        #文件分块
        file_o = open(file_path, "rb")
        res = dict()
        while chunk < chunks:
            ostream = open(temp_path,"wb")
            file_o.seek(0,1)
            chunk_content = file_o.read(chunk_size)
            #print chunk_content
            ostream.write(chunk_content)
            ostream.flush()
            ostream.close()
            print("length:")
            print(os.path.getsize(temp_path))

            params["fileUpload"] = open(temp_path, "rb")
            #添加分块所需的参数
            if chunk == chunks - 1:
                chunk_size = file_length % chunk_size
            params["chunk_size"] = chunk_size
            params["pos"] = pos
            params["chunks"] = chunks
            params["chunk"] = chunk
            params["size"] = file_length
            pos += chunk_size
            chunk += 1
            register_openers()
            datagen, headers = multipart_encode(
                params
            )
            print datagen
            print headers
            print params
            request_handle = urllib2.Request(url, datagen, headers)


            res['request'] = "POST " + str(url)

            # logging.info(res['request'])
            begin_time = get_current_time()

            try:
                # 实际执行请求并取得返回
                response_handle = urllib2.urlopen(request_handle)
                res['code'] = response_handle.code
                res['data'] = response_handle.read()
                read_time = get_current_time()
                self.test_manager.send_host_port(self.host, self.port)
                self.test_manager.send_url(url_in)
                response_handle.close()
            except urllib2.HTTPError as e:
                res['code'] = e.code
                res['data'] = e.read()
                read_time = get_current_time()

            end_time = get_current_time()

            res["response_time"] = end_time - begin_time
            res["read_time"] = read_time - end_time  # 读数据使用的间隔时间，单位ms
            self.print_response_time(res)
            params["fileUpload"].close()
        file_o.close()

        #删除创建的临时文件
        os.remove(temp_path)

        return res

    def upload_files_chunk_and_chunks_is_3M(self, url_in,file_path, temp_path,params):
        """
        文件分块上传（文件流）的方法 每块的大小按100k来切分
        参数：

        :param url:         请求url

        :param file_path:   文件路径，包含文件名

        :param params:     上传文件需要带有的参数，字典格式

        """
        if self.port is None:
            url = "http://" + str(self.host) + str(url_in)
        else:
            url = "http://" + str(self.host) + ":" + str(self.port) + str(url_in)

        # if not os.path.exists(temp_path):
        #     os.mkdir(temp_path)

        #设定分块大小
        chunk_size = 1000*3000
        pos = 0
        chunk = 0
        file_length = os.path.getsize(file_path)
        chunks = file_length / chunk_size
        if file_length % chunk_size != 0:
            chunks += 1
        #文件分块
        file_o = open(file_path, "rb")
        res = dict()
        while chunk < chunks:
            ostream = open(temp_path,"wb")
            file_o.seek(0,1)
            chunk_content = file_o.read(chunk_size)
            #print chunk_content
            ostream.write(chunk_content)
            ostream.flush()
            ostream.close()
            print("length:")
            print(os.path.getsize(temp_path))

            params["fileUpload"] = open(temp_path, "rb")
            #添加分块所需的参数
            if chunk == chunks - 1:
                chunk_size = file_length % chunk_size
            params["chunk_size"] = chunk_size
            params["pos"] = pos
            params["chunks"] = chunks
            params["chunk"] = chunk
            params["size"] = file_length
            pos += chunk_size
            chunk += 1
            register_openers()
            datagen, headers = multipart_encode(
                params
            )
            print datagen
            print headers
            print params
            request_handle = urllib2.Request(url, datagen, headers)


            res['request'] = "POST " + str(url)

            # logging.info(res['request'])
            begin_time = get_current_time()

            try:
                # 实际执行请求并取得返回
                response_handle = urllib2.urlopen(request_handle)
                res['code'] = response_handle.code
                res['data'] = response_handle.read()
                read_time = get_current_time()
                self.test_manager.send_host_port(self.host, self.port)
                self.test_manager.send_url(url_in)
                response_handle.close()
            except urllib2.HTTPError as e:
                res['code'] = e.code
                res['data'] = e.read()
                read_time = get_current_time()

            end_time = get_current_time()

            res["response_time"] = end_time - begin_time
            res["read_time"] = read_time - end_time  # 读数据使用的间隔时间，单位ms
            self.print_response_time(res)
            params["fileUpload"].close()
        file_o.close()

        #删除创建的临时文件
        os.remove(temp_path)

        return res

    def upload_files_chunk_size_error(self, url_in,file_path, temp_path,params):
        """
        文件分块上传（文件流）的方法
        分块上传时传入错误的快的size 进行验证#1443的问题
        参数：

        :param url:         请求url

        :param file_path:   文件路径，包含文件名

        :param params:     上传文件需要带有的参数，字典格式

        """
        if self.port is None:
            url = "http://" + str(self.host) + str(url_in)
        else:
            url = "http://" + str(self.host) + ":" + str(self.port) + str(url_in)

        # if not os.path.exists(temp_path):
        #     os.mkdir(temp_path)

        #设定分块大小
        chunk_size = 1000*1000
        pos = 0
        chunk = 0
        file_length = os.path.getsize(file_path)+60000
        chunks = file_length / chunk_size
        if file_length % chunk_size != 0:
            chunks += 1
        #文件分块
        file_o = open(file_path, "rb")
        res = dict()

        while chunk < chunks :
            ostream = open(temp_path,"wb")
            file_o.seek(0,1)
            chunk_content = file_o.read(chunk_size)
            #print chunk_content
            ostream.write(chunk_content)
            ostream.flush()
            ostream.close()
            print"length:",os.path.getsize(temp_path)

            params["fileUpload"] = open(temp_path, "rb")
            #添加分块所需的参数
            if chunk == chunks - 1:
                chunk_size = file_length % chunk_size

            params["chunk_size"] = chunk_size
            params["pos"] = pos
            params["chunks"] = chunks
            params["chunk"] = chunk
            params["size"] = file_length
            pos += chunk_size
            chunk += 1
            register_openers()
            datagen, headers = multipart_encode(
                params
            )
            print datagen
            print headers
            print params
            request_handle = urllib2.Request(url, datagen, headers)


            res['request'] = "POST " + str(url)

            # logging.info(res['request'])
            begin_time = get_current_time()

            try:
                # 实际执行请求并取得返回
                response_handle = urllib2.urlopen(request_handle)
                res['code'] = response_handle.code
                res['data'] = response_handle.read()
                read_time = get_current_time()
                self.test_manager.send_host_port(self.host, self.port)
                self.test_manager.send_url(url_in)
                response_handle.close()
            except urllib2.HTTPError as e:
                res['code'] = e.code
                res['data'] = e.read()
                read_time = get_current_time()

            end_time = get_current_time()

            res["response_time"] = end_time - begin_time
            res["read_time"] = read_time - end_time  # 读数据使用的间隔时间，单位ms
            self.print_response_time(res)
            params["fileUpload"].close()
        file_o.close()

        #删除创建的临时文件
        os.remove(temp_path)

        return res

    def upload_files_chunk_status(self, url_in,file_path, temp_path,params):
        """
        获取分块上传状态（文件流）的方法
        参数：

        :param url:         请求url

        :param file_path:   文件路径，包含文件名

        :param params:     上传文件需要带有的参数，字典格式

        """
        if self.port is None:
            url = "http://" + str(self.host) + str(url_in)
        else:
            url = "http://" + str(self.host) + ":" + str(self.port) + str(url_in)

        # if not os.path.exists(temp_path):
        #     os.mkdir(temp_path)

        #设定分块大小
        chunk_size = 1000*1000
        pos = 0
        chunk = 0
        file_length = os.path.getsize(file_path)
        chunks = file_length / chunk_size
        if file_length % chunk_size != 0:
            chunks += 1
        #文件分块
        file_o = open(file_path, "rb")
        res = dict()
        while chunk < chunks-1: #不传完整块
            ostream = open(temp_path,"wb")
            file_o.seek(0,1)
            chunk_content = file_o.read(chunk_size)
            #print chunk_content
            ostream.write(chunk_content)
            ostream.flush()
            ostream.close()
            print "length:",os.path.getsize(temp_path)
            #print(os.path.getsize(temp_path))

            params["fileUpload"] = open(temp_path, "rb")
            #添加分块所需的参数
            if chunk == chunks - 1:
                chunk_size = file_length % chunk_size
            params["chunk_size"] = chunk_size
            params["pos"] = pos
            params["chunks"] = chunks
            params["chunk"] = chunk
            params["size"] = file_length
            pos += chunk_size
            chunk += 1
            register_openers()
            datagen, headers = multipart_encode(
                params
            )
            print datagen
            print headers
            print params
            request_handle = urllib2.Request(url, datagen, headers)


            res['request'] = "POST " + str(url)

            # logging.info(res['request'])
            begin_time = get_current_time()

            try:
                # 实际执行请求并取得返回
                response_handle = urllib2.urlopen(request_handle)
                res['code'] = response_handle.code
                res['data'] = response_handle.read()
                read_time = get_current_time()
                self.test_manager.send_host_port(self.host, self.port)
                self.test_manager.send_url(url_in)
                response_handle.close()
            except urllib2.HTTPError as e:
                res['code'] = e.code
                res['data'] = e.read()
                read_time = get_current_time()

            end_time = get_current_time()

            res["response_time"] = end_time - begin_time
            res["read_time"] = read_time - end_time  # 读数据使用的间隔时间，单位ms
            self.print_response_time(res)
            params["fileUpload"].close()
        file_o.close()

        #删除创建的临时文件
        os.remove(temp_path)

        return res

    def print_response_time(self, res):
        """
        打印某个接口的响应时间

        :param res: 响应

        .. code-block:: js

            {
                'request':
                'response_time':
                'read_time'
            }

        函数签名：

            res -> void

        .. code-block:: python
            :linenos:


        """
        print "*** 接口 '%s'\n响应时间：%sms\n读取时间：%sms ***" % (
            res['request'], str(res['response_time']), str(res['read_time'])
        )


if __name__ == '__main__':
    http_o = Http("aqapi.101.com", 80, ssl=True)
    res = http_o.post("/v0.93/bearer_tokens", "")
    logger.info(res)
