# coding=utf-8

import logging
from ..log import LogInfo
from ..conf.conf import MyCfg

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(filename)s[%(lineno)d] %(levelname)s %(message)s')
logger_o = logging.getLogger(__name__)


class Logger(object):
    """
    日志记录类

    使用config/{env}/cfg.ini进行配置

    .. code-block:: shell

        [log]
        type = file
        type = scribe
        type = socket


    .. code-block:: python

        >>> logger = Logger()
        >>> logger.info("打印日志")

    """
    def __init__(self, log_tag=None, root_path=None, log_file="error.log"):
        self.cfg_path = None
        logger = logging.getLogger(log_tag)
        logger.propagate = False

        if log_tag is None:
            log_tag = __name__

        if root_path is not None:
            try:
                cfg_o = MyCfg('cfg.ini')
                cfg_o.set_path(root_path)
                cfg_o.set_section('log')
                self.cfg_path = cfg_o.cfg_path
                log_type = cfg_o.get('type')
                logger_o.info(log_type)

            except Exception, e:
                logger_o.error(e)
                log_type = 'scribe'
                logger_o.info(log_type)
                logger_o.error("您需要在以下配置文件设置log配置段，默认使用scribe进行记录")
                logger_o.error(self.cfg_path)

            if not hasattr(self, 'scribe_handler'):
                logger_o.info("设置log handler")
                log_info = LogInfo()

            # 取消发送日志到日志服务器  -- 2018-10-15  laibaoyu
            # # 还没有设置日志句柄
            # if log_type == 'file':
            #     self.scribe_handler = logging.FileHandler(filename=log_file)
            #     logger.addHandler(self.scribe_handler)
            # elif log_type == 'hyqa':
            #     from ..logger.hyqa_logger import ScribeHandler
            #
            #     # 初始化一个日志处理器
            #     # 连接到日志服务器
            #     self.scribe_handler = ScribeHandler()
            #
            #     self.scribe_handler.setLevel(MyCfg.LOGLEVEL)
            #
            #     self.scribe_handler.set_appid(9997)
            #
            #     self.scribe_handler.set_filepath('/LogTest/Test01/error.log')
            #
            #     logger.addHandler(self.scribe_handler)
            # else:
            #     try:
            #         from ..logger.scribe_handler import ScribeHandler
            #
            #         self.scribe_handler = ScribeHandler(log_tag)
            #
            #         self.scribe_handler.setFormatter(log_info.get_format())
            #
            #         logger.addHandler(self.scribe_handler)
            #     except Exception, e:
            #         logger_o.info(e)

        self.logger = logger

    def info(self, msg):
        self.logger.info(msg)

    def debug(self, msg):
        self.logger.debug(msg)

    def debug_path(self, path):
        self.scribe_handler.set_filepath(path)
        self.logger.info("debug: 伪接口")

    def get_logger(self):
        return self.logger


if __name__ == "__main__":
    log = Logger()
    log.debug("/LogTest/Test02/error.log")
    log.debug("/LogTest/Test03/error.log")
