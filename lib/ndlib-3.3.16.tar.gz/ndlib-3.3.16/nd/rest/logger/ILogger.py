__author__ = 'Administrator'


class ILogger(object):
    def __init__(self):
        pass

    def info(self, msg):
        pass

    def debug(self, msg):
        pass

    def error(self, msg):
        pass
