# coding=utf-8

"""

"""
__author__ = 'Administrator'


from ..logger.ILogger import ILogger


class SimpleLogger(ILogger):
    def __init__(self):
        pass