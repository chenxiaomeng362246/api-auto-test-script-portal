__author__ = 'Administrator'


def test():
    print "file cache"
