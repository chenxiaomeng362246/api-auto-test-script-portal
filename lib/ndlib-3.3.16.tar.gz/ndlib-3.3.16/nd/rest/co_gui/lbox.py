# coding=utf-8

import sys
sys.path.insert(0, '../../../Pmw_2_0_0')

import Pmw

__author__ = 'linzh'

class Lbox(object):
    def __init__(self, master, title="选项"):
        self.list = Pmw.ScrolledListBox(master,
                                        label_text=title, labelpos='nw',
                                        # listbox_height = 6,
                                        # usehullsize = 1,
                                        # hull_width = 200,
                                        # hull_height = 200,
                                    )
        self.items = list()
        self.items.append("所有")
        self.list.setlist(self.items)
        self.list.pack()

    def set_items(self, items):
        self.items = items
        self.list.setlist(self.items)

