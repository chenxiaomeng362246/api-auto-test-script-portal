# coding=utf-8

from Tkinter import PhotoImage

from PIL import Image, ImageTk

__author__ = 'linzh'


class CoImage(object):
    def __init__(self, name=""):
        self.image = name

    def get_image(self):
        return PhotoImage(file=self.image)

    def create_image(self):
        pass
