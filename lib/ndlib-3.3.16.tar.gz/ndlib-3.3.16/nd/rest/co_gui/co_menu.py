# coding=utf-8
import Pmw
from ..co_gui.co_app import CoApp

__author__ = 'linzh'


class CoMenu(object):
    def __init__(self, parent):
        # self.menu = Pmw.MainMenuBar(parent, balloon=None)

        self.menu_info = dict()

        self.menu_info['菜单'] = '子菜单'

        self.menu = Pmw.MenuBar(parent,
                hull_relief='raised',
                hull_borderwidth=1,
                balloon=None)

        for idx, key in enumerate(self.menu_info):
            self.menu.addmenu(key, "菜单说明")
            self.menu.addmenuitem(key, 'command', "", label=self.menu_info[key])

        self.menu.pack()


if __name__ == '__main__':

    app = CoApp()

    root = app.get_root()

    menu = CoMenu(root)

    root.mainloop()
