# coding=utf-8

__author__ = 'linzh'


class CoTriangle(object):
    """
    画三角形

    """
    def __init__(self, canvas):
        self.canvas = canvas
        self.gid = 0

    def make_triangle(self, x, y, r=8):
        self.gid = self.canvas.create_polygon(x - r, y - r, x + r, y, x - r, y + r, fill="green")

if __name__ == '__main__':
    from Tkconstants import BOTH, YES
    from Tkinter import Canvas
    from ..co_gui.co_app import CoApp

    app = CoApp()
    root = app.get_root()
    canvas = Canvas(root, width=300, height=300, bd=2)
    canvas.pack(fill=BOTH, expand=YES)

    tri = CoTriangle(canvas)
    tri.make_triangle(50, 50, 10)

    root.mainloop()
