# coding=utf-8
from Tkinter import LabelFrame

__author__ = 'linzh'


class CoFieldSet(object):
    def __init__(self, master):
        self.frame = LabelFrame(master)
