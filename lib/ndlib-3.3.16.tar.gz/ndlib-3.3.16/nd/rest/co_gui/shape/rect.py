# coding=utf-8

__author__ = 'linzh'


class CoRect(object):
    def __init__(self, canvas):
        self.cv = canvas
        self.x = 0
        self.y = 0
        self.w = 0
        self.h = 0
        self.x2 = 0
        self.y2 = 0

    def make(self, x, y, w, h):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.x2 = x + w
        self.y2 = y + h
        self.cv.create_rectangle(x, y, x + w, y + h)

    def draw_text(self, txt="文本"):
        """

        :return:
        """
        x = self.x + self.w/2
        y = self.y + self.h/2
        self.cv.create_text(x, y, text=txt)

    def draw_line(self, rect):
        """
        在两个矩形之间画连线

        :param rect1:
        :param rect2:
        :return:
        """
        x1 = self.x2
        y1 = self.y + self.h/2

        x2 = rect.x + rect.w/2
        y2 = y1

        self.cv.create_line(x1, y1, x2, y2)

        x3 = x2

        y3 = rect.y

        self.cv.create_line(x2, y2, x2, y2)
        self.cv.create_line(x2, y2, x3, y3)
