# coding=utf-8

import time
import random
import hashlib
import hmac
import base64
from pyDes import *
from ..proc import CoProc
from ..http import *
from ..nd_uc import *
from ..restful import *
from ..nd_path import NdPath
import re

nd_path_o = NdPath()


def get_md5_pw(password):
        """
        根据uc的算法，对密码加密
        """
        p = os.path.abspath(__file__)
        p = os.path.dirname(p)
        md5_jar = p + os.sep + 'md5.jar'

        cmd = 'java -jar ' + md5_jar + ' %s' % password

        res = CoProc().run(cmd)
        return res['result'][:-2]


def get_beijing_time(utc_time):
    """
    根据iso时间获取北京时间
    utc_time 评价的创建时间，utc格式，'2015-12-28T03:05:56.000+0000'
    """
    real_time = utc_time[:-9]
    time_array = time.strptime(real_time, "%Y-%m-%dT%H:%M:%S")
    time_stamp = int(time.mktime(time_array))

    beijing_time_stamp = time_stamp + 60 * 60 * 8
    # beijing_time_stamp = time_stamp
    beijing_time = time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(beijing_time_stamp))

    return beijing_time

def des_encrypt(string, des_key):
    """
    UC1.0 DES对称加密算法
    :param string:明文
    :param des_key:秘钥
    :return 密文
    """
    k = des(key=str(des_key), mode=ECB, padmode=PAD_PKCS5)
    EncryptStr = k.encrypt(str(string))

    return base64.b64encode(EncryptStr)  # 转base64编码返回

def des_decrypt(string, des_key):
    """
    UC1.0 DES对称解密算法
    :param string:明文
    :param des_key:秘钥
    :return 密文
    """
    string = base64.b64decode(str(string))
    k = des(key=str(des_key), mode=ECB, padmode=PAD_PKCS5)
    EncryptStr = k.decrypt(string)

    return EncryptStr

class UcToken(NdUc):
    """
    通过uc获取token
    """
    def __init__(self, env, uc_version='0.93', uc_header=None):
        """
        :param env: 指定配置文件中的环境名称
        """
        self.env = env
        self.uc_header = uc_header
        super(UcToken, self).__init__(self.env, uc_version, self.uc_header)

        # 声明一些参数
        self.rest_o = Restful()

        # uc账号相关数据
        self.user_id = ''
        self.access_token = ''
        self.mac_key = ''
        self.session_key = ''

        self.http_obj = Http(host=self.host, port=self.port, ssl=self.is_ssl)
        self.http_obj.set_header(self.header)

        # 登录流程改造
        self.flag = True
        self.time_span = 0
        self.user = ''
        self.password = ''
        self.org = ''
        self.account = ''  # 账户默认为空

    def get_ms_format(self):
        """
        获取服务器时间的时间戳
        """
        self.http_obj.set_header(self.header)
        response = self.http_obj.get("/v0.93/server/time")

        data_dict = self.rest_o.parse_response(response, 200, '获取系统时间失败')
        # assert_that(data_dict, has_key('server_time'))
        ms_format = str(data_dict['ms_format'])

        return ms_format

    def get_server_time(self):
        """
        获取服务器时间
        """
        self.http_obj.set_header(self.header)
        response = self.http_obj.get("/v0.93/server/time")

        data_dict = self.rest_o.parse_response(response, 200, '获取系统时间失败')
        # assert_that(data_dict, has_key('server_time'))
        time = data_dict['server_time']

        return time

    def get_encoded_device_id(self, device_id, device):
        """
        :name 获取des加密后的device_id

        :param
        #.  device_id 原设备id
        #.  device  设备位  android取a，IOS取i，web取w
        """
        # 校验位 base64（md5（原设备id）），并取第3位
        check_char = base64.b64encode(NdUc.get_password_md5(device_id))[2]
        id = check_char + device + device_id
        return id

    def get_login_session(self):
        """
        创建UC登录会话，20分钟过期
        """
        code_sequence = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
        device_id = ''
        for i in xrange(32):
            device_id += random.choice(code_sequence)

        body = {
            "session_type":1,
            "device_id": self.get_encoded_device_id(device_id , 'a')
        }
        # 1.0版本 session 需要SDP-MIGRATED请求头
        # v1.0版本认证服务提供对v0.93版本认证服务的适配功能.通过在请求中添加SDP-MIGRATED(大写)请求头来开启此适配功能.
        # 当SDP-MIGRATED(大写)请求头的值为true时表示当前请求的是v1.0版本服务,
        # 当不带有此请求头或其值为false时，表示请求的是v0.93版本服务;
        self.http_obj.set_header(self.header)
        response = self.http_obj.post("/v"+str(self.uc_version)+"/session",body)
        data_dict = self.rest_o.parse_response(response, 201, '创建会话失败')

        self.session_key = data_dict['session_key']

        logger.info("会话信息")
        logger.info(data_dict)

        return data_dict

    def get_adjust_server_time(self):
        """
        根据iso时间获取北京时间
        utc_time 评价的创建时间，utc格式，'2015-12-28T03:05:56.000+0000'
        """
        # 获取服务器时间 不管是哪个环境的，都以uc登录的服务器时间戳为准（特殊）
        self.http_obj.set_header(self.header)
        # 获取当前时间
        locate_time = int(time.time()*1000)
        # 获取服务器时间
        response = self.http_obj.get("/v"+str(self.uc_version)+"/server/time")
        data_dict = self.rest_o.parse_response(response, 200, '获取系统时间失败')
        ms_format = data_dict['ms_format']

        # 计算本地时间与服务器时间的间隔
        time_span =  ms_format - locate_time

        return time_span


    # -------------- 生成mac token ----------------- #
    def get_mac_content(self, url, method, host):
        """
        :name 获取Authorization - os方法
        :param
        #.  id token
        #.  time 2014-12-24T12:23:12Z 时间
        #.  host 访问的域名（非默认端口号时，需要加上端口号）
        #.  method  获取方法
        注：一般没生成authorization，是因为没有事先登录，获取token
        """
        token_id = self.access_token

        server_time = self.get_server_time()
        print ("time1:" + str(server_time))
        server_time = server_time.encode('UTF-8')   # 2017-06-06T10:09:02.048+0000
        if self.env in [UcEnv.aws, UcEnv.awsca]:
            server_time = get_beijing_time(server_time)     # 加8小时
            print ("time2:" + str(server_time))

        p = os.path.abspath(os.path.dirname(__file__) + os.sep + '..' + os.sep)
        p = os.path.dirname(p) + os.sep + 'jlibs'
        tok_jar = p + os.sep + 'token.jar'

        # 调用jar[命令跟dos下一样]
        url = url.replace('$', '*')
        # print "------------------ begin jar"
        cmd = 'java -jar "' + tok_jar + '" %s %s %s %s "%s" %s' % (
            token_id, server_time, host, method, url, self.mac_key
        )
        # print "------------------ end jar"
        print cmd

        res = CoProc().run(cmd)
        authorization = res['result'][:-2]

        logger.info(cmd)
        logger.info(authorization)
        logger.info("获取token命令")

        return authorization

    def login(self, login_name, password, org_name="", has_encoded=False):
        """
        4.1.3 用户登陆
        {
            "login_name":"", --用户名或手机号或工号
            "password":"", --密码(加密算法由uc_sdk提供)
            "org_name":"", --组织登录名称(可选)
        }
        """
        nd_uc_o = NdUc()

        if has_encoded is False:    # 未加密
            md5_pw = nd_uc_o.get_password_md5(password)
        else:                       # 已加密
            md5_pw = password

        json_data = {
            "login_name": login_name,
            "password": md5_pw,
            "org_name": org_name
        }

        param = json.dumps(json_data)

        self.http_obj.set_header(self.header)

        url = '/v0.93/tokens'
        response = self.http_obj.post(url, param)

        return response

    def genarate_login_body(self, login_name, password, org_name="", uc_header=None, has_encoded=False):
        """
        封装登录需要的body

        """
        nd_uc_o = NdUc(uc_header=uc_header)
        if has_encoded is False:    # 未加密
            md5_pw = nd_uc_o.get_password_md5(password)
        else:                       # 已加密
            md5_pw = password
        json_data = {
            "login_name": login_name,
            "password": md5_pw,
            "org_name": org_name
        }
        if self.uc_version == '1.0':
            if uc_header.has_key('sdp-migrated') and str(uc_header['sdp-migrated']) == 'true':
                    session = self.get_login_session()
                    if org_name != "" and org_name != None:
                        login_name += '@'+ org_name
                    login_name = des_encrypt(login_name, session['session_key'])
                    md5_pw = des_encrypt(md5_pw, session['session_key'])
                    json_data = {
                        "login_name": login_name,
                        "password": md5_pw,
                        "session_id": session['session_id']
                     }
            else:
                if re.compile(ur'(\S+@\S+)').match(login_name):
                    body_org_name = ''
                elif org_name !="":
                    body_org_name = org_name
                elif uc_header.has_key('org_name'):
                    body_org_name = uc_header['org_name']
                elif uc_header.has_key('org'):
                    body_org_name = uc_header['org']
                else:
                    raise Exception("未指定登录组织（org_name/org）！")

                json_data = {
                    "login_name": login_name,
                    "password": md5_pw,
                    "org_name": body_org_name
                }

        return json.dumps(json_data)

    def get_login_info(self, login_name, password, org_name, uc_header=None, has_encoded=False):
        """
        4.1.3 用户登陆
        {
            "login_name":"", --用户名或手机号或工号
            "password":"", --密码(加密算法由uc_sdk提供)
            "org_name":"", --组织登录名称(可选)
        }
        备注：Mac Token 有效期为7天
        """
        # 获取运行工程路径
        path =  self.get_project_path()
        actual_version = '0.93'
        # 判断是不是uc 1.0版本
        if self.uc_version == '1.0':
            if uc_header.has_key('sdp-migrated') and str(uc_header['sdp-migrated']) == 'true':
                actual_version = '1.0'
        with open(path, 'a+') as f:
            lines = f.readlines()
            count = len(lines)
            if count != 0:
                for i in xrange(count):
                    # [:-1] 是为了去掉末尾的‘\n’符号
                    account_info_list = lines[i][:-1].split(',')
                    if login_name in account_info_list and password in account_info_list \
                            and str(org_name) in account_info_list and str(self.env) in account_info_list \
                            and actual_version in account_info_list and 'token' in account_info_list:
                        if time.time() - float(account_info_list[6]) > 432000:
                            self.logout(account_info_list[7])
                            del lines[i]
                            break
                        else:
                            if actual_version == '1.0':
                                self.session_key = account_info_list[9]
                            # 校验令牌有效性，无效重新获取
                            response = self.token_valid(account_info_list[7], account_info_list[8])
                            if response['code'] != 201:
                                del lines[i]
                                break
                            self.rest_o.parse_response(response, 201, 'access_token令牌检查失败')
                            return account_info_list[7], account_info_list[8]

            param = self.genarate_login_body(login_name, password, org_name, uc_header)

            self.http_obj.set_header(self.header)

            url = '/v' + str(self.uc_version) + '/tokens'
            # 请求
            response = self.http_obj.post(url, param)

            # 判断是否登录成功，判断session是否过期，过期重发，如果登录不成功再请求一次
            if response['code'] == 400:
                response_data = json.loads(response['data'])
                if response_data['code'] == "UC/SESSION_EXPIRED":
                    param = self.genarate_login_body(login_name, password, org_name)
                    response = self.http_obj.post(url, param)
                elif response['code'] != 201:
                    response = self.http_obj.post(url, param)
            data_dict = self.rest_o.parse_response(response, 201, '用户登陆失败')

            logger.info("登录信息")
            logger.info(data_dict)
            # 获取登录返回信息
            access_token = data_dict['access_token']
            mac_key = data_dict['mac_key']

        with open(path, 'w') as f:
            f.write(login_name + ',' + password + ',' + str(org_name) + ',' + str(self.env) + ',' + actual_version  + ','
                    + 'token'+ ',' + str(time.time()) + ',' + access_token + ',' + mac_key + ',' + self.session_key + '\n')
            f.write("".join(lines))
        return access_token, mac_key


    def get_token(self, user, password, org='', url='', method='', host='',
                  account_config_name=None, account='', path='', has_encoded=False):
        """
        用户登录，获取authorization
        :param user:用户名
        :param password:密码
        :param org:组织，无组织可不传
        :param url:请求的相对url，如 '/user'
        :param method:请求方法，如 'GET'
        :param host:请求的host，不是指uc的host
        :param account_config_name:账户配置文件名，
        :param account:账户配置文件名中的账号标签，
        :param path:账户配置文件所在的路径，
        :param has_encoded:密码是否已加密
        :return:登录后获取到的authorization
        """
        # 1.登录
        if self.flag:
            if account != '' and account is not None:
                # 读配置文件，获取user等配置
                account_cfg = MyCfg(account_config_name)
                account_cfg.set_section(account)
                account_cfg.set_path(path)
                self.user = account_cfg.get("user")
                self.password = account_cfg.get("password")
                self.org = account_cfg.get("org")
                self.account = account
            else:
                self.user = user
                self.password = password
                self.org = org

            # 获取登录返回信息
            self.access_token ,self.mac_key = self.get_login_info(self.user, self.password, self.org, self.uc_header, has_encoded)
            # 获取本地时间与服务器时间的差距
            self.time_span = self.get_adjust_server_time()
            self.flag = False

        if len(url) == 0:
            raise Exception("url不能为空")

        if len(method) == 0:
            raise Exception("http method不能为空")
        # 读取账号信息
        if account != '' and account is not None:
            # 读配置文件
            account_cfg = MyCfg(account_config_name)
            account_cfg.set_section(account)
            account_cfg.set_path(path)
            # 获取user等配置
            self.user = account_cfg.get("user")
            self.password = account_cfg.get("password")
            self.org = account_cfg.get("org")
        elif user != self.user or password != self.password or org != self.org:
            self.user = user
            self.password = password
            self.org = org
            self.account = 'account_change' # 标志 账户变更

        # 判断账号是否变更
        if account != self.account:
            self.access_token ,self.mac_key = self.get_login_info(self.user, self.password, self.org, self.uc_header, has_encoded)
            self.account = account
        # 获取授权信息
        authorization = self.get_authorization(self.access_token, self.mac_key, url, method, host)

        return authorization

    def get_token2(self, user, password, org='', url='', method='', host='',
                   account_config_name=None, account='', path='', has_encoded=False):
        """
        用户登录，获取authorization
        :param user:用户名
        :param password:密码
        :param org:组织，无组织可不传
        :param url:请求的相对url，如 '/user'
        :param method:请求方法，如 'GET'
        :param host:请求的host，不是指uc的host
        :param account_config_name:账户配置文件名，
        :param account:账户配置文件名中的账号标签，
        :param path:账户配置文件所在的路径，
        :param has_encoded:密码是否已加密
        :return:登录后获取到的authorization
        """
        # 1.登录
        if self.flag:
            if account != '' and account is not None:
                # 读配置文件，获取user等配置
                account_cfg = MyCfg(account_config_name)
                account_cfg.set_section(account)
                account_cfg.set_path(path)
                self.user = account_cfg.get("user")
                self.password = account_cfg.get("password")
                self.org = account_cfg.get("org")
                self.account = account
            else:
                self.user = user
                self.password = password
                self.org = org

            # 获取登录返回信息
            self.access_token ,self.mac_key = self.get_login_info(self.user, self.password, self.org, has_encoded)
            self.locate_time = int(time.time()*1000)
            # 获取本地时间与服务器时间的差距
            self.time_span = self.get_adjust_server_time()
            self.flag = False

        if len(url) == 0:
            raise Exception("url不能为空")

        if len(method) == 0:
            raise Exception("http method不能为空")
        # 读取账号信息
        if account != '' and account is not None:
            # 读配置文件
            account_cfg = MyCfg(account_config_name)
            account_cfg.set_section(account)
            account_cfg.set_path(path)
            # 获取user等配置
            self.user = account_cfg.get("user")
            self.password = account_cfg.get("password")
            self.org = account_cfg.get("org")
        elif user != self.user or password != self.password or org != self.org:
            self.user = user
            self.password = password
            self.org = org
            self.account = 'account_change' # 标志 账户变更

        service_time = int(time.time()*1000)
        # 判断账号是否变更
        if account != self.account:
            self.access_token ,self.mac_key = self.get_login_info(self.user, self.password, self.org, has_encoded)
            self.locate_time = int(time.time()*1000)
            self.account = account
        # session时效为20分钟（防止时间误差，实际采用19分钟），超时重新创建
        elif service_time - self.locate_time > 19*60*1000:
            if self.uc_version == '1.0':
                session = self.get_login_session()
            self.locate_time = int(time.time()*1000)
        # 获取授权信息
        authorization = self.get_authorization(self.access_token, self.mac_key, url, method, host)

        return authorization

    def get_authorization(self, access_token, mac_key, url, method, host):
        """
         Authorization生成算法
        :param access_token:令牌
        :param mac_key:秘钥
        :param url:请求的相对url，如 '/user'
        :param method:请求方法，如 'GET'
        :param host:请求的host
        """
        code_count = 8  # 定义随机码的个数
        code_sequence = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
        # 获取校准后的本地时间 self.time_span默认为0
        timestamp = str(int(time.time()*1000) + self.time_span)
        # print timestamp
        # 直接采用服务器时间
        # timestamp = str(self.get_ms_format())
        # if self.env in [UcEnv.aws, UcEnv.awsca]:
        # timestamp = self.get_ms_format()     # 加8小时

        uuid = ''
        for i in xrange(code_count):
            uuid += random.choice(code_sequence)
        nonce = timestamp + ":" + uuid

        message = nonce + "\n" + method + "\n" + url + "\n" + host + "\n"

        if self.uc_version == '1.0':
            if self.auth_header_switch == 'true':
                self.sdp_header = sorted(self.sdp_header.items(), key=lambda sdp_header:sdp_header[0], reverse=False)
                request = ''
                for item in self.sdp_header:
                    request += str(item[1]) + "\n"
                message += request
            if self.uc_header.has_key('sdp-migrated') and str(self.uc_header['sdp-migrated']) == 'true':
                mac_key = des_decrypt(mac_key,self.session_key)

        msg = bytes(message).encode('utf-8')
        key = bytes(mac_key).encode('utf-8')
        mac = base64.b64encode(hmac.new(key, msg, digestmod=hashlib.sha256).digest())
        authorization = 'MAC id="' + access_token + '",nonce="' + nonce + '",mac="' + mac + '"'

        # print "authorization: ", authorization
        return authorization.encode('utf-8')

    # -------------- 生成bearer token ----------------- #
    def server_login(self, username, password=None, has_encoded=False):
        """
        4.1.14 服务端登录
        {
            "username"：用户名或手机号
            "password"：密码     【使用后台配置好的密码，如下代码所写】
        }
        注：服务端登录没有对应的退出
        """
        nd_uc_o = NdUc()

        if has_encoded is False:
            md5_pw = nd_uc_o.get_password_md5(password)
        else:
            md5_pw = password

        json_data = {
            "login_name": username,
            "password": md5_pw
        }
        param = json.dumps(json_data)

        url = "/v0.93/bearer_tokens"
        response = self.http_obj.post(url, param)
        return response

    def get_bearer_token(self, user_name='', password='', has_encoded=False):
        """
        通过服务端登录，获取bearer token
        :param user_name: 用户名
        :param password: 密码
        :param has_encoded: 密码是否已加密
        :return:登录返回的bearer token
        """
        # 获取运行工程路径
        path = self.get_project_path()
        with open(path, 'a+') as f:
            lines = f.readlines()
            count = len(lines)
            if count != 0:
                for i in xrange(count):
                    # [:-1] 是为了去掉末尾的‘\n’符号
                    account_info_list = lines[i][:-1].split(',')
                    if user_name in account_info_list and password in account_info_list \
                            and str(self.env) in account_info_list and '0.93' in account_info_list \
                            and 'bearer_token' in account_info_list:
                        if time.time() - float(account_info_list[6]) > 432000:
                            self.logout(account_info_list[7])
                            del lines[i]
                            break
                        else:
                            # 校验令牌有效性，无效重新获取
                            response = self.bearer_token_valid(account_info_list[7])
                            if response['code'] != 201:
                                del lines[i]
                                break
                            self.rest_o.parse_response(response, 201, 'bearer_token令牌检查失败')
                            return account_info_list[7]
        response = self.server_login(user_name, password, has_encoded)
        data_dec = Restful().parse_response(response, 201, "服务端登录失败")

        with open(path, 'w') as f:
            f.write(user_name + ',' + password + ',None,' + str(self.env) + ',0.93,bearer_token,' + str(time.time())
                    + ',' + data_dec['access_token'] + ',' + data_dec['mac_key'] + ',' + self.session_key + '\n')
            f.write("".join(lines))

        return data_dec['access_token']

    def logout(self, token):
        """
        4.1.6 退出系统 - 设置令牌过期
        注：服务端不需要退出
        """

        url = "/v" + str(self.uc_version) + "/tokens/" + token

        response = self.http_obj.delete(url)
        data = self.rest_o.parse_response(response, 200, "设置令牌过期（退出）失败")

        return data

    def token_valid(self, access_token, mac_key):
        """
        4.1.4 token令牌检查 - 判断令牌是否过期
        """
        request_uri = "/v" + str(self.uc_version) + "/server/time"
        authorization = self.get_authorization(access_token, mac_key, request_uri, "POST", self.host).split(',')
        url = "/v" + str(self.uc_version) + "/tokens/" + access_token + "/actions/valid"
        json_data = {
            "mac":authorization[2].split('mac="')[1][:-1],
            "nonce":authorization[1].split('nonce="')[1][:-1],
            "http_method" : "POST",
            "request_uri" : request_uri,
            "host" : self.host
        }
        response = self.http_obj.post(url, json.dumps(json_data))

        return response

    def bearer_token_valid(self, bearer_token):
        """
        4.1.15 bearer_token令牌检查 - 判断令牌是否过期
        """
        url = "/v" + str(self.uc_version) + "/bearer_tokens/" + bearer_token + "/actions/valid"

        response = self.http_obj.get(url)

        return response

    def get_project_path(self):
        """
        获取当前运行工程的路径
        :return: path
        """
        temp = os.getcwd()
        if os.path.exists(os.path.join(temp, 'runner.py')):
            path = temp.split(os.sep + 'runner')
        else:
            path = temp.split(os.sep + 'testcases' + os.sep)
        path = path[0] + os.sep + 'uc_token.txt'
        return path