# coding=utf-8

__author__ = 'Administrator'

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.info(__name__)

import threading


class Semaphore(threading._Semaphore):
    # wait()
    wait = threading._Semaphore.acquire
    # signal = threading._Semaphore.release

    def signal(self, n=1):
        """Signal the semaphore.

        n: how many times to signal
        """
        for i in range(n):
            self.release()

    def value(self):
        """
        返回semaphore的当前值
        Returns the current value of the semaphore.

        Note: asking for the value of a semaphore is almost always
        a bad idea.
        获取当前值是不对的，该方法应该仅作为测试用

        If you do anything based on the result, it is
        likely to be a mistake.
        """
        return self._Semaphore__value


if __name__ == '__main__':
    sema1 = Semaphore(1)
    logger.info(sema1.value())

    sema0 = Semaphore(0)
    logger.info(sema0.value())
