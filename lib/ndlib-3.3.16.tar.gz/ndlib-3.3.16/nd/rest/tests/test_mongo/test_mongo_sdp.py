# coding=utf-8
from ..co_test.nd_case import NdCase

__author__ = 'linzh'


class MongoSdpTest(NdCase):
    def test_ok(self):
        """

        :return:
        """
        pass
