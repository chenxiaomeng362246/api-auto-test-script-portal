# coding=utf-8

"""httplib的一层封装，更易于使用

.. doctest:: 

    >>> http_obj = cofHttp.Http(url, 80)
    >>> http_obj.set_header(header)
    >>> http_obj.post
"""

__author__ = 'Administrator'

import urllib2
import cookielib
from restful import Restful
import time
import socket
import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logger.info(__name__)

class HttpMonitor(object):
    """对GET/POST进行了封装，让代码更简短易读
    :class:`cof.http.Http` 先初始化

    * `METHOD`: 默认请求方法
    """

    METHOD = "GET"

    def __init__(self, host, port=80, url='', ssl=False, timeout=60):
        """
        使用httplib库进行操作
        """
        import httplib
        self.host = host
        self.port = str(port)
        if self.port == "":
            self.port = None
        self.url = url
        self.header = dict()
        # 请求body
        self.params = None
        self.timeout = timeout
        if ssl:
            self.conn = httplib.HTTPSConnection(self.host, self.port, timeout=self.timeout)
        else:
            # self.conn = httplib.HTTPConnection("127.0.0.1", 8888)
            self.conn = httplib.HTTPConnection(self.host, self.port, timeout=self.timeout)

        # self.conn.set_tunnel(self.host, int(self.port))

    def parse_url(self):
        pass

    def set_header(self, header):
        """
        设置http请求头，可以设置AccessToken
        """
        self.header = header

    def send_request(self, res, method, url, headers, body=None):
        """
        封装发送请求的过程
        """
        retry_count = 0  # 重试次数
        for i in xrange(2):
            try:
                headers['Qa-tag'] = '0'
                start_time = time.time()
                conn = self.conn
                conn.request(method=method, url=url, headers=headers, body=body)
                response = conn.getresponse()
                stop_time = time.time()
                res["code"] = response.status
                res["data"] = response.read()
                res["response_header"] = response.getheaders()
                break
            except socket.error, e:  # 连接错误 or 读取错误  只捕获socket超时异常、10060、11004
                logger.error(e)
                if (e.errno == 10060 or e.errno == 11004) and retry_count == 0:  # 如果为10060防火墙异常\11004域名解析异常重试一次
                    conn.close()
                    retry_count += 1
                    print ("<p><span style=\"color:blue\">socket %s错误，重试一次<span></p><hr/>" % str(e.errno))
                    continue
                elif e.message == 'timed out':
                    stop_time = time.time()
                    res["code"] = 0
                    res["data"] = '{"message": "%s"}' % (e)
                    res["response_header"] = {}
                    break
                else:
                    conn.close()
                    raise
        run_time = int((stop_time - start_time) * 1000 + 0.5)
        res["response_time"] = run_time
        print "运行时间：" + str(run_time) + "ms"
        res["request_header"] = headers
        logger.info(url)
        logger.info("===============================")
        if 'data' in res:
            logger.info(res["data"])
        conn.close()

    def get(self, url):
        res = dict()
        if self.port == None:
            res["request"] = "GET " + self.host + url
        else:
            res["request"] = "GET " + self.host + ":" + self.port + url
        self.send_request(res, 'GET', url, self.header)
        return res

    def post(self, url, params):
        res = dict()
        if self.port == None:
            res["request"] = "POST " + self.host + url + ",body=" + params
        else:
            res["request"] = "POST " + self.host + ":" + self.port + url + ",body=" + params
        self.send_request(res, 'POST', url, self.header, body=params)
        return res

    def delete(self, url, params=None):
        res = dict()
        if self.port == None:
            res["request"] = "DELETE " + self.host + url
        else:
            res["request"] = "DELETE " + self.host + ":" + self.port + url
        if params != None:
            res["request"] += ",\nbody=" + params
        self.send_request(res, 'DELETE', url, self.header, body=params)
        return res

    def patch(self, url, params):
        res = dict()
        if self.port == None:
            res["request"] = "PATCH " + self.host + url + ",body=" + params
        else:
            res["request"] = "PATCH " + self.host + ":" + self.port + url + ",body=" + params
        self.send_request(res, 'PATCH', url, self.header, body=params)
        return res

    def put(self, url, params):
        res = dict()
        if self.port == None:
            res["request"] = "PUT " + self.host + url + ",body=" + params
        else:
            res["request"] = "PUT " + self.host + ":" + self.port + url + ",body=" + params
        self.send_request(res, 'PUT', url, self.header, body=params)
        return res


class Http2(object):
    """
    使用urllib2 http库进行调用
    """
    def __init__(self, host, port, url, timeout=60):
        self.host = host
        self.port = port
        self.header = dict()
        # 请求body
        self.params = None
        self.timeout = timeout

        self.req_url = 'http://' + host + ':' + port + url
        self.conn = urllib2.Request(self.req_url)

    def set_header(self, header):
        # print header
        header['Qa-tag'] = '0'
        for k in header:
            v = header[k]
            self.conn.add_header(k, v)

    def post(self, url, params):
        error = None
        res = None
        try:
            response = urllib2.urlopen(self.req_url, params, timeout=self.timeout)
            res = response.read()
        except Exception, e:  # 连接错误 or 读取错误
            error = e.message
            logger.info(e)
        Restful().request_timeout(error, self.timeout, self.req_url)
        return res


class Http3(object):
    def __init__(self, host, port, url='', timeout=60):
        cookies = cookielib.LWPCookieJar()

        handlers = [
            urllib2.HTTPHandler(),
            urllib2.HTTPSHandler(),
            urllib2.HTTPCookieProcessor(cookies)
        ]

        self.opener = urllib2.build_opener(*handlers)
        self.req_url = 'http://' + host + ':' + str(port)
        self.timeout = timeout

    def set_header(self, header):
        # print header
        header['Qa-tag'] = '0'
        for k in header:
            v = header[k]
            self.opener.addheaders.append((k, v))

    def post(self, url, params):
        error = None
        res = None
        try:
            url = self.req_url + url
            req = urllib2.Request(url)
            res = self.opener.open(req, params, timeout=self.timeout).read()
        except Exception, e:  # 连接错误 or 读取错误
            error = e.message
            logger.info(e)
        Restful().request_timeout(error, self.timeout, url)
        return res

    def get(self, url):
        error = None
        res = None
        try:
            url = self.req_url + url
            req = urllib2.Request(url)
            res = self.opener.open(req, timeout=self.timeout).read()
        except Exception, e:  # 连接错误 or 读取错误
            error = e.message
            logger.info(e)
        Restful().request_timeout(error, self.timeout, url)
        return res

class Http4(object):
    """对GET/POST进行了封装，让代码更简短易读 添加了获取jsession
    :class:`cof.http.Http` 先初始化

    * `METHOD`: 默认请求方法
    """

    METHOD = "GET"

    def __init__(self, host, port=80, url='', ssl=False, timeout=60):
        """
        使用httplib库进行操作
        """
        import httplib
        self.host = host
        self.port = str(port)
        if self.port == "":
            self.port = None
        self.url = url
        self.header = dict()
        # 请求body
        self.params = None
        self.timeout = timeout
        if ssl:
            self.conn = httplib.HTTPSConnection(self.host, self.port, timeout=self.timeout)
        else:
            self.conn = httplib.HTTPConnection(self.host, self.port, timeout=self.timeout)

    def parse_url(self):
        pass

    def set_header(self, header):
        """
        设置http请求头，可以设置AccessToken
        """
        self.header = header

    def send_request(self, res, method, url, headers, body=None):
        """
        封装发送请求的过程
        """
        retry_count = 0  # 重试次数
        for i in xrange(2):
            try:
                headers['Qa-tag'] = '0'
                conn = self.conn
                conn.request(method=method, url=url, headers=headers, body=body)
                response = conn.getresponse()
                res["code"] = response.status
                res["data"] = response.read()
                cookie = response.getheader("set-cookie")
                if cookie != None:
                    start = cookie.find("JSESSIONID=")
                    end = cookie.find(";", start + 11)
                    jsession = str(cookie[start + 11:end])
                    res["jsession"] = jsession
                break
            except socket.error, e:  # 连接错误 or 读取错误  只捕获socket超时异常、10060、11004
                logger.error(e)
                if (e.errno == 10060 or e.errno == 11004) and retry_count == 0:  # 如果为10060防火墙异常\11004域名解析异常重试一次
                    conn.close()
                    retry_count += 1
                    print ("<p><span style=\"color:blue\">socket %s错误，重试一次<span></p><hr/>" % str(e.errno))
                    continue
                elif e.message == 'timed out':
                    res["code"] = 0
                    res["data"] = '{"message": "%s"}' % (e)
                    res["response_header"] = {}
                    break
                else:
                    conn.close()
                    raise
        res["request_header"] = headers
        conn.close()

    def get(self, url):
        res = dict()
        if self.port == None:
            res["request"] = "GET " + self.host + url
        else:
            res["request"] = "GET " + self.host + ":" + self.port + url
        self.send_request(res, 'GET', url, self.header)
        return res

    def post(self, url, params):
        res = dict()
        if self.port == None:
            res["request"] = "POST " + self.host + url + ",\nbody=" + params
        else:
            res["request"] = "POST " + self.host + ":" + self.port + url + ",\nbody=" + params
        self.send_request(res, 'POST', url, self.header, body=params)
        return res

    def delete(self, url, params=None):
        res = dict()
        if self.port == None:
            res["request"] = "DELETE " + self.host + url
        else:
            res["request"] = "DELETE " + self.host + ":" + self.port + url
        if params != None:
            res["request"] += ",\nbody=" + params
        self.send_request(res, 'DELETE', url, self.header, body=params)
        return res

    def patch(self, url, params):
        res = dict()
        if self.port == None:
            res["request"] = "PATCH " + self.host + url + ",\nbody=" + params
        else:
            res["request"] = "PATCH " + self.host + ":" + self.port + url + ",\nbody=" + params
        self.send_request(res, 'PATCH', url, self.header, body=params)
        return res

    def put(self, url, params):
        res = dict()
        if self.port == None:
            res["request"] = "PUT " + self.host + url + ",\nbody=" + params
        else:
            res["request"] = "PUT " + self.host + ":" + self.port + url + ",\nbody=" + params
        self.send_request(res, 'PUT', url, self.header, body=params)
        return res


class HttpCurl(object):
    """
    使用
    """
    def get(self):
        pass


class HttpTornado(object):
    def __init__(self):
        from tornado.httpclient import HTTPClient
        self.conn = HTTPClient()

    """
    使用tornado库
    """
    def get(self, url):
        return self.conn.fetch(url)
        pass

    def put(self, url):
        from tornado.httpclient import HTTPRequest
        req = HTTPRequest(url, "PUT")
        self.conn.fetch(req)


class HttpInfo(object):
    def __init__(self):
        self.host = ""

    def get_host(self):
        return self.host
