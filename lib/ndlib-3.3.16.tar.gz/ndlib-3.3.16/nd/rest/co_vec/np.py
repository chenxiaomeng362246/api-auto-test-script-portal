# coding=utf-8

__author__ = 'linzh'

import numpy as np


class CoVec(object):
    def __init__(self, l):
        self.vec = np.array(l)
