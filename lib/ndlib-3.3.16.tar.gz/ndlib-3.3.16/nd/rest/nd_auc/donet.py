# coding=utf-8
from cof.conf import get_cfg_type
from cof.tornado.escape import json_decode

cfg_type = get_cfg_type()

if cfg_type == "test":
    from cof.co_http.co_curl import Http
else:
    from cof.http import Http

import urllib
from cof.nd_auc.auc import AucToken

Http.DEBUG = True

__author__ = 'linzh'

import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(filename)s[%(lineno)d] %(levelname)s %(message)s')
logger = logging.getLogger(__name__)
logger.info(__name__)


class Elearn(object):
    def __init__(self):
        host = 'api.e.test.huayu.nd'
        self.http_o = Http(host)
        header = dict()
        header['Content-Type'] = 'application/x-www-form-urlencoded'
        header['Accept'] = 'application/json'
        self.http_o.set_header(header)
        self.ver = '6'

    def base_url(self, url):
        token_o = AucToken()
        tok = token_o.get_access()
        url += '?accesstoken=' + tok
        url = '/v' + str(self.ver) + '/' + url
        return url

    def uctoken(self):
        token_o = AucToken()
        tok = token_o.get_access()
        return tok

    def get(self, url, param=None):
        url = self.base_url(url)
        if param:
            url += '&' + urllib.urlencode(param)
        res = self.http_o.get(url)
        logger.info(res)

        return res

    def post(self, url, data):
        data = urllib.urlencode(data)
        res = self.http_o.post(self.base_url(url), data)
        return res

    def get_auc_id(self):
        work_nr = "871101"
        data = dict()
        data['ucid'] = work_nr
        res = self.get("user/getuseridbyucid", data)
        data = json_decode(res['data'])
        data_dec = data['Data']
        return data_dec['UserId']


if __name__ == '__main__':
    o = Elearn()
    o.get('project/channels')

