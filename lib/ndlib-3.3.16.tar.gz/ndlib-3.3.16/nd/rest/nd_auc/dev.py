# coding=utf-8

__author__ = 'linzh'


class Auth(object):
    @staticmethod
    def get_cfg():
        # elearning_host = elearning-web.debug.web.nd
        # uc_host = 101uccenter.beta.web.sdp.101.com
        # gateway_host = elearning-gateway.debug.web.nd
        # port =
        cfg = dict()
        cfg['auc_host'] = 'test.userapi.huayu.nd'
        cfg['user'] = '10005074@nd'
        cfg['password'] = 'qa123456'
        cfg['client_id'] = '1816'
        cfg['client_secret'] = '7776a6c8a0a347a1'

        return cfg

    @staticmethod
    def get_test_cfg():
        cfg = dict()
        # auc_host = userapi.e.101.com
        # gateway_host = elearning-gateway.beta.web.sdp.101.com
        # client_id = 298
        # client_secret = b439665485b24fc3
        # port = 80
        # user = 10005074@nd
        # password = qa123456


