# coding=utf-8
__author__ = 'linzh'

"""
jenkins操作函数库
"""


class Jenkins(object):
    def __init__(self):
        self.host = ""
        self.port = 0

    def get_jobs(self):
        """

        :return:
        """
        pass

    def make_job_xml(self):
        """
        创建jenkins任务配置文件

        :return:
        """
        pass

    def create_job(self):
        """

        :return:
        """
        pass