# coding=utf-8
__author__ = 'linzh'

from ..nd_cs import NdCs


def get_download_url(dentry_id):
    """
    获取指定文件下载地址

    dentry_id -> url

    :param dentry_id:

    :return:

    .. code-block:: python
        :linenos:

        >>> from cof.nd_cs.html import get_download_url
        >>> url = get_download_url(dentry_id)
        >>> print url
    """
    nd_cs_o = NdCs()
    session = nd_cs_o.get_session('10003732')
    cs_download_url = 'http://cdncs.101.com/v0.1/download?'
    cs_download_url += 'dentryId=' + dentry_id
    cs_download_url += '&session=' + session['session']
    report_url = cs_download_url
    return report_url


def get_static_url(filename):
    """
    静态方式链接

    :param dentry_id:
    :return:

    .. code-block:: python
        :linenos:

        >>> from cof.nd_cs.html import get_static_url
        >>> filename = '/report.html'
        >>> url = get_static_url(filename)
        >>> print url
    """
    nd_cs_o = NdCs()
    session_info = nd_cs_o.get_session('10003732')

    return 'http://cdncs.101.com/v0.1/' + session_info['session'] + '/static' + session_info['path'] + filename


if __name__ == '__main__':
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.info(__name__)

    dentry_id = "test"
    url = get_download_url(dentry_id)
    logger.info(url)

    filename = '/report.html'
    url = get_static_url(filename)
    logger.info(url)

