# coding=utf-8

__author__ = 'linzh'

import matplotlib.pyplot as plt

font = {
    'family': 'YaHei Consolas Hybrid',
    'size': 10
}

plt.matplotlib.rc('font', **font)


class CoPoint(object):
    def __init__(self, size=None):
        self.x = [1, 2, 3]
        self.y = [2, 3, 6]

        self.area = None

        if size:
            fig = plt.figure(figsize=size)
        else:
            fig = plt.figure(figsize=(5, 15))

        self.ax = fig.add_subplot(111)

        self.xaxis = plt.gca().xaxis

    def set_x(self, x):
        self.x = x

    def set_y(self, y):
        self.y = y

    def set_xy(self, x, y):
        self.x = x
        self.y = y

    def set_area(self, area):
        self.area = area

    def set_ylabel(self, label):
        self.ax.set_ylabel(label)

    def set_xlabel(self, label):
        self.ax.set_xlabel(label)

    def set_xtick(self, x):
        xaxis = self.ax.xaxis

        xaxis.set_ticklabels(x)

    def set_ytick_val(self, y):
        self.ax.set_ylim(-1, 11)
        yaxis = self.ax.yaxis
        yaxis.set_ticks(y)

    def set_ytick(self, y):
        yaxis = self.ax.yaxis

        yaxis.set_ticklabels(y)

    def plot(self):
        if self.area:
            self.ax.scatter(self.x, self.y, s=self.area, c='#0d6cb0')
        else:
            self.ax.scatter(self.x, self.y)


