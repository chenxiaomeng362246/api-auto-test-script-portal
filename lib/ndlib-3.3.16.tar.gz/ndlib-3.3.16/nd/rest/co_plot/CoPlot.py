# coding=utf-8

__author__ = 'linzh'

import matplotlib.pyplot as plt

plt.style.use('ggplot')


class CoPlot(object):
    @staticmethod
    def show():
        """

        :return:
        """
        plt.show()

    @staticmethod
    def save(name="figure.png"):
        # plt.tight_layout()
        plt.subplots_adjust(bottom=0.5)
        plt.savefig(name, bbox_inches='tight')
        return name
