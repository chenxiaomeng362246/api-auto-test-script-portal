# coding=utf-8
from nd.rest.co_time import get_ts
from nd.rest.co_test.nd_case import NdCase

__author__ = 'linzh'


class TimeTest(NdCase):
    def setUp(self):
        pass

    def test_expired(self):
        pass

    def test_get_ts(self):
        """
        获取当前时间戳

        :return:
        """
        print get_ts()
